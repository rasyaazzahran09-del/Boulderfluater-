import 'dart:math';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ══════════════════════════════════════════════════════════
//  SNOW PARTICLE
// ══════════════════════════════════════════════════════════
class SnowParticle {
  double x, y, radius, speed, opacity, drift;
  bool isCrystal;
  SnowParticle({
    required this.x, required this.y, required this.radius,
    required this.speed, required this.opacity, required this.drift,
    required this.isCrystal,
  });
}

class SnowPainter extends CustomPainter {
  final List<SnowParticle> particles;
  SnowPainter({required this.particles});

  void _drawCrystal(Canvas canvas, Offset center, double size, double opacity) {
    final paint = Paint()
      ..color = const Color(0xFFB3E5FC).withOpacity(opacity)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (int i = 0; i < 6; i++) {
      final angle = (i * 60) * pi / 180;
      final end = Offset(center.dx + cos(angle) * size, center.dy + sin(angle) * size);
      canvas.drawLine(center, end, paint);
      for (double t = 0.4; t <= 0.8; t += 0.3) {
        final bs = Offset(center.dx + cos(angle) * size * t, center.dy + sin(angle) * size * t);
        final bl = size * 0.3;
        for (int s = -1; s <= 1; s += 2) {
          final ba = angle + s * 60 * pi / 180;
          canvas.drawLine(bs, Offset(bs.dx + cos(ba) * bl, bs.dy + sin(ba) * bl), paint);
        }
      }
    }
    canvas.drawCircle(center, size * 0.5, Paint()
      ..color = const Color(0xFF80D8FF).withOpacity(opacity * 0.3)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4));
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      if (p.isCrystal) {
        _drawCrystal(canvas, Offset(p.x, p.y), p.radius, p.opacity);
      } else {
        canvas.drawCircle(Offset(p.x, p.y), p.radius, Paint()
          ..color = Colors.white.withOpacity(p.opacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5));
      }
    }
  }

  @override
  bool shouldRepaint(covariant SnowPainter old) => true;
}

class SnowfallWidget extends StatefulWidget {
  const SnowfallWidget({super.key});
  @override
  State<SnowfallWidget> createState() => _SnowfallWidgetState();
}

class _SnowfallWidgetState extends State<SnowfallWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final List<SnowParticle> _particles = [];
  final Random _rng = Random();
  Size _size = Size.zero;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))
      ..addListener(_update)..repeat();
  }

  void _init(Size size) {
    if (_particles.isNotEmpty) return;
    _size = size;
    for (int i = 0; i < 80; i++) _particles.add(_make(randomY: true));
  }

  SnowParticle _make({bool randomY = false}) => SnowParticle(
    x: _rng.nextDouble() * _size.width,
    y: randomY ? _rng.nextDouble() * _size.height : -20,
    radius: _rng.nextDouble() * 5 + 1.5,
    speed: _rng.nextDouble() * 0.8 + 0.3,
    opacity: _rng.nextDouble() * 0.5 + 0.15,
    drift: (_rng.nextDouble() - 0.5) * 0.5,
    isCrystal: _rng.nextDouble() > 0.65,
  );

  void _update() {
    if (_size == Size.zero) return;
    setState(() {
      for (int i = 0; i < _particles.length; i++) {
        final p = _particles[i];
        p.y += p.speed * 1.2;
        p.x += p.drift;
        if (p.y > _size.height + 20 || p.x < -20 || p.x > _size.width + 20) {
          _particles[i] = _make();
        }
      }
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, c) {
    _init(Size(c.maxWidth, c.maxHeight));
    return CustomPaint(painter: SnowPainter(particles: _particles), size: Size(c.maxWidth, c.maxHeight));
  });
}

// ══════════════════════════════════════════════════════════
//  GRID PAINTER (tech background lines)
// ══════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final double opacity;
  _GridPainter(this.opacity);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF00D4FF).withOpacity(opacity * 0.07)
      ..strokeWidth = 0.5;

    const gap = 40.0;
    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Diagonal accent lines
    final accentPaint = Paint()
      ..color = const Color(0xFF00D4FF).withOpacity(opacity * 0.04)
      ..strokeWidth = 1;
    for (double x = -size.height; x < size.width; x += 80) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), accentPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.opacity != opacity;
}

// ══════════════════════════════════════════════════════════
//  LANDING PAGE
// ══════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late AnimationController _fadeCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _slideCtrl;
  late AnimationController _scanCtrl;

  late Animation<double> _fadeAnim;
  late Animation<double> _pulseAnim;
  late Animation<Offset>  _slideAnim;
  late Animation<double>  _scanAnim;

  static const Color _bg      = Color(0xFF020810);
  static const Color _ice     = Color(0xFF00D4FF);
  static const Color _iceBlue = Color(0xFF0288D1);
  static const Color _light   = Color(0xFF80EAFF);
  static const Color _card    = Color(0xFF060F1C);
  static const Color _amber   = Color(0xFFFFAA00);

  @override
  void initState() {
    super.initState();

    _fadeCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..forward();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500))..repeat(reverse: true);
    _slideCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..forward();
    _scanCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();

    _fadeAnim  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic));
    _scanAnim  = Tween<double>(begin: 0.0, end: 1.0).animate(_scanCtrl);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _slideCtrl.dispose();
    _scanCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [

        // ── Deep radial background ──
        Container(decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.4),
            radius: 1.8,
            colors: [Color(0xFF0A1E35), Color(0xFF050D1A), Color(0xFF020810)],
          ),
        )),

        // ── Tech grid ──
        Positioned.fill(child: CustomPaint(painter: _GridPainter(1.0))),

        // ── Glow top ──
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Positioned(
            top: -60, left: 0, right: 0,
            child: Center(child: Container(
              width: 400, height: 400,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: _ice.withOpacity(_pulseAnim.value * 0.12), blurRadius: 120, spreadRadius: 40)],
              ),
            )),
          ),
        ),

        // ── Glow bottom right ──
        Positioned(
          bottom: -60, right: -60,
          child: Container(width: 250, height: 250, decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: _iceBlue.withOpacity(0.08), blurRadius: 80, spreadRadius: 20)],
          )),
        ),

        // ── Snowfall ──
        const Positioned.fill(child: SnowfallWidget()),

        // ── Scan line animation ──
        AnimatedBuilder(
          animation: _scanAnim,
          builder: (_, __) => Positioned(
            top: _scanAnim.value * size.height - 2,
            left: 0, right: 0,
            child: Container(
              height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  _ice.withOpacity(0.3),
                  _ice.withOpacity(0.6),
                  _ice.withOpacity(0.3),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
        ),

        // ── Content ──
        SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _slideAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(children: [

                  const SizedBox(height: 50),

                  // ── Logo ──
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Stack(alignment: Alignment.center, children: [
                      // Outer pulse ring
                      Container(
                        width: 160, height: 160,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _ice.withOpacity(_pulseAnim.value * 0.2), width: 1),
                          boxShadow: [BoxShadow(color: _ice.withOpacity(_pulseAnim.value * 0.12), blurRadius: 40, spreadRadius: 10)],
                        ),
                      ),
                      // Mid ring
                      Container(
                        width: 138, height: 138,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _ice.withOpacity(0.3 + _pulseAnim.value * 0.2), width: 1.5),
                        ),
                      ),
                      // Corner decorations
                      ..._buildCornerDecos(130, _ice.withOpacity(0.6)),
                      // Logo circle
                      Container(
                        width: 118, height: 118,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _card,
                          border: Border.all(color: _ice.withOpacity(0.7), width: 2.5),
                          boxShadow: [
                            BoxShadow(color: _ice.withOpacity(_pulseAnim.value * 0.4), blurRadius: 20, spreadRadius: 2),
                            const BoxShadow(color: Colors.black, blurRadius: 10),
                          ],
                        ),
                        child: ClipOval(
                          child: Image.asset('assets/images/reze.png', fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Icon(Icons.person, color: _ice, size: 50)),
                        ),
                      ),
                    ]),
                  ),

                  const SizedBox(height: 28),

                  // ── Status badge ──
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                    decoration: BoxDecoration(
                      color: _ice.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _ice.withOpacity(0.2)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Container(width: 6, height: 6, decoration: const BoxDecoration(color: Color(0xFF00E5A0), shape: BoxShape.circle)),
                      const SizedBox(width: 6),
                      const Text("SYSTEM ONLINE", style: TextStyle(color: Color(0xFF00E5A0), fontSize: 10, fontFamily: 'Orbitron', letterSpacing: 2)),
                    ]),
                  ),

                  const SizedBox(height: 16),

                  // ── Title ──
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [Color(0xFF80D8FF), Colors.white, Color(0xFF40C4FF)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text("XxL Project ", style: TextStyle(
                      fontSize: 30, fontWeight: FontWeight.w900,
                      color: Colors.white, fontFamily: 'Orbitron', letterSpacing: 3,
                    )),
                  ),

                  const SizedBox(height: 8),

                  Text("Powered by @Bizzxx_Reals01",
                    style: TextStyle(color: _light.withOpacity(0.4), fontSize: 12, fontFamily: 'ShareTechMono'),
                    textAlign: TextAlign.center),

                  const SizedBox(height: 44),

                  // ── SIGN IN button ──
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, "/login"),
                    child: Container(
                      width: double.infinity, height: 56,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF0288D1), Color(0xFF00D4FF), Color(0xFF80EAFF)],
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(color: _ice.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6)),
                          BoxShadow(color: _ice.withOpacity(0.2), blurRadius: 40, spreadRadius: 2),
                        ],
                      ),
                      child: Stack(alignment: Alignment.center, children: [
                        // Shimmer overlay
                        ClipRRect(borderRadius: BorderRadius.circular(16),
                          child: AnimatedBuilder(
                            animation: _scanAnim,
                            builder: (_, __) => Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.transparent, Colors.white.withOpacity(0.1), Colors.transparent],
                                  stops: [
                                    (_scanAnim.value - 0.3).clamp(0, 1),
                                    _scanAnim.value.clamp(0, 1),
                                    (_scanAnim.value + 0.3).clamp(0, 1),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.login_rounded, color: Colors.black, size: 20),
                          SizedBox(width: 10),
                          Text("SIGN IN", style: TextStyle(
                            color: Colors.black, fontSize: 15,
                            fontWeight: FontWeight.w900, letterSpacing: 3,
                            fontFamily: 'Orbitron',
                          )),
                        ]),
                      ]),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // ── BUY ACCESS button ──
                  GestureDetector(
                    onTap: () => _openUrl("https://t.me/Bizzxx_Reals01/292"),
                    child: Container(
                      width: double.infinity, height: 56,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _ice.withOpacity(0.35), width: 1.5),
                        boxShadow: [BoxShadow(color: _ice.withOpacity(0.05), blurRadius: 16)],
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.shopping_bag_outlined, color: _ice.withOpacity(0.8), size: 20),
                        const SizedBox(width: 10),
                        Text("BUY ACCESS", style: TextStyle(
                          color: _ice.withOpacity(0.9), fontSize: 14,
                          fontWeight: FontWeight.bold, letterSpacing: 2.5,
                          fontFamily: 'Orbitron',
                        )),
                      ]),
                    ),
                  ),

                  const SizedBox(height: 32),

                  // ── Divider ──
                  Row(children: [
                    Expanded(child: Container(height: 1, decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [Colors.transparent, _ice.withOpacity(0.2)]),
                    ))),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text("CONNECT", style: TextStyle(color: _ice.withOpacity(0.4), fontSize: 9, fontFamily: 'Orbitron', letterSpacing: 2))),
                    Expanded(child: Container(height: 1, decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_ice.withOpacity(0.2), Colors.transparent]),
                    ))),
                  ]),

                  const SizedBox(height: 20),

                  // ── Contact buttons ──
                  Row(children: [
                    Expanded(child: _contactBtn(FontAwesomeIcons.telegram, "Telegram", "https://t.me/Bizzxx_Reals01", const Color(0xFF0088CC))),
                    const SizedBox(width: 14),
                    Expanded(child: _contactBtn(FontAwesomeIcons.whatsapp, "WhatsApp", "https://whatsapp.com/channel/0029Vb7HFj87tkj13mpV990U", const Color(0xFF25D366))),
                  ]),

                  const SizedBox(height: 36),

                  // ── Tech specs row ──
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _ice.withOpacity(0.08)),
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                      _specItem("v2.0", "VERSION"),
                      Container(width: 1, height: 28, color: _ice.withOpacity(0.1)),
                      _specItem("256-BIT", "ENCRYPT"),
                      Container(width: 1, height: 28, color: _ice.withOpacity(0.1)),
                      _specItem("24/7", "UPTIME"),
                    ]),
                  ),

                  const SizedBox(height: 24),

                  // ── Footer ──
                  Text("© 2026 XxL Project ",
                    style: TextStyle(color: Colors.white.withOpacity(0.12), fontSize: 9, fontFamily: 'Orbitron', letterSpacing: 1),
                    textAlign: TextAlign.center),

                  const SizedBox(height: 24),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  List<Widget> _buildCornerDecos(double size, Color color) {
    const len = 12.0;
    const w   = 2.0;
    final half = size / 2;
    return [
      // Top-left
      Positioned(top: -half, left: -half, child: SizedBox(width: size, height: size,
        child: Stack(children: [
          Positioned(top: 0, left: 0, child: Container(width: len, height: w, color: color)),
          Positioned(top: 0, left: 0, child: Container(width: w, height: len, color: color)),
        ]),
      )),
      // Top-right
      Positioned(top: -half, right: -half, child: SizedBox(width: size, height: size,
        child: Stack(children: [
          Positioned(top: 0, right: 0, child: Container(width: len, height: w, color: color)),
          Positioned(top: 0, right: 0, child: Container(width: w, height: len, color: color)),
        ]),
      )),
      // Bottom-left
      Positioned(bottom: -half, left: -half, child: SizedBox(width: size, height: size,
        child: Stack(children: [
          Positioned(bottom: 0, left: 0, child: Container(width: len, height: w, color: color)),
          Positioned(bottom: 0, left: 0, child: Container(width: w, height: len, color: color)),
        ]),
      )),
      // Bottom-right
      Positioned(bottom: -half, right: -half, child: SizedBox(width: size, height: size,
        child: Stack(children: [
          Positioned(bottom: 0, right: 0, child: Container(width: len, height: w, color: color)),
          Positioned(bottom: 0, right: 0, child: Container(width: w, height: len, color: color)),
        ]),
      )),
    ];
  }

  Widget _contactBtn(IconData icon, String label, String url, Color color) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          FaIcon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: color.withOpacity(0.9), fontWeight: FontWeight.bold, fontSize: 13)),
        ]),
      ),
    );
  }

  Widget _specItem(String value, String label) {
    return Column(children: [
      Text(value, style: const TextStyle(color: _ice, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
      const SizedBox(height: 2),
      Text(label, style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 8, fontFamily: 'Orbitron', letterSpacing: 1)),
    ]);
  }
}