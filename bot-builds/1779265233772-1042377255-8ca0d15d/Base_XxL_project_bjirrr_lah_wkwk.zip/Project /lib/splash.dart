import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  bool _fadeOutStarted = false;

  // --- TEMA WARNA ICE BLUE ---
  final Color iceBlueLight = const Color(0xFFE1F5FE);   // Biru es sangat terang
  final Color iceBlue = const Color(0xFF4FC3F7);       // Biru es
  final Color iceBlueDark = const Color(0xFF0288D1);   // Biru es gelap
  final Color iceBlueDeep = const Color(0xFF01579B);   // Biru es dalam

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _fadeController = AnimationController(
          vsync: this,
          duration: const Duration(seconds: 1),
        );

        _videoController.addListener(() {
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (duration != null &&
              position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (position >= duration) {
            _navigateToDashboard();
          }
        });
      });
  }

  void _navigateToDashboard() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // --- VIDEO BACKGROUND FULL SCREEN ---
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF29B6F6)),
              ),
            ),

          // --- TEKS DENGAN TULISAN KECIL DI ATAS (warna ice blue) ---
          Positioned(
            bottom: 80,
            left: 0,
            right: 0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Tulisan kecil "Selamat datang di Apps XxL Project " - warna ice blue muda
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    "Selamat datang di Apps XxL Project ",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: iceBlueLight.withOpacity(0.9),
                      letterSpacing: 1.5,
                      fontStyle: FontStyle.italic,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 8,
                          offset: const Offset(1, 1),
                        ),
                        Shadow(
                          color: iceBlueDark.withOpacity(0.4),
                          blurRadius: 4,
                          offset: const Offset(0, 0),
                        ),
                      ],
                    ),
                  ),
                ),
                // Tulisan utama "XxL Project " - warna ice blue gelap dengan bayangan ice blue terang
                Text(
                  "XxL Project ",
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    color: iceBlueDeep,
                    letterSpacing: 3,
                    shadows: [
                      // Bayangan ice blue terang
                      Shadow(
                        color: iceBlue.withOpacity(0.8),
                        blurRadius: 15,
                        offset: const Offset(2, 2),
                      ),
                      // Bayangan ice blue gelap
                      Shadow(
                        color: iceBlueDeep.withOpacity(0.9),
                        blurRadius: 15,
                        offset: const Offset(-2, -2),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // --- FADE OUT OVERLAY ---
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
              child: Container(color: Colors.black),
            ),
        ],
      ),
    );
  }
}