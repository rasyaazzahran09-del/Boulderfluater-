import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late AnimationController _pulseAnim;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // Floating window variables
  bool _isFloatingWindowVisible = false;
  Offset _floatingWindowPosition = const Offset(20, 100);
  bool _isDragging = false;

  // === TEMA WARNA ICE BLUE ===
  final Color bgDark = Colors.black;
  final Color primaryDark = const Color(0xFF00101A);
  final Color accentDark = const Color(0xFF001F2E);
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = const Color(0xFF0A2A3A);
  final Color borderGlass = const Color(0xFF1E88E5);
  final Color accentIceBlue = const Color(0xFF42A5F5);
  final Color accentIceBlueGlow = const Color(0x5542A5F5);
  final Color accentIceBlueLight = const Color(0xFF90CAF9);
  final Color liveGreen = const Color(0xFF22C55E);
  
  final Color _iceBlue = const Color(0xFF42A5F5);
  final Color _iceBlueLight = const Color(0xFFB3E5FC);
  final Color _iceBlueDark = const Color(0xFF1565C0);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _pulseAnim = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _loadFloatingWindowPreference();
  }

  Future<void> _loadFloatingWindowPreference() async {
    final prefs = await SharedPreferences.getInstance();
    final isVisible = prefs.getBool('floating_window_visible_$username') ?? false;
    final posX = prefs.getDouble('floating_window_x_$username') ?? 20;
    final posY = prefs.getDouble('floating_window_y_$username') ?? 100;
    
    setState(() {
      _isFloatingWindowVisible = isVisible;
      _floatingWindowPosition = Offset(posX, posY);
    });
  }

  Future<void> _saveFloatingWindowPreference() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('floating_window_visible_$username', _isFloatingWindowVisible);
    await prefs.setDouble('floating_window_x_$username', _floatingWindowPosition.dx);
    await prefs.setDouble('floating_window_y_$username', _floatingWindowPosition.dy);
  }

  void _toggleFloatingWindow() {
    setState(() {
      _isFloatingWindowVisible = !_isFloatingWindowVisible;
    });
    _saveFloatingWindowPreference();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.VorlexzStars.my.id'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: primaryDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired",
            style: TextStyle(color: _iceBlueLight, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK",
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey, 
          userRole: role, 
          listDoos: listDoos,
          username: username,
          expiredDate: expiredDate,  // ← INI YANG DITAMBAHKAN
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      }
    });
    Navigator.pop(context);
  }

  // ===================== FLOATING WINDOW =====================
  Widget _buildFloatingWindow() {
    if (!_isFloatingWindowVisible) return const SizedBox.shrink();

    return Positioned(
      left: _floatingWindowPosition.dx,
      top: _floatingWindowPosition.dy,
      child: GestureDetector(
        onPanStart: (details) {
          setState(() {
            _isDragging = true;
          });
        },
        onPanUpdate: (details) {
          setState(() {
            _floatingWindowPosition = Offset(
              (_floatingWindowPosition.dx + details.delta.dx).clamp(0, MediaQuery.of(context).size.width - 120),
              (_floatingWindowPosition.dy + details.delta.dy).clamp(0, MediaQuery.of(context).size.height - 150),
            );
          });
        },
        onPanEnd: (details) {
          setState(() {
            _isDragging = false;
          });
          _saveFloatingWindowPreference();
        },
        child: Material(
          color: Colors.transparent,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  cardGlass,
                  primaryDark,
                ],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _isDragging ? accentIceBlue : borderGlass,
                width: _isDragging ? 2 : 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentIceBlueGlow,
                  blurRadius: _isDragging ? 20 : 10,
                  spreadRadius: _isDragging ? 2 : 1,
                ),
              ],
            ),
            child: Stack(
              children: [
                // Content
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: accentIceBlue.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.speed_rounded,
                        color: accentIceBlueLight,
                        size: 28,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "ONLINE",
                      style: TextStyle(
                        color: liveGreen,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "$onlineUsers Users",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    Text(
                      "$activeConnections Online",
                      style: TextStyle(
                        color: accentGrey,
                        fontSize: 8,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
                // Close button
                Positioned(
                  top: 4,
                  right: 4,
                  child: GestureDetector(
                    onTap: _toggleFloatingWindow,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.8),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 12,
                      ),
                    ),
                  ),
                ),
                // Drag indicator
                Positioned(
                  bottom: 4,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 2,
                    width: 30,
                    decoration: BoxDecoration(
                      color: accentGrey.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===================== AKSI CEPAT CARD =====================
  Widget _buildAksiCepatCard({
    required IconData icon,
    required Color iconColor,
    required Color iconBg,
    required String title,
    required String subtitle,
    required String buttonLabel,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderGlass, width: 1),
            boxShadow: [
              BoxShadow(
                color: accentIceBlueGlow,
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: iconBg,
                  shape: BoxShape.circle,
                  border: Border.all(color: iconColor.withOpacity(0.5)),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: accentGrey,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: accentIceBlue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: accentIceBlue.withOpacity(0.5)),
                ),
                child: Text(
                  buttonLabel,
                  style: TextStyle(
                    color: accentIceBlueLight,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===================== NEWS PAGE =====================
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),

          // === STATS CARD: Online & Koneksi + LIVE + FLOATING WINDOW TOGGLE ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderGlass, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: accentIceBlueGlow,
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(child: _buildStatItem(icon: Icons.people_alt_outlined, label: "Online", value: "$onlineUsers")),
                  Container(width: 1, height: 36, color: borderGlass),
                  Expanded(child: _buildStatItem(icon: Icons.wifi_rounded, label: "Koneksi", value: "$activeConnections")),
                  GestureDetector(
                    onTap: _toggleFloatingWindow,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: _isFloatingWindowVisible ? accentIceBlue.withOpacity(0.3) : liveGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: _isFloatingWindowVisible ? accentIceBlue.withOpacity(0.5) : liveGreen.withOpacity(0.5), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _isFloatingWindowVisible ? Icons.open_in_full : Icons.close_fullscreen,
                            color: _isFloatingWindowVisible ? accentIceBlueLight : liveGreen,
                            size: 14,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            _isFloatingWindowVisible ? "ON" : "OFF",
                            style: TextStyle(
                              color: _isFloatingWindowVisible ? accentIceBlueLight : liveGreen,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 22),

          // News Slider
          SizedBox(
            height: 200,
            child: newsList.isEmpty
                ? Center(child: Text("Tidak ada berita", style: TextStyle(color: accentGrey)))
                : PageView.builder(
                    controller: PageController(viewportFraction: 0.92),
                    itemCount: newsList.length,
                    itemBuilder: (context, index) {
                      final item = newsList[index];
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: cardGlass,
                          border: Border.all(color: borderGlass),
                          boxShadow: [BoxShadow(color: accentIceBlueGlow, blurRadius: 12, offset: const Offset(0, 5))],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (item['image'] != null && item['image'].toString().isNotEmpty) NewsMedia(url: item['image']),
                              Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black.withOpacity(0.7), Colors.transparent], begin: Alignment.bottomCenter, end: Alignment.topCenter))),
                              Positioned(
                                top: 12,
                                left: 12,
                                child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: accentIceBlue, borderRadius: BorderRadius.circular(6)), child: const Text("NEWS", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1))),
                              ),
                              Positioned(
                                top: 12,
                                right: 12,
                                child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(6)), child: Text("${index + 1}/${newsList.length}", style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'ShareTechMono'))),
                              ),
                              Positioned(
                                bottom: 14,
                                left: 14,
                                right: 14,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item['title'] ?? 'No Title', style: const TextStyle(color: Colors.white, fontSize: 15, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 3),
                                    Text(item['desc'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.7), fontFamily: "ShareTechMono", fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          const SizedBox(height: 24),

          // ── FEATURED WHATSAPP CRASH ──
          _sectionLabel("NEWS & UPDATES", isIceBlue: true),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => GestureDetector(
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("WhatsApp Crash Feature Coming Soon!")),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF001F2E), Color(0xFF0A3A5A), Color(0xFF00101A)],
                      begin: Alignment.topLeft, end: Alignment.bottomRight),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _iceBlue.withOpacity(0.6), width: 1.5),
                    boxShadow: [BoxShadow(color: _iceBlue.withOpacity(_pulseAnim.value * 0.3), blurRadius: 20, spreadRadius: 1)]),
                  child: Row(children: [
                    Container(padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: _iceBlue.withOpacity(0.15), shape: BoxShape.circle,
                        border: Border.all(color: _iceBlue.withOpacity(0.6)),
                        boxShadow: [BoxShadow(color: _iceBlue.withOpacity(_pulseAnim.value * 0.4), blurRadius: 12)]),
                      child: const Icon(FontAwesomeIcons.whatsapp, color: Color(0xFF42A5F5), size: 20)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text("WHATSAPP CRASH", style: TextStyle(color: _iceBlueLight, fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1,
                        shadows: [Shadow(color: _iceBlue.withOpacity(0.8), blurRadius: 8)])),
                      const SizedBox(height: 4),
                      Text("Send custom payloads to crash target WhatsApp.",
                        style: TextStyle(color: _iceBlue.withOpacity(0.7), fontSize: 10, fontFamily: 'ShareTechMono')),
                      const SizedBox(height: 8),
                      Row(children: [
                        _featureBadge("Bug", isIceBlue: true), const SizedBox(width: 4),
                        _featureBadge("Gacor", isIceBlue: true), const SizedBox(width: 4),
                        _featureBadge("Crash", isIceBlue: true),
                      ]),
                    ])),
                    Opacity(opacity: 0.08, child: const Icon(FontAwesomeIcons.whatsapp, color: Color(0xFF42A5F5), size: 55)),
                  ]),
                ),
              ),
            ),
          ),

          const SizedBox(height: 10),

          // Info Channel Card
          _buildAksiCepatCard(
            icon: FontAwesomeIcons.telegram,
            iconColor: const Color(0xFF29B6F6),
            iconBg: const Color(0xFF0D1A2E),
            title: "Info Channel",
            subtitle: "Join XxL Project Info Channel",
            buttonLabel: "Join",
            onTap: () => _openUrl("https://t.me/Bizzxx_Reals01"),
          ),

          const SizedBox(height: 10),

          // Bug Sender Card
          _buildAksiCepatCard(
            icon: Icons.wifi_tethering_rounded,
            iconColor: accentIceBlueLight,
            iconBg: const Color(0xFF0A2A3A),
            title: "Bug Sender",
            subtitle: "Kelola WhatsApp sender aktif",
            buttonLabel: "Buka",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  // ===================== STAT ITEM =====================
  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Icon(icon, color: accentGrey, size: 20),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: TextStyle(color: primaryWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
              Text(label, style: TextStyle(color: accentGrey, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  // ===================== SECTION LABEL =====================
  Widget _sectionLabel(String title, {bool isIceBlue = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 3, 
            height: 18, 
            decoration: BoxDecoration(
              color: isIceBlue ? _iceBlue : accentIceBlue, 
              borderRadius: BorderRadius.circular(4),
              boxShadow: [BoxShadow(color: isIceBlue ? _iceBlue.withOpacity(0.5) : accentIceBlueGlow, blurRadius: 8)]
            ),
          ),
          const SizedBox(width: 8),
          Text(title, 
            style: TextStyle(
              color: isIceBlue ? _iceBlueLight : Colors.white, 
              fontSize: 16, 
              fontWeight: FontWeight.bold, 
              fontFamily: 'Orbitron'
            ),
          ),
        ],
      ),
    );
  }

  // ===================== FEATURE BADGE =====================
  Widget _featureBadge(String text, {bool isIceBlue = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: isIceBlue ? _iceBlue.withOpacity(0.15) : _iceBlue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isIceBlue ? _iceBlue.withOpacity(0.5) : _iceBlue.withOpacity(0.3)),
      ),
      child: Text(text,
        style: TextStyle(
          color: isIceBlue ? _iceBlueLight : _iceBlueLight,
          fontSize: 9,
          fontFamily: 'ShareTechMono',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ===================== DRAWER =====================
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 250,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoController!.value.size.width,
                        height: _menuVideoController!.value.size.height,
                        child: VideoPlayer(_menuVideoController!),
                      ),
                    ),
                  ),
                Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(0.2), Colors.black.withOpacity(0.85)]))),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 90,
                          height: 90,
                          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: accentIceBlue, width: 2.5), boxShadow: [BoxShadow(color: accentIceBlueGlow, blurRadius: 18, spreadRadius: 2)]),
                          child: ClipOval(
                            child: _profileImage != null ? Image.file(_profileImage!, fit: BoxFit.cover) : Image.asset('assets/images/logo.png', fit: BoxFit.cover),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text("Halo, $username 👋", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(width: 7, height: 7, decoration: BoxDecoration(color: liveGreen, shape: BoxShape.circle)),
                            const SizedBox(width: 5),
                            Text("${role.toUpperCase()} · Exp: $expiredDate", style: TextStyle(color: accentGrey, fontSize: 12, fontFamily: 'ShareTechMono')),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: bgDark,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  if (role == "reseller") _buildDrawerMenuItem(icon: Icons.storefront, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin") _buildDrawerMenuItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "owner") _buildDrawerMenuItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.send_rounded,
                    label: "Manage Sender",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
                    },
                  ),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(
                    icon: Icons.logout,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.15) : cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isLogout ? Colors.red.withOpacity(0.4) : borderGlass),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : accentIceBlueLight, size: 22),
        title: Text(label, style: TextStyle(color: isLogout ? Colors.redAccent : primaryWhite, fontWeight: FontWeight.w600, fontSize: 15, fontFamily: 'Orbitron')),
        trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner": return Colors.white;
      case "vip": return Colors.white70;
      case "reseller": return Colors.lightGreenAccent;
      case "premium": return Colors.orangeAccent;
      default: return Colors.white54;
    }
  }

  // ===================== BUILD =====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: bgDark.withOpacity(0.92),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Halo, $username 👋", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
            Row(
              children: [
                Container(width: 6, height: 6, decoration: BoxDecoration(color: liveGreen, shape: BoxShape.circle)),
                const SizedBox(width: 5),
                Text("${role.toUpperCase()} · Exp: $expiredDate", style: TextStyle(color: accentGrey, fontSize: 11, fontFamily: 'ShareTechMono')),
              ],
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: accentIceBlue, width: 1.5), boxShadow: [BoxShadow(color: accentIceBlueGlow, blurRadius: 8)]),
              child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover)),
            ),
          ),
          IconButton(icon: Icon(Icons.headset_mic_outlined, color: primaryWhite), tooltip: 'Customer Service', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactPage()))),
          IconButton(icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.white), tooltip: 'My Profile', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [bgDark, primaryDark, bgDark])),
            child: SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),
          ),
          _buildFloatingWindow(),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: primaryDark, border: Border(top: BorderSide(color: borderGlass)), boxShadow: [BoxShadow(color: accentIceBlueGlow, blurRadius: 12, offset: const Offset(0, -2))]),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentIceBlueLight,
          unselectedItemColor: accentGrey,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 10),
          unselectedLabelStyle: const TextStyle(fontSize: 10, fontFamily: 'Orbitron'),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.campaign_outlined), label: "Info"),
            BottomNavigationBarItem(icon: Icon(Icons.tune_rounded), label: "Tools"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pulseAnim.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

// ===================== NEWS MEDIA WIDGET =====================
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!));
      } else {
        return const Center(child: CircularProgressIndicator(color: Colors.white));
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1A1A28), child: const Icon(Icons.broken_image, color: Colors.white38)),
      );
    }
  }
}