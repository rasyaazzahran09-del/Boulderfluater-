import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// Import halaman lain (asumsikan sudah ada)
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'custom_bug.dart';
import 'chat_page.dart';
import 'status_page.dart';

// ═══════════════════════════════════════════════════════════════════════════════
//  COLOR TOKENS - ENHANCED PALETTE
// ═══════════════════════════════════════════════════════════════════════════════
class AppTheme {
  // Primary - Medium Blue
  static const Color primary = Color(0xFF1E88E5);
  static const Color primaryDim = Color(0xFF1565C0);
  static const Color primaryGlow = Color(0x1A1E88E5);
  
  // Backgrounds - Pure Black
  static const Color bgDark = Color(0xFF000000);
  static const Color bgSurface = Color(0xFF0A0A0A);
  static const Color bgCard = Color(0xFF111111);
  static const Color bgGlass = Color(0x99111111);
  
  // Text
  static const Color textWhite = Color(0xFFF8FAFC);
  static const Color textGrey = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFF64748B);
  
  // Accents
  static const Color accentGreen = Color(0xFF10B981);
  static const Color accentOrange = Color(0xFFF59E0B);
  static const Color accentRed = Color(0xFFEF4444);
  static const Color accentPurple = Color(0xFF8B5CF6);
  static const Color accentPink = Color(0xFFEC4899);
  
  // Borders
  static const Color borderSubtle = Color(0x1AFFFFFF);
  static const Color borderGlow = Color(0x401E88E5);
  
  // Gradients
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF1E88E5), Color(0xFF1565C0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient darkGradient = LinearGradient(
    colors: [Color(0xFF0A0A0A), Color(0xFF000000)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

class _C {
  static const cyan      = Color(0xFF1E88E5); // biru medium, tidak terlalu terang
  static const cyanDim   = Color(0xFF1565C0); // biru lebih tua
  static const cyanGlow  = Color(0x1A1E88E5);
  static const bg        = Color(0xFF000000); // hitam murni
  static const surface   = Color(0xFF0A0A0A); // hitam sangat gelap
  static const card      = Color(0xFF111111); // hitam kartu
  static const border    = Color(0x1AFFFFFF);
  static const white     = Color(0xFFF8FAFC);
  static const grey      = Color(0xFF94A3B8);
  static const orange    = Color(0xFFF59E0B);
  static const green     = Color(0xFF10B981);
  static const blue      = Color(0xFF1E88E5); // biru medium
  static const amber     = Color(0xFFFBBF24);
  static const red       = Color(0xFFEF4444);
  static const purple    = Color(0xFF8B5CF6);
  static const pink      = Color(0xFFEC4899);
  static const textMuted = Color(0xFF64748B);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MAIN DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // Animation Controllers
  late final AnimationController _mainAnimCtrl;
  late final AnimationController _glowCtrl;
  late final Animation<double> _fadeAnim;
  late final Animation<Offset> _slideAnim;
  late final Animation<double> _glowAnim;

  // State Variables
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = 'unknown';
  File? profileImage;
  int bottomNavIndex = 0;
  Widget selectedPage = const SizedBox.shrink();
  int onlineUsers = 0;
  int activeConnections = 0;
  List<Map<String, dynamic>> recentActivities = [];
  
  WebSocketChannel? _channel;
  VideoPlayerController? _brandVideoController;
  bool _brandVideoReady = false;
  VideoPlayerController? _badgeVideoController;
  bool _badgeVideoReady = false;
  VideoPlayerController? _headerVideoController;
  bool _headerVideoReady = false;
  
  // News State
  static const _apiBase = 'https://app.siputzx.my.id';
  bool isLoadingNews = false;
  String newsError = '';
  bool _speedDialOpen = false;
  
  // Prayer State
  bool isLoadingPrayer = false;
  String prayerError = '';
  String prayerCity = 'Jakarta';
  String nextPrayerName = '-';
  String nextPrayerCountdown = '--:--:--';
  String activePrayerName = '';
  Timer? _prayerTicker;
  DateTime? _nextPrayerTime;
  Map<String, String> prayerTimes = {
    'Subuh': '--:--',
    'Dzuhur': '--:--',
    'Ashar': '--:--',
    'Maghrib': '--:--',
    'Isya': '--:--',
  };

  // Typing Effect
  String _typedText = '';
  int _typingCharIndex = 0;
  bool _typingDeleting = false;
  bool _typingActive = true;
  String get _fullText => 'HELLO, $username';

  @override
  void initState() {
    super.initState();
    
    // Initialize state from widget
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    selectedPage = _buildDashboard();

    // Setup Animations
    _setupAnimations();
    
    // Initialize Features
    _startTyping();
    _initBrandVideo();
    _initBadgeVideo();
    _initHeaderVideo();
    _loadRecentActivities();
    _initDeviceAndConnect();
    _loadProfileImage();
    _fetchLatestNews();
    _fetchPrayerSchedule(city: prayerCity);
  }

  void _setupAnimations() {
    _mainAnimCtrl = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..forward();

    _glowCtrl = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnim = CurvedAnimation(
      parent: _mainAnimCtrl,
      curve: Curves.easeOutCubic,
    );

    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.05),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _mainAnimCtrl,
      curve: Curves.easeOutCubic,
    ));

    _glowAnim = Tween<double>(begin: 0.3, end: 0.8).animate(CurvedAnimation(
      parent: _glowCtrl,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _mainAnimCtrl.dispose();
    _glowCtrl.dispose();
    _prayerTicker?.cancel();
    _brandVideoController?.dispose();
    _badgeVideoController?.dispose();
    _channel?.sink.close(status.goingAway);
    _typingActive = false;
    _headerVideoController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  TYPING EFFECT LOGIC
  // ═══════════════════════════════════════════════════════════════════════════
  void _startTyping() {
    _typedText = '';
    _typingCharIndex = 0;
    _typingDeleting = false;
    _typingActive = true;
    Future.delayed(const Duration(milliseconds: 300), _animateTyping);
  }

  void _animateTyping() {
    if (!_typingActive || !mounted) return;

    if (!_typingDeleting) {
      if (_typingCharIndex < _fullText.length) {
        setState(() => _typedText = _fullText.substring(0, ++_typingCharIndex));
        Future.delayed(Duration(milliseconds: 50 + math.Random().nextInt(80)), _animateTyping);
      } else {
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted && _typingActive) {
            _typingDeleting = true;
            _animateTyping();
          }
        });
      }
    } else {
      if (_typingCharIndex > 0) {
        setState(() => _typedText = _fullText.substring(0, --_typingCharIndex));
        Future.delayed(const Duration(milliseconds: 25), _animateTyping);
      } else {
        _typingDeleting = false;
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted && _typingActive) _animateTyping();
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  BRAND VIDEO INITIALIZATION
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _initBrandVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/videos/landing.mp4');
      _brandVideoController = controller;
      
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      
      if (mounted) setState(() => _brandVideoReady = true);
    } catch (e) {
      debugPrint('Video Error: $e');
      if (mounted) setState(() => _brandVideoReady = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  BADGE VIDEO INITIALIZATION
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _initBadgeVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/videos/palu.mp4');
      _badgeVideoController = controller;
      
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      
      if (mounted) setState(() => _badgeVideoReady = true);
    } catch (e) {
      debugPrint('Badge Video Error: $e');
      if (mounted) setState(() => _badgeVideoReady = false);
    }
  }

  Future<void> _initHeaderVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/videos/atas.mp4');
      _headerVideoController = controller;
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      if (mounted) setState(() => _headerVideoReady = true);
    } catch (e) {
      debugPrint('Header Video Error: $e');
      if (mounted) setState(() => _headerVideoReady = false);
    }
  }

  Widget _buildBadgeVideo() {
    if (_badgeVideoReady && _badgeVideoController != null && _badgeVideoController!.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _badgeVideoController!.value.size.width,
          height: _badgeVideoController!.value.size.height,
          child: VideoPlayer(_badgeVideoController!),
        ),
      );
    }
    return Container(
      width: 40,
      height: 40,
      decoration: const BoxDecoration(
        color: _C.blue,
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: const Icon(Icons.videocam_rounded, color: _C.white, size: 18),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  NEWS FETCHING LOGIC
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchLatestNews() async {
    if (!mounted) return;
    setState(() { isLoadingNews = true; newsError = ''; });

    final endpoints = [
      '$_apiBase/api/berita/terbaru',
      '$_apiBase/api/berita/cnnindonesia',
      '$_apiBase/api/berita/kompas',
      '$_apiBase/api/news/terbaru',
      '$_apiBase/api/cnn/terbaru',
    ];

    for (final ep in endpoints) {
      try {
        final res = await http.get(Uri.parse(ep)).timeout(const Duration(seconds: 8));
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final raw = jsonDecode(res.body);
          final list = _extractList(raw);
          final normed = list.map(_normalizeNews).where((e) => 
            (e['title'] ?? '').toString().trim().isNotEmpty
          ).toList();
          
          if (normed.isNotEmpty && mounted) {
            setState(() { 
              newsList = normed; 
              isLoadingNews = false; 
            });
            return;
          }
        }
      } catch (e) {
        debugPrint('News fetch error [$ep]: $e');
      }
    }

    if (mounted) {
      setState(() {
        isLoadingNews = false;
        newsError = 'Berita tidak tersedia saat ini';
        if (newsList.isEmpty && widget.news.isNotEmpty) {
          newsList = widget.news;
        }
      });
    }
  }

  List<dynamic> _extractList(dynamic d) {
    if (d is List) return d;
    if (d is Map) {
      for (final k in ['data', 'result', 'articles', 'news']) {
        final v = d[k];
        if (v is List) return v;
      }
    }
    return [];
  }

  Map<String, dynamic> _normalizeNews(dynamic item) {
    if (item is! Map) return {'title': item.toString(), 'desc': '', 'image': '', 'url': ''};
    
    String pick(List<String> keys) {
      for (final k in keys) {
        final v = item[k];
        if (v != null && v.toString().trim().isNotEmpty) return v.toString();
      }
      return '';
    }

    return {
      'title': pick(['title', 'judul', 'name']),
      'desc': pick(['description', 'summary', 'content']),
      'image': pick(['image', 'thumbnail', 'urlToImage']),
      'url': pick(['url', 'link', 'source']),
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  PRAYER SCHEDULE LOGIC
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _fetchPrayerSchedule({required String city}) async {
    if (!mounted) return;
    setState(() { 
      isLoadingPrayer = true; 
      prayerError = ''; 
      prayerCity = city; 
    });

    try {
      final now = DateTime.now();
      final uri = Uri.parse(
        'https://api.aladhan.com/v1/timingsByCity/${now.millisecondsSinceEpoch ~/ 1000}'
        '?city=${Uri.encodeComponent(city)}&country=Indonesia&method=20'
      );

      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode < 200 || res.statusCode >= 300) throw Exception('HTTP ${res.statusCode}');

      final decoded = jsonDecode(res.body);
      final timings = decoded['data']?['timings'];
      if (timings == null) throw Exception('Invalid format');

      final updated = <String, String>{
        'Subuh': _cleanTime(timings['Fajr']),
        'Dzuhur': _cleanTime(timings['Dhuhr']),
        'Ashar': _cleanTime(timings['Asr']),
        'Maghrib': _cleanTime(timings['Maghrib']),
        'Isya': _cleanTime(timings['Isha']),
      };

      if (mounted) {
        setState(() { 
          prayerTimes = updated; 
          isLoadingPrayer = false; 
        });
        _updateNextPrayer();
        _startPrayerTicker();
      }
    } catch (e) {
      debugPrint('Prayer error: $e');
      if (mounted) {
        setState(() {
          isLoadingPrayer = false;
          prayerError = 'Gagal memuat jadwal sholat';
        });
      }
    }
  }

  String _cleanTime(dynamic v) {
    if (v == null) return '--:--';
    final match = RegExp(r'\d{1,2}:\d{2}').firstMatch(v.toString());
    return match?.group(0)?.padLeft(5, '0') ?? '--:--';
  }

  void _startPrayerTicker() {
    _prayerTicker?.cancel();
    _prayerTicker = Timer.periodic(const Duration(seconds: 1), (_) => _updateNextPrayer());
  }

  DateTime? _timeToday(String v) {
    if (!RegExp(r'^\d{1,2}:\d{2}$').hasMatch(v)) return null;
    final now = DateTime.now();
    final parts = v.split(':');
    return DateTime(now.year, now.month, now.day, int.parse(parts[0]), int.parse(parts[1]));
  }

  void _updateNextPrayer() {
    final now = DateTime.now();
    final schedule = prayerTimes.entries
        .map((e) => MapEntry(e.key, _timeToday(e.value)))
        .where((e) => e.value != null)
        .map((e) => MapEntry(e.key, e.value!))
        .toList();

    if (schedule.isEmpty) return;

    MapEntry<String, DateTime>? next;
    String active = schedule.first.key;

    for (final e in schedule) {
      if (!e.value.isAfter(now)) active = e.key;
      if (e.value.isAfter(now) && next == null) next = e;
    }

    next ??= MapEntry(schedule.first.key, schedule.first.value.add(const Duration(days: 1)));
    final diff = next.value.difference(now);

    if (mounted) {
      setState(() {
        activePrayerName = active;
        nextPrayerName = next!.key;
        nextPrayerCountdown = '${diff.inHours.toString().padLeft(2, '0')}:${(diff.inMinutes % 60).toString().padLeft(2, '0')}:${(diff.inSeconds % 60).toString().padLeft(2, '0')}';
        _nextPrayerTime = next.value;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  PROFILE & ACTIVITIES
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final path = prefs.getString('profile_image_$username');
      if (path != null && path.isNotEmpty && mounted) {
        setState(() => profileImage = File(path));
      }
    } catch (e) {
      debugPrint('Profile image load error: $e');
    }
  }

  Future<void> _loadRecentActivities() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList('recent_activities_$username') ?? [];
      if (mounted) {
        setState(() {
          recentActivities = raw
              .map((a) => jsonDecode(a) as Map<String, dynamic>)
              .toList();
        });
      }
    } catch (e) {
      debugPrint('Activities load error: $e');
    }
  }

  Future<void> _addRecentActivity(String action, String detail) async {
    final entry = {
      'action': action,
      'detail': detail,
      'time': DateTime.now().toIso8601String(),
    };
    
    if (mounted) {
      setState(() {
        recentActivities.insert(0, entry);
        if (recentActivities.length > 20) {
          recentActivities = recentActivities.take(20).toList();
        }
      });
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
        'recent_activities_$username',
        recentActivities.map(jsonEncode).toList(),
      );
    } catch (e) {
      debugPrint('Save activity error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  WEBSOCKET & DEVICE
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _initDeviceAndConnect() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      _connectWS();
    } catch (e) {
      debugPrint('Device info error: $e');
    }
  }

  void _connectWS() {
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('wss://ws-queen.official.com'),
      );

      _channel!.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));

      _channel!.sink.add(jsonEncode({'type': 'stats'}));

      _channel!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data['type'] == 'myInfo' && data['valid'] == false) {
              _handleInvalidSession(data['reason'] == 'androidIdMismatch'
                  ? 'Akun Anda telah login di perangkat lain.'
                  : 'Session tidak valid. Silakan login kembali.');
            }
            if (data['type'] == 'stats' && mounted) {
              setState(() {
                onlineUsers = data['onlineUsers'] ?? 0;
                activeConnections = data['activeConnections'] ?? 0;
              });
            }
          } catch (e) {
            debugPrint('WS parse error: $e');
          }
        },
        onError: (e) => debugPrint('WS error: $e'),
        onDone: () => debugPrint('WS closed'),
      );
    } catch (e) {
      debugPrint('WS connect error: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  HELPERS & NAVIGATION
  // ═══════════════════════════════════════════════════════════════════════════
  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
      await _addRecentActivity('Membuka Link', url);
    }
  }

  String _formatTime(DateTime t) {
    final diff = DateTime.now().difference(t);
    if (diff.inDays > 0) return '${diff.inDays}h lalu';
    if (diff.inHours > 0) return '${diff.inHours}j lalu';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m lalu';
    return 'Baru saja';
  }

  void _handleInvalidSession(String msg) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _StyledDialog(
        icon: Icons.warning_amber_rounded,
        iconColor: _C.orange,
        title: 'Session Expired',
        content: Text(msg, style: const TextStyle(color: _C.grey)),
        actions: [
          _CyanButton(
            label: 'Login Ulang',
            onTap: () => Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (r) => false,
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int idx) {
    if (!mounted) return;
    setState(() {
      bottomNavIndex = idx;
      switch (idx) {
        case 0:
          selectedPage = _buildDashboard();
          break;
        case 1:
          // Chat
          selectedPage = ChatHubPage(
            sessionKey: sessionKey,
            username: username,
          );
          break;
        case 2:
          _showHomeSpeedDial();
          return;
        case 3:
          // Status
          selectedPage = StatusPage(
            sessionKey: sessionKey,
            username: username,
          );
          break;
        case 4:
          selectedPage = RiwayatPage(
            sessionKey: sessionKey,
            role: role,
          );
          break;
        case 5:
          selectedPage = BugSenderPage(
            username: username,
            sessionKey: sessionKey,
            role: role,
          );
          break;
        default:
          selectedPage = _buildDashboard();
      }
    });
  }

  void _showHomeSpeedDial() {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'SpeedDial',
      barrierColor: Colors.black.withOpacity(0.65),
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (_, anim, __) {
        return _HomeSpeedDial(
          animation: anim,
          onGroup: () {
            Navigator.pop(context);
            Navigator.push(context, _createRoute(HomePage(
              username: username,
              password: password,
              sessionKey: sessionKey,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
            )));
          },
          onContact: () {
            Navigator.pop(context);
            Navigator.push(context, _createRoute(BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            )));
          },
          onCustom: () {
            Navigator.pop(context);
            Navigator.push(context, _createRoute(CustomAttackPage(
              sessionKey: sessionKey,
              username: username,
              password: password,
              role: role,
              listBug: listBug,
              expiredDate: expiredDate,
            )));
          },
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return FadeTransition(
          opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
          child: child,
        );
      },
    );
  }

  void _onDrawerTabSelected(int idx) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 200), () {
      if (!mounted) return;
      setState(() {
        bottomNavIndex = 1;
        switch (idx) {
          case 1:
            selectedPage = SellerPage(keyToken: sessionKey);
            break;
          case 2:
            selectedPage = AdminPage(sessionKey: sessionKey);
            break;
          case 3:
            selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
            break;
        }
      });
    });
  }

  Route _createRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1.0, 0.0),
            end: Offset.zero,
          ).animate(CurvedAnimation(
            parent: animation,
            curve: Curves.easeInOutCubic,
          )),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 350),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  BUILD METHOD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.8,
            colors: [
              Color(0x0D1E88E5),
              Color(0xFF000000),
              Color(0xFF000000),
            ],
          ),
        ),
        child: SafeArea(
          child: AnimatedBuilder(
            animation: Listenable.merge([_fadeAnim, _slideAnim]),
            builder: (context, child) {
              return FadeTransition(
                opacity: _fadeAnim,
                child: SlideTransition(
                  position: _slideAnim,
                  child: bottomNavIndex == 0 ? _buildDashboard() : selectedPage,
                ),
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ── APP BAR (Full Video Header - no text, buttons overlay) ──
  PreferredSizeWidget _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(80),
      child: Builder(
        builder: (ctx) => Stack(
          children: [
            // ── Full video background ──
            SizedBox(
              width: double.infinity,
              height: 80,
              child: (_headerVideoReady &&
                      _headerVideoController != null &&
                      _headerVideoController!.value.isInitialized)
                  ? FittedBox(
                      fit: BoxFit.cover,
                      clipBehavior: Clip.hardEdge,
                      child: SizedBox(
                        width: _headerVideoController!.value.size.width,
                        height: _headerVideoController!.value.size.height,
                        child: VideoPlayer(_headerVideoController!),
                      ),
                    )
                  : Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF000000), Color(0xFF111111)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: const Center(
                        child: Icon(Icons.play_circle_outline,
                            color: _C.cyan, size: 28),
                      ),
                    ),
            ),

            // ── Dark gradient overlay (top fade for status bar) ──
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.45),
                      Colors.transparent,
                      Colors.black.withOpacity(0.3),
                    ],
                  ),
                ),
              ),
            ),

            // ── Buttons overlay (right side, vertically centred) ──
            Positioned(
              right: 10,
              top: 0,
              bottom: 0,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Menu
                  _AppBarIconBtn(
                    icon: Icons.menu_rounded,
                    onTap: () => Scaffold.of(ctx).openDrawer(),
                  ),
                  const SizedBox(width: 6),
                  // Profile
                  _AppBarIconBtn(
                    icon: Icons.person_outline_rounded,
                    onTap: () => Navigator.push(
                      ctx,
                      _createRoute(ProfilePage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey,
                      )),
                    ),
                  ),
                  const SizedBox(width: 6),
                  // Settings
                  _AppBarIconBtn(
                    icon: Icons.settings_outlined,
                    onTap: () {},
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── BOTTOM NAVIGATION ──
  Widget _buildBottomNav() {
    const navItems = [
      _NavItem(icon: Icons.dashboard_rounded,              label: 'Home',    color: _C.cyan),
      _NavItem(icon: Icons.chat_bubble_rounded,            label: 'Chat',    color: _C.blue),
      _NavItem(icon: Icons.home_rounded,                   label: 'HomePage',color: _C.blue),
      _NavItem(icon: Icons.circle_notifications_rounded,   label: 'Status',  color: _C.green),
      _NavItem(icon: Icons.history_rounded,                label: 'Riwayat', color: Color(0xFFF59E0B)),
      _NavItem(icon: Icons.bug_report_rounded,             label: 'Bug',     color: _C.red),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF050505).withOpacity(0.98),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _C.cyan.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: _C.cyan.withOpacity(0.08),
            blurRadius: 24,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(navItems.length, (i) {
          return _BubbleNavItem(
            item: navItems[i],
            isSelected: bottomNavIndex == i,
            onTap: () => _onBottomNavTapped(i),
          );
        }),
      ),
    );
  }

  // ── DRAWER ──
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: _C.bg,
      width: MediaQuery.of(context).size.width * 0.85,
      child: Column(
        children: [
          // Header
          Container(
            height: 240,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF080808),
                  Color(0xFF000000),
                ],
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Avatar
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [_C.cyan, _C.blue],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _C.cyan.withOpacity(0.3),
                            blurRadius: 25,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: profileImage != null
                            ? Image.file(profileImage!, fit: BoxFit.cover)
                            : Icon(
                                FontAwesomeIcons.userAstronaut,
                                size: 38,
                                color: _C.bg,
                              ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      username,
                      style: const TextStyle(
                        color: _C.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                      decoration: BoxDecoration(
                        color: _C.cyan.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _C.cyan.withOpacity(0.3)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: _C.cyan,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Menu Items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 20),
              children: [
                // ── AKSES CEPAT (di atas garis 3) ──
                _drawerItem(Icons.storefront_rounded, 'Seller Page', () => _onDrawerTabSelected(1),
                    color: _C.cyan),
                _drawerItem(Icons.admin_panel_settings_rounded, 'Admin Page', () => _onDrawerTabSelected(2),
                    color: _C.cyan),

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  child: Divider(color: Colors.white10),
                ),

                // ── MENU UTAMA ──
                if (role == 'reseller')
                  _drawerItem(Icons.storefront_rounded, 'Seller Page (Role)', () => _onDrawerTabSelected(1)),
                if (role == 'admin')
                  _drawerItem(Icons.admin_panel_settings_rounded, 'Admin Page (Role)', () => _onDrawerTabSelected(2)),
                if (role == 'owner')
                  _drawerItem(Icons.workspace_premium_rounded, 'Owner Page', () => _onDrawerTabSelected(3)),

                _drawerItem(Icons.history_rounded, 'Riwayat Aktivitas', () {
                  Navigator.pop(context);
                  Navigator.push(context, _createRoute(RiwayatPage(sessionKey: sessionKey, role: role)));
                }),

                _drawerItem(Icons.store_rounded, 'Marketplace', () {
                  Navigator.pop(context);
                  Navigator.push(context, _createRoute(MarketplacePage(sessionKey: sessionKey, username: username, role: role)));
                }),

                _drawerItem(Icons.person_rounded, 'Profile', () {
                  Navigator.pop(context);
                  Navigator.push(context, _createRoute(ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)));
                }),

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  child: Divider(color: Colors.white10),
                ),

                _drawerItem(Icons.logout_rounded, 'Log Out', () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (r) => false,
                  );
                }, isLogout: true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String label, VoidCallback onTap, {bool isLogout = false, Color? color}) {
    final itemColor = color ?? _C.cyan;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: isLogout ? _C.red.withOpacity(0.08) : _C.surface.withOpacity(0.5),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isLogout ? _C.red.withOpacity(0.2) : itemColor.withOpacity(0.25),
        ),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? _C.red : itemColor, size: 20),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? _C.red : _C.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: isLogout ? null : const Icon(Icons.arrow_forward_ios_rounded, color: _C.grey, size: 14),
        onTap: onTap,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  DASHBOARD CONTENT BUILDER
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildDashboard() {
    return Stack(
      children: [
        // Background Grid
        Positioned.fill(
          child: CustomPaint(
            painter: _GridPainter(color: _C.cyan.withOpacity(0.03), spacing: 28),
          ),
        ),
        
        // Floating Orbs
        Positioned(top: 100, left: -80, child: _orb(_C.cyan.withOpacity(0.08), 180)),
        Positioned(bottom: 200, right: -60, child: _orb(_C.purple.withOpacity(0.06), 140)),

        // Main Content
        SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              
              // Hero Brand Section
              _buildHeroSection(),
              const SizedBox(height: 24),

              // User Info Card
              _buildUserCard(),
              const SizedBox(height: 24),

              // Stats Row
              _buildStatsRow(),
              const SizedBox(height: 24),

              // Feature Card
              _buildFeatureCard(),
              const SizedBox(height: 24),

              // Prayer Section
              _buildPrayerSection(),
              const SizedBox(height: 24),

              // Quick Actions
              _buildSectionHeader(Icons.flash_on_rounded, 'MENU UTAMA'),
              const SizedBox(height: 14),
              _buildQuickActions(),
              const SizedBox(height: 24),

              // News Section
              _buildSectionHeader(Icons.newspaper_rounded, 'BERITA TERKINI', trailing: _newsBadge()),
              const SizedBox(height: 14),
              _buildNewsSection(),
              const SizedBox(height: 16),

              // Bug Image Banner
              _buildBugBanner(),
              const SizedBox(height: 24),

              // Recent Activity
              _buildSectionHeader(Icons.history_rounded, 'AKTIVITAS TERKINI'),
              const SizedBox(height: 14),
              _buildActivitySection(),
              const SizedBox(height: 16),

              // Blessing Card
              _buildBlessingCard(),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ],
    );
  }

  // ── HERO SECTION ──
  Widget _buildHeroSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 220,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: _C.surface,
        border: Border.all(color: _C.cyan.withOpacity(0.25)),
        boxShadow: [
          BoxShadow(
            color: _C.cyan.withOpacity(0.15),
            blurRadius: 32,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video Background
            if (_brandVideoReady && _brandVideoController != null && _brandVideoController!.value.isInitialized)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _brandVideoController!.value.size.width,
                    height: _brandVideoController!.value.size.height,
                    child: VideoPlayer(_brandVideoController!),
                  ),
                ),
              )
            else
              // Fallback dark gradient saat video belum siap
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF050505), Color(0xFF000000)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ),

            // Dark overlay agar VTX badge terlihat jelas
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.black.withOpacity(0.25),
                      Colors.black.withOpacity(0.15),
                    ],
                  ),
                ),
              ),
            ),

            // Hanya label VTX SYSTEM ACTIVE di pojok kiri bawah
            Positioned(
              left: 20,
              bottom: 20,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: _C.cyan.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _C.cyan.withOpacity(0.5), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.3),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Text(
                  'VTX SYSTEM ACTIVE',
                  style: TextStyle(
                    color: _C.cyan,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── USER CARD ──
  Widget _buildUserCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(0.9),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.cyan.withOpacity(0.15)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Avatar
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [_C.cyan, _C.blue]),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.3),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/profile.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => const Icon(
                      Icons.verified_user_rounded,
                      color: _C.bg,
                      size: 32,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              // Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Selamat Datang',
                      style: TextStyle(
                        color: _C.grey,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            username,
                            style: const TextStyle(
                              color: _C.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: _C.blue,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.check_rounded,
                            color: _C.white,
                            size: 12,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: _C.blue.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.blue.withOpacity(0.3)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: _C.blue,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Video di ruang kosong sebelah kanan
              const SizedBox(width: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: 72,
                  height: 80,
                  child: _buildBadgeVideo(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Divider(color: _C.border.withOpacity(0.5)),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Expired: $expiredDate',
                style: const TextStyle(
                  color: _C.grey,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              GestureDetector(
                onTap: () => _openUrl('https://t.me/keiraamd'),
                child: Row(
                  children: [
                    const Text(
                      'Upgrade Role?',
                      style: TextStyle(
                        color: _C.cyan,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Icon(
                      Icons.arrow_forward_rounded,
                      color: _C.cyan,
                      size: 14,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── STATS ROW ──
  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(child: _statCard(Icons.people_alt_rounded, 'Online Users', '$onlineUsers', _C.cyan)),
          const SizedBox(width: 12),
          Expanded(child: _statCard(Icons.link_rounded, 'Connections', '$activeConnections', _C.green)),
        ],
      ),
    );
  }

  Widget _statCard(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(0.8),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, color: color, size: 22),
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                  boxShadow: [BoxShadow(color: color, blurRadius: 8)],
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              color: _C.white,
              fontSize: 26,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: _C.grey,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ── FEATURE CARD ──
  Widget _buildFeatureCard() {
    return GestureDetector(
      onTap: () => Navigator.push(context, _createRoute(HomePage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      ))),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF10B981), Color(0xFF059669), Color(0xFF047857)],
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: _C.green.withOpacity(0.25),
              blurRadius: 25,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -20,
              top: -20,
              child: Icon(
                FontAwesomeIcons.whatsapp,
                size: 120,
                color: Colors.white.withOpacity(0.1),
              ),
            ),
            Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withOpacity(0.3)),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.whatsapp,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'WhatsApp Bug Sender',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Kirim bug ke WhatsApp dengan mudah',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'AKTIF • TAP TO OPEN',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── PRAYER SECTION ──
  Widget _buildPrayerSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF7C3AED).withOpacity(0.18),
            const Color(0xFFF59E0B).withOpacity(0.10),
            _C.surface.withOpacity(0.95),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFF7C3AED).withOpacity(0.35), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7C3AED).withOpacity(0.2),
            blurRadius: 28,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF7C3AED), Color(0xFFF59E0B)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF7C3AED).withOpacity(0.4),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: const Icon(Icons.mosque_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'JADWAL SHOLAT',
                      style: TextStyle(
                        color: _C.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.orange.withOpacity(0.25),
                      _C.orange.withOpacity(0.10),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.orange.withOpacity(0.5)),
                ),
                child: Text(
                  '$nextPrayerName • $nextPrayerCountdown',
                  style: const TextStyle(
                    color: _C.orange,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),

          // Prayer Times Grid - colorful
          Row(
            children: [
              _prayerTile(Icons.nights_stay_rounded, 'SUBUH', prayerTimes['Subuh']!, 'Subuh'),
              _prayerTile(Icons.wb_sunny_rounded, 'DZUHUR', prayerTimes['Dzuhur']!, 'Dzuhur'),
              _prayerTile(Icons.cloud_rounded, 'ASHAR', prayerTimes['Ashar']!, 'Ashar'),
              _prayerTile(Icons.dark_mode_rounded, 'MAGHRIB', prayerTimes['Maghrib']!, 'Maghrib'),
              _prayerTile(Icons.bedtime_rounded, 'ISYA', prayerTimes['Isya']!, 'Isya'),
            ],
          ),
          const SizedBox(height: 16),

          // City Selector
          GestureDetector(
            onTap: _showCityPicker,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 13),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF7C3AED).withOpacity(0.15),
                    _C.cyan.withOpacity(0.08),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _C.cyan.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.location_on_rounded, color: _C.cyan, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    prayerCity.toUpperCase(),
                    style: const TextStyle(
                      color: _C.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.keyboard_arrow_down_rounded, color: _C.grey, size: 18),
                ],
              ),
            ),
          ),

          if (isLoadingPrayer || prayerError.isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(
                  isLoadingPrayer ? Icons.sync_rounded : Icons.error_outline_rounded,
                  color: isLoadingPrayer ? _C.cyan : _C.orange,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    isLoadingPrayer ? 'Memuat jadwal...' : prayerError,
                    style: TextStyle(
                      color: isLoadingPrayer ? _C.cyan : _C.orange,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (!isLoadingPrayer && prayerError.isNotEmpty)
                  GestureDetector(
                    onTap: () => _fetchPrayerSchedule(city: prayerCity),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.cyan.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'Retry',
                        style: TextStyle(color: _C.cyan, fontSize: 10, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _prayerTile(IconData icon, String label, String time, String key) {
    final isActive = activePrayerName == key;

    // Warna unik tiap waktu sholat
    final Color tileColor;
    final Color tileColorLight;
    switch (key) {
      case 'Subuh':
        tileColor      = const Color(0xFF818CF8); // indigo
        tileColorLight = const Color(0xFFE0E7FF);
        break;
      case 'Dzuhur':
        tileColor      = const Color(0xFFF59E0B); // amber
        tileColorLight = const Color(0xFFFEF3C7);
        break;
      case 'Ashar':
        tileColor      = const Color(0xFF10B981); // emerald
        tileColorLight = const Color(0xFFD1FAE5);
        break;
      case 'Maghrib':
        tileColor      = const Color(0xFFEC4899); // pink
        tileColorLight = const Color(0xFFFCE7F3);
        break;
      case 'Isya':
        tileColor      = const Color(0xFF8B5CF6); // violet
        tileColorLight = const Color(0xFFEDE9FE);
        break;
      default:
        tileColor      = _C.cyan;
        tileColorLight = const Color(0xFFCFFAFE);
    }

    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isActive
                ? [tileColor.withOpacity(0.55), tileColor.withOpacity(0.30)]
                : [tileColor.withOpacity(0.22), tileColor.withOpacity(0.10)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isActive ? tileColor : tileColor.withOpacity(0.55),
            width: isActive ? 2.0 : 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: tileColor.withOpacity(isActive ? 0.45 : 0.20),
              blurRadius: isActive ? 16 : 8,
              spreadRadius: isActive ? 1 : 0,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon dengan background bulat berwarna
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: isActive
                    ? tileColor.withOpacity(0.35)
                    : tileColor.withOpacity(0.18),
                shape: BoxShape.circle,
                border: Border.all(
                  color: tileColor.withOpacity(isActive ? 0.8 : 0.4),
                  width: 1,
                ),
              ),
              child: Icon(
                icon,
                color: isActive ? Colors.white : tileColor,
                size: 14,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? Colors.white : tileColor,
                fontSize: 7.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              time,
              style: TextStyle(
                color: isActive ? Colors.white : tileColorLight,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCityPicker() {
    final ctrl = TextEditingController(text: prayerCity);
    showDialog(
      context: context,
      builder: (_) => _StyledDialog(
        icon: Icons.location_city_rounded,
        iconColor: _C.cyan,
        title: 'Pilih Kota',
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ctrl,
              style: const TextStyle(color: _C.white),
              cursorColor: _C.cyan,
              decoration: InputDecoration(
                hintText: 'Nama kota...',
                hintStyle: const TextStyle(color: _C.grey),
                prefixIcon: const Icon(Icons.search_rounded, color: _C.cyan),
                filled: true,
                fillColor: _C.bg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: _C.cyan.withOpacity(0.2)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: _C.cyan),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Makassar'].map((city) {
                return GestureDetector(
                  onTap: () => ctrl.text = city,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: _C.cyanGlow,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.cyan.withOpacity(0.3)),
                    ),
                    child: Text(
                      city,
                      style: const TextStyle(color: _C.cyan, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: _C.grey)),
          ),
          _CyanButton(
            label: 'Cari',
            onTap: () {
              final city = ctrl.text.trim();
              if (city.isNotEmpty) {
                Navigator.pop(context);
                _fetchPrayerSchedule(city: city);
              }
            },
          ),
        ],
      ),
    );
  }

  // ── QUICK ACTIONS ──
  Widget _buildQuickActions() {
    final actions = [
      _QuickAction(Icons.chat_bubble_rounded, 'Chat', 'Pesan & Grup', _C.cyan, () {
        Navigator.push(context, _createRoute(ChatHubPage(sessionKey: sessionKey, username: username)));
      }),
      _QuickAction(Icons.circle_notifications_rounded, 'Status', 'Status & Stories', const Color(0xFF4CAF50), () {
        Navigator.push(context, _createRoute(StatusPage(sessionKey: sessionKey, username: username)));
      }),
      _QuickAction(Icons.bug_report_rounded, 'Bug Sender', 'Kelola bug', _C.cyan, () {
        Navigator.push(context, _createRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)));
      }),
      _QuickAction(FontAwesomeIcons.whatsapp, 'WA Bug', 'Kirim ke WA', const Color(0xFF25D366), () {
        Navigator.push(context, _createRoute(HomePage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey)));
      }),
      _QuickAction(Icons.store_rounded, 'Marketplace', 'Jual beli', _C.green, () {
        Navigator.push(context, _createRoute(MarketplacePage(sessionKey: sessionKey, username: username, role: role)));
      }),
      _QuickAction(Icons.build_rounded, 'Tools', 'Gateway tools', _C.blue, () {
        Navigator.push(context, _createRoute(ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos)));
      }),
      _QuickAction(Icons.info_rounded, 'Info', 'Updates', _C.orange, () {
        Navigator.push(context, _createRoute(InfoPage(sessionKey: sessionKey)));
      }),
      _QuickAction(Icons.favorite_rounded, 'Thanks', 'Credits', _C.pink, _showThanksDialog),
      _QuickAction(FontAwesomeIcons.telegram, 'Telegram', 'Community', const Color(0xFF0088CC), () {
        _openUrl('https://t.me/aboutnastarz');
      }),
    ];

    return SizedBox(
      height: 190,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        physics: const BouncingScrollPhysics(),
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (_, i) => _actionCard(actions[i]),
      ),
    );
  }

  Widget _actionCard(_QuickAction action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        width: 200,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              action.color.withOpacity(0.18),
              action.color.withOpacity(0.06),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: action.color.withOpacity(0.4), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: action.color.withOpacity(0.18),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: action.color.withOpacity(0.22),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: action.color.withOpacity(0.5)),
                boxShadow: [
                  BoxShadow(
                    color: action.color.withOpacity(0.3),
                    blurRadius: 14,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Icon(action.icon, color: action.color, size: 26),
            ),
            const SizedBox(height: 14),
            Text(
              action.title,
              style: TextStyle(
                color: action.color,
                fontSize: 15,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.3,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 3),
            Text(
              action.subtitle,
              style: TextStyle(
                color: action.color.withOpacity(0.6),
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // ── NEWS SECTION ──
  Widget _newsBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: _C.cyan.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.cyan.withOpacity(0.25)),
      ),
      child: Text(
        isLoadingNews ? 'Loading...' : '${newsList.length} Berita',
        style: const TextStyle(
          color: _C.cyan,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget _buildNewsSection() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: _C.surface.withOpacity(0.6),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border.withOpacity(0.3)),
        ),
        child: Center(
          child: Text(
            isLoadingNews ? 'Memuat berita...' : (newsError.isNotEmpty ? newsError : 'Belum ada berita'),
            style: const TextStyle(color: _C.grey, fontSize: 13),
          ),
        ),
      );
    }

    return SizedBox(
      height: 210,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        physics: const BouncingScrollPhysics(),
        itemCount: newsList.length.clamp(0, 10),
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => _newsCard(newsList[i]),
      ),
    );
  }

  Widget _newsCard(dynamic item) {
    final n = _normalizeNews(item);
    final title = n['title']?.toString() ?? 'Update';
    final desc = n['desc']?.toString() ?? '';
    final image = n['image']?.toString() ?? '';
    final url = n['url']?.toString() ?? '';

    return GestureDetector(
      onTap: url.isNotEmpty ? () => _openUrl(url) : null,
      child: Container(
        width: 250,
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 15,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Image
              if (image.isNotEmpty)
                Image.network(
                  image,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _newsPlaceholder(),
                )
              else
                _newsPlaceholder(),

              // Overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.85),
                    ],
                  ),
                ),
              ),

              // Content
              Positioned(
                left: 14,
                right: 14,
                bottom: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.cyan.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text(
                        'LIVE NEWS',
                        style: TextStyle(
                          color: _C.cyan,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _C.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        height: 1.3,
                      ),
                    ),
                    if (desc.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        desc,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.grey,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _newsPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.cyan.withOpacity(0.2), _C.bg],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(
        child: Icon(Icons.newspaper_rounded, color: _C.grey, size: 48),
      ),
    );
  }

  // ── ACTIVITY SECTION ──
  Widget _buildActivitySection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(0.7),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border.withOpacity(0.4)),
      ),
      child: recentActivities.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(32),
              child: Center(
                child: Text(
                  'Belum ada aktivitas',
                  style: TextStyle(color: _C.grey, fontSize: 13),
                ),
              ),
            )
          : ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: recentActivities.length.clamp(0, 5),
              separatorBuilder: (_, __) => Divider(color: _C.border.withOpacity(0.3), height: 1),
              itemBuilder: (_, i) {
                final activity = recentActivities[i];
                return ListTile(
                  dense: true,
                  leading: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: _C.cyanGlow,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.history_rounded, color: _C.cyan, size: 16),
                  ),
                  title: Text(
                    activity['action'] ?? '',
                    style: const TextStyle(color: _C.white, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    activity['detail'] ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _C.grey, fontSize: 10),
                  ),
                  trailing: Text(
                    _formatTime(DateTime.tryParse(activity['time'] ?? '') ?? DateTime.now()),
                    style: const TextStyle(color: _C.textMuted, fontSize: 9),
                  ),
                );
              },
            ),
    );
  }

  // ── BLESSING CARD ──
  Widget _buildBlessingCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.surface, _C.card],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.pink.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _C.pink.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.favorite_rounded, color: _C.pink, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Terima kasih, $username! 💫',
                  style: const TextStyle(
                    color: _C.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Semoga hari ini penuh berkah dan manfaat. Aamiin.',
                  style: TextStyle(
                    color: _C.grey,
                    fontSize: 11,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── SECTION HEADER ──
  Widget _buildSectionHeader(IconData icon, String label, {Widget? trailing}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Icon(icon, color: _C.cyan, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: _C.grey,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
          ),
          if (trailing != null) trailing,
        ],
      ),
    );
  }

  // ── THANKS DIALOG ──
  void _showThanksDialog() {
    showDialog(
      context: context,
      builder: (_) => _StyledDialog(
        icon: Icons.emoji_people_rounded,
        iconColor: _C.pink,
        title: 'Thanks To',
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _thanksItem('VTX Team', 'Developer & Creator', Icons.code_rounded, _C.cyan),
            const Divider(color: Colors.white10, height: 20),
            _thanksItem('All Users', 'Supporters Loyal', Icons.people_rounded, _C.green),
            const Divider(color: Colors.white10, height: 20),
            _thanksItem('Telegram', '@Volderaz_q', Icons.send, const Color(0xFF0088CC)),
          ],
        ),
        actions: [
          _CyanButton(label: 'Close', onTap: () => Navigator.pop(context)),
        ],
      ),
    );
  }

  Widget _thanksItem(String title, String sub, IconData icon, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: _C.white, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(color: _C.grey, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── BUG BANNER ──
  Widget _buildBugBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _C.surface,
        border: Border.all(color: _C.cyan.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: _C.cyan.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/bugonly.jpg',
              fit: BoxFit.cover,
              errorBuilder: (ctx, err, st) => Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.cyan.withOpacity(0.15),
                      _C.surface,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.bug_report_rounded, color: _C.cyan, size: 48),
                ),
              ),
            ),
            // Dark overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.55),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 16,
              bottom: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: _C.cyan.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.cyan.withOpacity(0.4)),
                ),
                child: const Text(
                  'VTX BUG TOOLS',
                  style: TextStyle(
                    color: _C.cyan,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── UTILITIES ──
  Widget _orb(Color color, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [BoxShadow(color: color, blurRadius: 50, spreadRadius: 15)],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  DATA MODELS & HELPERS
// ═══════════════════════════════════════════════════════════════════════════
class _QuickAction {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _QuickAction(this.icon, this.title, this.subtitle, this.color, this.onTap);
}

// ═══════════════════════════════════════════════════════════════════════════
//  SHARED WIDGETS
// ═══════════════════════════════════════════════════════════════════════════
class _StyledDialog extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final Widget content;
  final List<Widget> actions;

  const _StyledDialog({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.content,
    required this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      contentPadding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: _C.white,
                fontWeight: FontWeight.w800,
                fontSize: 17,
              ),
            ),
          ),
        ],
      ),
      content: content,
      actions: actions,
    );
  }
}

class _CyanButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _CyanButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: _C.cyan, // medium blue 0xFF1E88E5
        foregroundColor: _C.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        elevation: 0,
      ),
      onPressed: onTap,
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  CUSTOM PAINTERS
// ═══════════════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  final Color color;
  final double spacing;
  const _GridPainter({required this.color, required this.spacing});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 0.5;
    
    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => old.color != color || old.spacing != spacing;
}

// ═══════════════════════════════════════════════════════════════════════════
//  MARKETPLACE PAGE (FIXED VERSION)
// ═══════════════════════════════════════════════════════════════════════════
class Product {
  final String id;
  final String name;
  final String price;
  final String description;
  final String category;

  const Product({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.category,
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
    id: j['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
    name: j['name'] ?? '',
    price: j['price'] ?? '',
    description: j['description'] ?? '',
    category: j['category'] ?? '',
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'price': price,
    'description': description,
    'category': category,
  };
}

class MarketplacePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const MarketplacePage({super.key, required this.sessionKey, required this.username, required this.role});

  @override
  State<MarketplacePage> createState() => _MarketplacePageState();
}

class _MarketplacePageState extends State<MarketplacePage> {
  List<Product> products = [];
  List<Product> filteredProducts = [];
  String selectedCategory = 'Semua';
  String searchQuery = '';

  static const categories = ['Semua', 'Access VTX', 'Script/APK', 'VPS Legal', 'Jasa', 'Lainnya'];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList('marketplace_products_${widget.sessionKey}') ?? [];
      setState(() {
        products = raw.map((j) => Product.fromJson(jsonDecode(j))).toList();
        filteredProducts = products;
      });
    } catch (e) {
      debugPrint('Load products error: $e');
    }
  }

  Future<void> _saveProducts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
        'marketplace_products_${widget.sessionKey}',
        products.map((p) => jsonEncode(p.toJson())).toList(),
      );
    } catch (e) {
      debugPrint('Save products error: $e');
    }
  }

  void _filter() {
    setState(() {
      filteredProducts = products.where((p) {
        final catMatch = selectedCategory == 'Semua' || p.category == selectedCategory;
        final searchMatch = searchQuery.isEmpty ||
            p.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
            p.description.toLowerCase().contains(searchQuery.toLowerCase());
        return catMatch && searchMatch;
      }).toList();
    });
  }

  void _addProduct() {
    showDialog(
      context: context,
      builder: (_) => _ProductDialog(onSave: (p) {
        setState(() {
          products.add(p);
          _filter();
        });
        _saveProducts();
      }),
    );
  }

  void _editProduct(Product p) {
    showDialog(
      context: context,
      builder: (_) => _ProductDialog(product: p, onSave: (edited) {
        setState(() {
          final idx = products.indexWhere((x) => x.id == p.id);
          if (idx != -1) {
            products[idx] = edited;
            _filter();
          }
        });
        _saveProducts();
      }),
    );
  }

  void _deleteProduct(Product p) {
    showDialog(
      context: context,
      builder: (_) => _StyledDialog(
        icon: Icons.delete_forever_rounded,
        iconColor: _C.red,
        title: 'Hapus Produk',
        content: Text('Yakin hapus "${p.name}"?', style: const TextStyle(color: _C.grey)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: _C.grey))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _C.red),
            onPressed: () {
              setState(() {
                products.removeWhere((x) => x.id == p.id);
                _filter();
              });
              _saveProducts();
              Navigator.pop(context);
            },
            child: const Text('Hapus', style: TextStyle(color: _C.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAdmin = widget.role == 'admin' || widget.role == 'owner';

    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        title: const Text('Marketplace', style: TextStyle(fontWeight: FontWeight.w800, color: _C.white)),
        backgroundColor: _C.surface,
        elevation: 0,
        iconTheme: const IconThemeData(color: _C.cyan),
        actions: [
          if (isAdmin)
            IconButton(
              icon: const Icon(Icons.add_box_rounded, color: _C.cyan),
              onPressed: _addProduct,
            ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            margin: const EdgeInsets.all(16),
            child: TextField(
              onChanged: (v) {
                searchQuery = v;
                _filter();
              },
              style: const TextStyle(color: _C.white),
              cursorColor: _C.cyan,
              decoration: InputDecoration(
                hintText: 'Cari produk...',
                hintStyle: const TextStyle(color: _C.grey),
                prefixIcon: const Icon(Icons.search_rounded, color: _C.cyan),
                filled: true,
                fillColor: _C.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: _C.cyan),
                ),
              ),
            ),
          ),

          // Categories
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final cat = categories[i];
                final isSelected = cat == selectedCategory;
                return GestureDetector(
                  onTap: () {
                    selectedCategory = cat;
                    _filter();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? _C.cyan : _C.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: isSelected ? _C.cyan : _C.border),
                    ),
                    child: Text(
                      cat,
                      style: TextStyle(
                        color: isSelected ? _C.bg : _C.grey,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 12),

          // Products List
          Expanded(
            child: filteredProducts.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inventory_2_outlined, size: 56, color: _C.grey),
                        SizedBox(height: 12),
                        Text('Belum ada produk', style: TextStyle(color: _C.grey, fontSize: 14)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: filteredProducts.length,
                    itemBuilder: (_, i) => _productCard(filteredProducts[i], isAdmin),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _productCard(Product p, bool canEdit) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border.withOpacity(0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    p.name,
                    style: const TextStyle(color: _C.white, fontSize: 16, fontWeight: FontWeight.w800),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.cyanGlow,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    p.category,
                    style: const TextStyle(color: _C.cyan, fontSize: 10, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              p.description,
              style: const TextStyle(color: _C.grey, fontSize: 12),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Text(
                  p.price,
                  style: const TextStyle(color: _C.cyan, fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _buyProduct(p),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                    decoration: BoxDecoration(
                      color: _C.cyan,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'Beli',
                      style: TextStyle(color: _C.bg, fontSize: 13, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                if (canEdit) ...[
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.edit_rounded, size: 18, color: _C.blue),
                    onPressed: () => _editProduct(p),
                    constraints: const BoxConstraints(),
                    padding: EdgeInsets.zero,
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: const Icon(Icons.delete_rounded, size: 18, color: _C.red),
                    onPressed: () => _deleteProduct(p),
                    constraints: const BoxConstraints(),
                    padding: EdgeInsets.zero,
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _buyProduct(Product p) {
    showDialog(
      context: context,
      builder: (_) => _StyledDialog(
        icon: Icons.shopping_bag_rounded,
        iconColor: _C.green,
        title: 'Konfirmasi Pembelian',
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(p.name, style: const TextStyle(color: _C.white, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Harga: ${p.price}', style: const TextStyle(color: _C.cyan, fontSize: 14)),
            const SizedBox(height: 8),
            Text(p.description, style: const TextStyle(color: _C.grey, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: _C.grey))),
          _CyanButton(label: 'Beli Sekarang', onTap: () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Pembelian ${p.name} berhasil!'),
                backgroundColor: _C.green,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  BUBBLE BOTTOM NAV COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════

class _NavItem {
  final IconData icon;
  final String label;
  final Color color;
  const _NavItem({required this.icon, required this.label, required this.color});
}

class _BubbleNavItem extends StatefulWidget {
  final _NavItem item;
  final bool isSelected;
  final VoidCallback onTap;

  const _BubbleNavItem({
    required this.item,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_BubbleNavItem> createState() => _BubbleNavItemState();
}

class _BubbleNavItemState extends State<_BubbleNavItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scaleAnim;
  final List<_BubbleParticle> _particles = [];
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _scaleAnim = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.88), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.88, end: 1.08), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.08, end: 1.0), weight: 35),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _spawnBubbles() {
    final rng = math.Random();
    setState(() {
      _particles.clear();
      for (int i = 0; i < 8; i++) {
        _particles.add(_BubbleParticle(
          dx: (rng.nextDouble() - 0.5) * 60,
          dy: -(20 + rng.nextDouble() * 40),
          size: 4 + rng.nextDouble() * 8,
          delay: rng.nextDouble() * 150,
        ));
      }
    });
    _ctrl.forward(from: 0);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _particles.clear());
    });
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.item.color;
    final selected = widget.isSelected;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        _spawnBubbles();
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: SizedBox(
        width: 52,
        height: 62,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, child) {
            return Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                // Bubble particles
                ..._particles.map((p) => _AnimatedBubble(
                      particle: p,
                      color: color,
                      animation: _ctrl,
                    )),

                // Icon + label
                Transform.scale(
                  scale: _ctrl.isAnimating ? _scaleAnim.value : (_pressed ? 0.88 : 1.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut,
                        width: selected ? 44 : 36,
                        height: selected ? 36 : 30,
                        decoration: BoxDecoration(
                          color: selected
                              ? color.withOpacity(0.18)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: selected
                              ? [
                                  BoxShadow(
                                    color: color.withOpacity(0.35),
                                    blurRadius: 12,
                                    spreadRadius: 1,
                                  )
                                ]
                              : [],
                        ),
                        child: Icon(
                          widget.item.icon,
                          color: selected ? color : _C.textMuted,
                          size: selected ? 22 : 20,
                        ),
                      ),
                      const SizedBox(height: 3),
                      AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 200),
                        style: TextStyle(
                          color: selected ? color : _C.textMuted,
                          fontSize: selected ? 9.5 : 9,
                          fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                          letterSpacing: 0.2,
                        ),
                        child: Text(
                          widget.item.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _BubbleParticle {
  final double dx;
  final double dy;
  final double size;
  final double delay;
  const _BubbleParticle({
    required this.dx,
    required this.dy,
    required this.size,
    required this.delay,
  });
}

class _AnimatedBubble extends StatelessWidget {
  final _BubbleParticle particle;
  final Color color;
  final Animation<double> animation;

  const _AnimatedBubble({
    required this.particle,
    required this.color,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    final progress = (animation.value - particle.delay / 600).clamp(0.0, 1.0);
    final opacity = progress < 0.7
        ? progress / 0.7
        : 1.0 - ((progress - 0.7) / 0.3);

    return Positioned(
      left: 26 + particle.dx * progress - particle.size / 2,
      top: 20 + particle.dy * progress - particle.size / 2,
      child: Opacity(
        opacity: opacity.clamp(0.0, 1.0),
        child: Container(
          width: particle.size * (1 - progress * 0.3),
          height: particle.size * (1 - progress * 0.3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.6),
            border: Border.all(
              color: color.withOpacity(0.9),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 4,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  PRODUCT DIALOG
// ═══════════════════════════════════════════════════════════════════════════
class _ProductDialog extends StatefulWidget {
  final Product? product;
  final Function(Product) onSave;
  const _ProductDialog({this.product, required this.onSave});

  @override
  State<_ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<_ProductDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameCtrl;
  late TextEditingController _priceCtrl;
  late TextEditingController _descCtrl;
  late String _category;

  static const cats = ['Access VTX', 'Script/APK', 'VPS Legal', 'Jasa', 'Lainnya'];

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.product?.name ?? '');
    _priceCtrl = TextEditingController(text: widget.product?.price ?? '');
    _descCtrl = TextEditingController(text: widget.product?.description ?? '');
    _category = widget.product?.category ?? cats.first;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Row(
        children: [
          Icon(widget.product == null ? Icons.add_circle_rounded : Icons.edit_rounded, color: _C.cyan),
          const SizedBox(width: 12),
          Text(widget.product == null ? 'Tambah Produk' : 'Edit Produk',
              style: const TextStyle(color: _C.white, fontWeight: FontWeight.w800)),
        ],
      ),
      content: Form(
        key: _formKey,
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.85,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _nameCtrl,
                style: const TextStyle(color: _C.white),
                decoration: _inputDecoration('Nama Produk'),
                validator: (v) => (v?.isEmpty ?? true) ? 'Wajib diisi' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _priceCtrl,
                style: const TextStyle(color: _C.white),
                decoration: _inputDecoration('Harga (Rp)', prefix: const Icon(Icons.attach_money_rounded, color: _C.green, size: 20)),
                validator: (v) => (v?.isEmpty ?? true) ? 'Wajib diisi' : null,
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: _category,
                dropdownColor: _C.card,
                style: const TextStyle(color: _C.white),
                decoration: _inputDecoration('Kategori'),
                items: cats.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setState(() => _category = v!),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _descCtrl,
                style: const TextStyle(color: _C.white),
                maxLines: 3,
                decoration: _inputDecoration('Deskripsi'),
                validator: (v) => (v?.isEmpty ?? true) ? 'Wajib diisi' : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: _C.grey))),
        _CyanButton(label: 'Simpan', onTap: () {
          if (_formKey.currentState?.validate() ?? false) {
            widget.onSave(Product(
              id: widget.product?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
              name: _nameCtrl.text.trim(),
              price: _priceCtrl.text.trim(),
              description: _descCtrl.text.trim(),
              category: _category,
            ));
            Navigator.pop(context);
          }
        }),
      ],
    );
  }

  InputDecoration _inputDecoration(String label, {Widget? prefix}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: _C.grey),
      prefixIcon: prefix,
      filled: true,
      fillColor: _C.bg,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: _C.cyan.withOpacity(0.2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: _C.cyan),
      ),
    );
  }
}
// ═══════════════════════════════════════════════════════════════════════════
//  HOME SPEED DIAL (Foto 2 style: GROUP, CONTACT, CUSTOM + Close)
// ═══════════════════════════════════════════════════════════════════════════
class _HomeSpeedDial extends StatefulWidget {
  final Animation<double> animation;
  final VoidCallback onGroup;
  final VoidCallback onContact;
  final VoidCallback onCustom;

  const _HomeSpeedDial({
    required this.animation,
    required this.onGroup,
    required this.onContact,
    required this.onCustom,
  });

  @override
  State<_HomeSpeedDial> createState() => _HomeSpeedDialState();
}

class _HomeSpeedDialState extends State<_HomeSpeedDial>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Widget _dialButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    required double delay,
  }) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final t = Curves.elasticOut.transform(
          (((_ctrl.value - delay) / (1 - delay)).clamp(0.0, 1.0)),
        );
        return Transform.scale(
          scale: t,
          child: Opacity(
            opacity: t.clamp(0.0, 1.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: onTap,
                  child: Container(
                    width: 68,
                    height: 68,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color,
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.5),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: Colors.white, size: 28),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 80),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Top row: GROUP and CUSTOM
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _dialButton(
                  icon: Icons.groups_rounded,
                  label: 'CONTACT',
                  color: const Color(0xFF3B82F6),
                  onTap: widget.onGroup,
                  delay: 0.1,
                ),
                const SizedBox(width: 56),
                _dialButton(
                  icon: Icons.code_rounded,
                  label: 'CUSTOM',
                  color: const Color(0xFF8B5CF6),
                  onTap: widget.onCustom,
                  delay: 0.2,
                ),
              ],
            ),
            const SizedBox(height: 20),
            // Middle: CONTACT
            _dialButton(
              icon: Icons.person_rounded,
              label: 'SENDER',
              color: const Color(0xFF10B981),
              onTap: widget.onContact,
              delay: 0.15,
            ),
            const SizedBox(height: 28),
            // Close button
            AnimatedBuilder(
              animation: _ctrl,
              builder: (_, __) {
                final t = _ctrl.value.clamp(0.0, 1.0);
                return Transform.scale(
                  scale: t,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFEF4444),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFEF4444).withOpacity(0.5),
                            blurRadius: 16,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.close_rounded, color: Colors.white, size: 26),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  APP BAR ICON BUTTON (Photo 2 style: dark rounded square)
// ═══════════════════════════════════════════════════════════════════════════
class _AppBarIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _AppBarIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: const Color(0xFF0D0D0D),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.cyan.withOpacity(0.4)),
        ),
        child: Icon(icon, color: _C.cyan, size: 20),
      ),
    );
  }
}
