import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// =====================================================
// AI PAGE — Menggunakan api.siputzx.my.id
// Tanpa server, langsung ke API
// =====================================================

class AIPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const AIPage({
    Key? key,
    required this.username,
    required this.sessionKey,
  }) : super(key: key);

  @override
  State<AIPage> createState() => _AIPageState();
}

class _AIPageState extends State<AIPage> {
  final TextEditingController _textController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = false;
  bool _isTyping = false;
  String _currentResponse = '';
  Timer? _typingTimer;
  int _typingIndex = 0;
  String _selectedModel = 'copilot';

  // Model yang tersedia via siputzx
  final List<Map<String, String>> _models = [
    {'id': 'copilot',  'label': 'Copilot (Default)'},
    {'id': 'llama',    'label': 'Meta LLaMA'},
    {'id': 'gemini',   'label': 'Gemini Flash'},
    {'id': 'blackbox', 'label': 'Blackbox AI'},
  ];

  static const String _apiBase = 'https://api.siputzx.my.id';

  final Color primaryDark   = const Color(0xFF0A0A0A);
  final Color cardDark      = const Color(0xFF1A1A1A);
  final Color accentRed     = const Color(0xFFDC143C);
  final Color userBubble    = const Color(0xFF8B0000);
  final Color aiBubble      = const Color(0xFF2A2A2A);

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }

  // ── Endpoint berdasarkan model yang dipilih ──
  Uri _buildEndpoint(String text) {
    final encoded = Uri.encodeComponent(text);
    switch (_selectedModel) {
      case 'llama':
        return Uri.parse('$_apiBase/api/ai/llama?text=$encoded');
      case 'gemini':
        return Uri.parse('$_apiBase/api/ai/gemini-flash?text=$encoded');
      case 'blackbox':
        return Uri.parse('$_apiBase/api/ai/blackbox?text=$encoded');
      default:
        return Uri.parse('$_apiBase/api/ai/copilot?text=$encoded');
    }
  }

  // ── Parse respons dari berbagai endpoint siputzx ──
  String? _parseResponse(Map<String, dynamic> data) {
    if (data['status'] != true) return null;
    // Kemungkinan key: result, data, response, message, answer
    for (final k in ['result', 'data', 'response', 'message', 'answer', 'text']) {
      if (data[k] != null && data[k] is String && (data[k] as String).isNotEmpty) {
        return data[k] as String;
      }
    }
    return null;
  }

  void _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList('ai_chat_${widget.username}');
    if (history != null && history.isNotEmpty) {
      setState(() {
        _messages.clear();
        for (var j in history) {
          try { _messages.add(jsonDecode(j)); } catch (_) {}
        }
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }
  }

  void _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('ai_chat_${widget.username}',
        _messages.map((m) => jsonEncode(m)).toList());
  }

  void _addMessage(String text, bool isUser) {
    setState(() {
      _messages.add({'text': text, 'isUser': isUser, 'ts': DateTime.now().toIso8601String()});
    });
    _saveChatHistory();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _startTyping(String text) {
    setState(() { _isTyping = true; _currentResponse = ''; _typingIndex = 0; });
    _typingTimer?.cancel();
    _typingTimer = Timer.periodic(const Duration(milliseconds: 18), (timer) {
      if (_typingIndex < text.length) {
        setState(() { _currentResponse = text.substring(0, ++_typingIndex); });
        _scrollToBottom();
      } else {
        timer.cancel();
        setState(() => _isTyping = false);
        _addMessage(text, false);
      }
    });
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;
    setState(() => _isLoading = true);
    _addMessage(text, true);
    _textController.clear();

    try {
      final res = await http.get(
        _buildEndpoint(text),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 20));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final reply = _parseResponse(data);
        if (reply != null) {
          _startTyping(reply);
        } else {
          _addMessage('AI tidak memberikan respons. Coba model lain.', false);
        }
      } else {
        _addMessage('Error ${res.statusCode} — Coba ganti model AI.', false);
      }
    } catch (e) {
      _addMessage('Gagal terhubung: $e', false);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _clearChat() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        title: const Text('Hapus Chat', style: TextStyle(color: Colors.white)),
        content: const Text('Yakin hapus semua riwayat chat?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: Colors.white70))),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              setState(() { _messages.clear(); _currentResponse = ''; _isTyping = false; _typingTimer?.cancel(); });
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('ai_chat_${widget.username}');
            },
            child: Text('Hapus', style: TextStyle(color: accentRed)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: cardDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('AI Assistant',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        actions: [
          if (_messages.isNotEmpty)
            IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white70), onPressed: _clearChat),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: _models.map((m) {
                final selected = m['id'] == _selectedModel;
                return GestureDetector(
                  onTap: () => setState(() => _selectedModel = m['id']!),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: selected ? accentRed : const Color(0xFF111111),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: selected ? accentRed : Colors.grey.shade700),
                    ),
                    child: Text(m['label']!,
                        style: TextStyle(
                          color: selected ? Colors.white : Colors.grey.shade400,
                          fontSize: 12,
                          fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                        )),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scrollController,
            padding: const EdgeInsets.all(16),
            itemCount: _messages.length + (_isTyping ? 1 : 0),
            itemBuilder: (ctx, i) {
              if (i < _messages.length) return _buildBubble(_messages[i]);
              return _buildTypingBubble();
            },
          ),
        ),
        _buildInputBar(),
      ]),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg) {
    final isUser = msg['isUser'] == true;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser)
            Container(
              margin: const EdgeInsets.only(right: 8, top: 4),
              child: CircleAvatar(
                radius: 14,
                backgroundColor: Colors.grey.shade800,
                child: const Icon(Icons.auto_awesome, color: Colors.white, size: 16),
              ),
            ),
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isUser ? userBubble : aiBubble,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: isUser ? accentRed.withOpacity(0.3) : Colors.grey.shade700),
              ),
              child: SelectableText(msg['text'] ?? '',
                  style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
            ),
          ),
          if (isUser)
            Container(
              margin: const EdgeInsets.only(left: 8, top: 4),
              child: CircleAvatar(
                radius: 14,
                backgroundColor: accentRed,
                child: Text(
                  (widget.username.isNotEmpty ? widget.username[0] : 'U').toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTypingBubble() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(right: 8, top: 4),
            child: CircleAvatar(
              radius: 14,
              backgroundColor: Colors.grey.shade800,
              child: const Icon(Icons.auto_awesome, color: Colors.white, size: 16),
            ),
          ),
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: aiBubble,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.grey.shade700),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    child: SelectableText(_currentResponse,
                        style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
                  ),
                  const SizedBox(width: 8),
                  Container(width: 8, height: 8,
                      decoration: BoxDecoration(color: accentRed, borderRadius: BorderRadius.circular(4))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        border: Border(top: BorderSide(color: Colors.grey.shade800)),
      ),
      child: Row(children: [
        Expanded(
          child: TextField(
            controller: _textController,
            style: const TextStyle(color: Colors.white),
            maxLines: null,
            keyboardType: TextInputType.multiline,
            decoration: InputDecoration(
              hintText: 'Ketik pesan...',
              hintStyle: TextStyle(color: Colors.grey.shade600),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25),
                borderSide: BorderSide(color: Colors.grey.shade700),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25),
                borderSide: BorderSide(color: Colors.grey.shade700),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25),
                borderSide: BorderSide(color: accentRed),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              fillColor: Colors.grey.shade900,
              filled: true,
            ),
            onSubmitted: _sendMessage,
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: _isLoading ? null : () => _sendMessage(_textController.text),
          child: Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [accentRed, const Color(0xFFFF6B6B)]),
            ),
            child: _isLoading
                ? const Center(child: SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)))
                : const Icon(Icons.send, color: Colors.white),
          ),
        ),
      ]),
    );
  }
}
