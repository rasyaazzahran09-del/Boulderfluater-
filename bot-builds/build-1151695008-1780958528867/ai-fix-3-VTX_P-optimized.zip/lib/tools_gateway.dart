import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'admin_page.dart';
import 'spotify.dart';
import 'anime_home.dart';
import 'dracin_page.dart';
import 'ai.dart';
import 'device_dashboard.dart';
import 'chat_page.dart';
import 'status_page.dart';
// === FITUR BARU ===
import 'stalker_page.dart';
import 'iqc_page.dart';
import 'live_photo_page.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  final Color bgDark       = const Color(0xFF0B0E14);
  final Color cardBg       = const Color(0xFF151A23);
  final Color cardBorder   = const Color(0xFF252B36);
  final Color textPrimary  = Colors.white;
  final Color textSecondary = const Color(0xFF8B949E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(children: [
          _buildHeader(context),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.85,
                physics: const BouncingScrollPhysics(),
                children: [

                  // ─────────────────────────────────
                  // BARIS 1: DDoS & Server
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.flash_on,
                    iconBg: [const Color(0xFFFF6B35), const Color(0xFFFF8E53)],
                    title: "DDoS Attack",
                    subtitle: "Attack Panel",
                    accent: const Color(0xFFFF6B35),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos))),
                  ),

                  _card(context,
                    icon: Icons.dns,
                    iconBg: [const Color(0xFF4CAF50), const Color(0xFF66BB6A)],
                    title: "Manage Server",
                    subtitle: "Server Control",
                    accent: const Color(0xFF4CAF50),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ManageServerPage(keyToken: sessionKey))),
                  ),

                  // ─────────────────────────────────
                  // BARIS 2: WiFi
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.wifi_off,
                    iconBg: [const Color(0xFF2196F3), const Color(0xFF42A5F5)],
                    title: "WiFi Killer",
                    subtitle: "Internal Network",
                    accent: const Color(0xFF2196F3),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => WifiKillerPage())),
                  ),

                  (userRole == "vip" || userRole == "owner")
                      ? _card(context,
                          icon: Icons.router,
                          iconBg: [const Color(0xFF9C27B0), const Color(0xFFAB47BC)],
                          title: "WiFi External",
                          subtitle: "External Attack",
                          accent: const Color(0xFF9C27B0),
                          onTap: () => Navigator.push(context,
                              MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey))),
                        )
                      : _card(context,
                          icon: Icons.lock,
                          iconBg: [const Color(0xFF607D8B), const Color(0xFF78909C)],
                          title: "WiFi External",
                          subtitle: "VIP Only",
                          accent: const Color(0xFF607D8B),
                          isLocked: true,
                          onTap: () {},
                        ),

                  // ─────────────────────────────────
                  // BARIS 3: OSINT / Check
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.badge,
                    iconBg: [const Color(0xFFFF9800), const Color(0xFFFFB74D)],
                    title: "NIK Check",
                    subtitle: "ID Validator",
                    accent: const Color(0xFFFF9800),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const NikCheckerPage())),
                  ),

                  _card(context,
                    icon: Icons.domain,
                    iconBg: [const Color(0xFF00BCD4), const Color(0xFF26C6DA)],
                    title: "Domain OSINT",
                    subtitle: "Domain Scanner",
                    accent: const Color(0xFF00BCD4),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const DomainOsintPage())),
                  ),

                  // ─────────────────────────────────
                  // BARIS 4: STALKER OSINT (BARU)
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.person_search,
                    iconBg: [const Color(0xFFEF4444), const Color(0xFFFF6B6B)],
                    title: "Stalker OSINT",
                    subtitle: "IG • TikTok • GitHub",
                    accent: const Color(0xFFEF4444),
                    badge: "NEW",
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const StalkerPage())),
                  ),

                  _card(context,
                    icon: Icons.chat_bubble_outline,
                    iconBg: [const Color(0xFFE91E63), const Color(0xFFF06292)],
                    title: "Spam NGL",
                    subtitle: "Anonymous Msg",
                    accent: const Color(0xFFE91E63),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => NglPage())),
                  ),

                  // ─────────────────────────────────
                  // BARIS 5: Admin & Device
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.admin_panel_settings,
                    iconBg: [const Color(0xFFF44336), const Color(0xFFEF5350)],
                    title: "RATT Admin",
                    subtitle: "Admin Panel",
                    accent: const Color(0xFFF44336),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => DeviceDashboardPage(sessionKey: sessionKey))),
                  ),

                  _card(context,
                    icon: Icons.phone_android,
                    iconBg: [const Color(0xFF3F51B5), const Color(0xFF7986CB)],
                    title: "Phone Lookup",
                    subtitle: "Number Info",
                    accent: const Color(0xFF3F51B5),
                    onTap: () => _showComingSoon(context),
                  ),

                  // ─────────────────────────────────
                  // BARIS 6: Downloader
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.music_note,
                    iconBg: [const Color(0xFF1DB954), const Color(0xFF1ED760)],
                    title: "Spotify",
                    subtitle: "Music Downloader",
                    accent: const Color(0xFF1DB954),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const SpotifyPage())),
                  ),

                  _card(context,
                    icon: Icons.smart_display,
                    iconBg: [const Color(0xFF000000), const Color(0xFF333333)],
                    title: "TikTok",
                    subtitle: "Video Downloader",
                    accent: const Color(0xFFFE2C55),
                    iconColor: const Color(0xFFFE2C55),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const TiktokDownloaderPage())),
                  ),

                  // ─────────────────────────────────
                  // BARIS 7: Downloader lanjutan
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.camera_alt,
                    iconBg: [const Color(0xFFE1306C), const Color(0xFFF77737)],
                    title: "Instagram",
                    subtitle: "Media Downloader",
                    accent: const Color(0xFFE1306C),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const InstagramDownloaderPage())),
                  ),

                  _card(context,
                    icon: Icons.auto_awesome,
                    iconBg: [const Color(0xFF673AB7), const Color(0xFF9575CD)],
                    title: "AI Assistant",
                    subtitle: "Multi-Model AI",
                    accent: const Color(0xFF673AB7),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => AIPage(username: '', sessionKey: sessionKey))),
                  ),

                  // ─────────────────────────────────
                  // BARIS 8: IQC & Live Photo (BARU)
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.analytics_outlined,
                    iconBg: [const Color(0xFF7C3AED), const Color(0xFFAB47BC)],
                    title: "IQC",
                    subtitle: "Image Quality Check",
                    accent: const Color(0xFF7C3AED),
                    badge: "NEW",
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const IqcPage())),
                  ),

                  _card(context,
                    icon: Icons.motion_photos_on,
                    iconBg: [const Color(0xFFE91E63), const Color(0xFFFF4081)],
                    title: "Live Photo",
                    subtitle: "Foto → Live Video",
                    accent: const Color(0xFFE91E63),
                    badge: "NEW",
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const LivePhotoPage())),
                  ),

                  // ─────────────────────────────────
                  // BARIS 9: Entertainment
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.movie_filter,
                    iconBg: [const Color(0xFFFF5722), const Color(0xFFFF7043)],
                    title: "Dracin",
                    subtitle: "Movie Stream",
                    accent: const Color(0xFFFF5722),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const DracinPage())),
                  ),

                  _card(context,
                    icon: Icons.animation,
                    iconBg: [const Color(0xFFFF4081), const Color(0xFFFF80AB)],
                    title: "Anime Home",
                    subtitle: "Anime Stream",
                    accent: const Color(0xFFFF4081),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const HomeAnimePage())),
                  ),

                  // ─────────────────────────────────
                  // BARIS 10: Utilities & Social
                  // ─────────────────────────────────
                  _card(context,
                    icon: Icons.qr_code_2,
                    iconBg: [const Color(0xFF009688), const Color(0xFF4DB6AC)],
                    title: "QR Generator",
                    subtitle: "Create QR Code",
                    accent: const Color(0xFF009688),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const QrGeneratorPage())),
                  ),

                  _card(context,
                    icon: Icons.forum_rounded,
                    iconBg: [const Color(0xFF4A90C4), const Color(0xFF357ABD)],
                    title: "VTX Chat",
                    subtitle: "Public & Private",
                    accent: const Color(0xFF4A90C4),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ChatHubPage(sessionKey: sessionKey, username: sessionKey))),
                  ),

                  _card(context,
                    icon: Icons.auto_stories_rounded,
                    iconBg: [const Color(0xFFFF6B9D), const Color(0xFFFF4081)],
                    title: "Status",
                    subtitle: "Story & Updates",
                    accent: const Color(0xFFFF4081),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => StatusPage(sessionKey: sessionKey, username: sessionKey))),
                  ),

                  _card(context,
                    icon: Icons.call_rounded,
                    iconBg: [const Color(0xFF4CAF50), const Color(0xFF2E7D32)],
                    title: "VTX Call",
                    subtitle: "Voice & Video",
                    accent: const Color(0xFF4CAF50),
                    onTap: () => _showCallDialog(context),
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }

  // ── Header ──
  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cardBorder),
              ),
              child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
            ),
          ),
          Column(children: [
            Text("UTILITY TOOLS",
                style: TextStyle(color: textPrimary, fontSize: 18, fontWeight: FontWeight.bold,
                    letterSpacing: 2, fontFamily: 'Orbitron')),
            const SizedBox(height: 2),
            Text("Professional Toolkit",
                style: TextStyle(color: textSecondary, fontSize: 11, letterSpacing: 1)),
          ]),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
            ),
            child: const Icon(Icons.settings_suggest_outlined, color: Color(0xFFEF4444), size: 20),
          ),
        ],
      ),
    );
  }

  // ── Card Tool ──
  Widget _card(
    BuildContext context, {
    required IconData icon,
    required List<Color> iconBg,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
    bool isLocked = false,
    Color? iconColor,
    String? badge,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: isLocked ? null : onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: cardBorder.withOpacity(0.5)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 4))],
          ),
          child: Stack(children: [
            // Konten utama
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: iconBg, begin: Alignment.topLeft, end: Alignment.bottomRight),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: iconBg[0].withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4))],
                  ),
                  child: Icon(icon, color: iconColor ?? Colors.white, size: 24),
                ),
                const Spacer(),
                Text(title,
                    style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(subtitle,
                    style: TextStyle(color: textSecondary, fontSize: 11, fontFamily: 'ShareTechMono'),
                    overflow: TextOverflow.ellipsis),
              ]),
            ),

            // Accent line bawah kiri
            Positioned(
              bottom: 16, left: 16,
              child: Container(width: 24, height: 3,
                  decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(2))),
            ),

            // Arrow kanan bawah
            Positioned(
              bottom: 12, right: 12,
              child: Icon(Icons.arrow_forward_ios, color: textSecondary.withOpacity(0.5), size: 14),
            ),

            // Badge NEW (jika ada)
            if (badge != null)
              Positioned(
                top: 8, right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(badge,
                      style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                ),
              ),

            // Lock overlay
            if (isLocked)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(16)),
                  child: const Center(child: Icon(Icons.lock, color: Colors.white54, size: 24)),
                ),
              ),
          ]),
        ),
      ),
    );
  }

  // ── Dialog Call ──
  void _showCallDialog(BuildContext context) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF151A23),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 20, right: 20, top: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Hubungi User',
                style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              autofocus: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Ketik username target...',
                hintStyle: const TextStyle(color: Color(0xFF8B949E)),
                filled: true,
                fillColor: const Color(0xFF0B0E14),
                prefixIcon: const Icon(Icons.person, color: Color(0xFF4A90C4)),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF4CAF50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  icon: const Icon(Icons.call, color: Colors.white),
                  label: const Text('Voice Call',
                      style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12)),
                  onPressed: () {
                    final target = ctrl.text.trim();
                    if (target.isEmpty) return;
                    Navigator.pop(context);
                    final parts = [sessionKey, target]..sort();
                    final roomId = 'call_${parts.join('_')}';
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => CallPage(
                        sessionKey: sessionKey, username: sessionKey,
                        peerUsername: target, isVideo: false, roomId: roomId,
                      ),
                    ));
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF4A90C4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  icon: const Icon(Icons.videocam, color: Colors.white),
                  label: const Text('Video Call',
                      style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12)),
                  onPressed: () {
                    final target = ctrl.text.trim();
                    if (target.isEmpty) return;
                    Navigator.pop(context);
                    final parts = [sessionKey, target]..sort();
                    final roomId = 'call_${parts.join('_')}';
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => CallPage(
                        sessionKey: sessionKey, username: sessionKey,
                        peerUsername: target, isVideo: true, roomId: roomId,
                      ),
                    ));
                  },
                ),
              ),
            ]),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: const [
        Icon(Icons.hourglass_top, color: Colors.white),
        SizedBox(width: 8),
        Text('Feature Coming Soon!', style: TextStyle(fontWeight: FontWeight.bold)),
      ]),
      backgroundColor: const Color(0xFF2D3748),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 2),
    ));
  }
}
