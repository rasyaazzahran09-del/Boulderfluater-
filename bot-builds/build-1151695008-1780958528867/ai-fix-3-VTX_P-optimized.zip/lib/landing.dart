import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _animationController;
  late final Animation<double> _fadeAnimation;
  late final Animation<Offset> _slideAnimation;

  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoFailed = false;

  static const String _videoAsset = 'assets/videos/headshot.mp4';
  static const String _posterAsset = 'assets/images/headshot_poster.jpg';

  static const Color _bg = Color(0xFF000000);
  static const Color _panel = Color(0xFF080808);
  static const Color _white = Color(0xFFF5F5F5);
  static const Color _softWhite = Color(0xFFD9D9D9);
  static const Color _redStart = Color(0xFF1E40AF);
  static const Color _redEnd = Color(0xFF2563EB);
  static const Color _line = Color(0xFF262626);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.03),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );

    _animationController.forward();
    _setupVideo();
  }

  Future<void> _setupVideo() async {
    try {
      final controller = VideoPlayerController.asset(_videoAsset);
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();

      if (!mounted) {
        await controller.dispose();
        return;
      }

      setState(() {
        _videoController = controller;
        _videoReady = true;
        _videoFailed = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _videoFailed = true;
        _videoReady = false;
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _videoController;
    if (controller == null || !_videoReady) return;

    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      controller.pause();
    } else if (state == AppLifecycleState.resumed) {
      controller.play();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _animationController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && mounted) {
        _showMessage('Tidak dapat membuka link.');
      }
    } catch (_) {
      if (!mounted) return;
      _showMessage('Terjadi kesalahan saat membuka link.');
    }
  }

  void _showMessage(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.black.withOpacity(0.92),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: Column(
                    children: [
                      _buildTopVideoCard(),
                      const SizedBox(height: 16),
                      Text(
                        'VTX',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _white,
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 3.2,
                          shadows: const [
                            Shadow(
                              color: Colors.black,
                              blurRadius: 10,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      _buildHandshakeIcon(),
                      const SizedBox(height: 24),
                      _buildInfoBox(),
                      const SizedBox(height: 22),
                      Text(
                        '— VTX —',
                        style: TextStyle(
                          color: _softWhite,
                          fontSize: 17,
                          letterSpacing: 2.2,
                        ),
                      ),
                      const SizedBox(height: 64),
                      _buildLoginButton(),
                      const SizedBox(height: 14),
                      _buildContactButton(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopVideoCard() {
    return Container(
      width: double.infinity,
      height: 240,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: const Color(0xFF101010),
        border: Border.all(color: const Color(0xFF1E1E1E), width: 1.2),
        boxShadow: const [
          BoxShadow(
            color: Colors.black54,
            blurRadius: 24,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Positioned.fill(child: _buildVideoLayer()),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.12),
                      Colors.black.withOpacity(0.06),
                      Colors.black.withOpacity(0.28),
                    ],
                  ),
                ),
              ),
            ),
            Center(
              child: Text(
                'VOLDERAZ',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0xFFE8EEF9),
                  fontWeight: FontWeight.w900,
                  fontSize: 44,
                  letterSpacing: 1.6,
                  shadows: const [
                    Shadow(
                      color: Colors.black87,
                      blurRadius: 10,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoLayer() {
    if (_videoReady && _videoController != null) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _videoController!.value.size.width,
          height: _videoController!.value.size.height,
          child: VideoPlayer(_videoController!),
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        Image.asset(
          _posterAsset,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) {
            return Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF2C0E0E), Color(0xFF151515)],
                ),
              ),
            );
          },
        ),
        if (!_videoFailed)
          const Center(
            child: SizedBox(
              height: 28,
              width: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2.4,
                color: Colors.white,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildHandshakeIcon() {
    return Container(
      width: 66,
      height: 66,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.02),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Icon(
        Icons.handshake_outlined,
        color: Colors.white.withOpacity(0.88),
        size: 34,
      ),
    );
  }

  Widget _buildInfoBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      decoration: BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: const [
          BoxShadow(
            color: Colors.black45,
            blurRadius: 22,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Text(
        'Confirmation of the latest official VTX update. We,\n'
        'as representatives of the VTX team, would like to\n'
        'inform you that this is an app bug. So make sure that while\n'
        'using this application, don\'t use it for revenge. Use it\n'
        'for your own needs only. OK, Happy Using.',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: _white.withOpacity(0.9),
          fontSize: 14,
          height: 1.65,
          letterSpacing: 0.25,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return _buildMainButton(
      label: 'Login To VTX',
      icon: Icons.rocket_launch_rounded,
      gradient: const [Color(0xFF1E40AF), Color(0xFF2563EB)],
      onTap: () {
        Navigator.pushNamed(context, '/login');
      },
    );
  }

  Widget _buildContactButton() {
    return _buildMainButton(
      label: 'Hubungi Team VTX',
      icon: Icons.facebook_rounded,
      gradient: const [
        Color(0xFF6EE6FF),
        Color(0xFF7AFD95),
        Color(0xFFF3F84C),
      ],
      textColor: const Color(0xFF181818),
      onTap: () => _openUrl('https://t.me/Volderaz'),
    );
  }

  Widget _buildMainButton({
    required String label,
    required IconData icon,
    required List<Color> gradient,
    required VoidCallback onTap,
    Color textColor = Colors.white,
  }) {
    return Container(
      width: double.infinity,
      height: 62,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(colors: gradient),
        border: Border.all(color: Colors.white.withOpacity(0.45), width: 1),
        boxShadow: [
          BoxShadow(
            color: gradient.first.withOpacity(0.22),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: textColor, size: 23),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
