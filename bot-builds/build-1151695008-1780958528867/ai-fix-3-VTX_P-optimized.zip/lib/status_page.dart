import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

const String _kServerBase = 'http://panel-legal.jhonaley.net:2983'; // Ganti URL server kamu

// ============================================================
// MODEL
// ============================================================
class UserStatus {
  final String id;
  final String username;
  final String mediaUrl;
  final String mediaType; // image | video | text
  final String caption;
  final DateTime createdAt;
  final bool isOwn;
  final List<String> viewers;

  const UserStatus({
    required this.id,
    required this.username,
    required this.mediaUrl,
    required this.mediaType,
    required this.caption,
    required this.createdAt,
    required this.isOwn,
    required this.viewers,
  });

  factory UserStatus.fromJson(Map<String, dynamic> j, String myUsername) {
    return UserStatus(
      id: j['id']?.toString() ?? '',
      username: j['username']?.toString() ?? '',
      mediaUrl: j['mediaUrl']?.toString() ?? '',
      mediaType: j['mediaType']?.toString() ?? 'image',
      caption: j['caption']?.toString() ?? '',
      createdAt:
          DateTime.tryParse(j['createdAt']?.toString() ?? '') ?? DateTime.now(),
      isOwn: j['username']?.toString() == myUsername,
      viewers: List<String>.from(j['viewers'] ?? []),
    );
  }
}

// ============================================================
// STATUS HUB PAGE
// ============================================================
class StatusPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StatusPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> {
  List<UserStatus> _myStatuses = [];
  List<UserStatus> _othersStatuses = [];
  bool _loading = true;

  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _border = Color(0xFF252B36);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  @override
  void initState() {
    super.initState();
    _loadStatuses();
  }

  String? _errorMsg;

  Future<void> _loadStatuses() async {
    setState(() { _loading = true; _errorMsg = null; });
    try {
      final res = await http.get(
        Uri.parse('$_kServerBase/status/all'),
        headers: {'Authorization': 'Bearer ${widget.sessionKey}'},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final all = List<Map<String, dynamic>>.from(data['statuses'] ?? []);
        final parsed =
            all.map((s) => UserStatus.fromJson(s, widget.username)).toList();
        setState(() {
          _myStatuses = parsed.where((s) => s.isOwn).toList();
          _othersStatuses = parsed.where((s) => !s.isOwn).toList();
        });
      } else {
        setState(() => _errorMsg = 'Server error: \${res.statusCode}');
      }
    } catch (e) {
      setState(() => _errorMsg = 'Koneksi gagal: \$e');
    }
    setState(() => _loading = false);
  }

  Future<void> _addStatus(String mediaUrl, String mediaType, String caption) async {
    try {
      await http.post(
        Uri.parse('$_kServerBase/status/create'),
        headers: {
          'Authorization': 'Bearer ${widget.sessionKey}',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'mediaUrl': mediaUrl,
          'mediaType': mediaType,
          'caption': caption,
          'username': widget.username,
        }),
      );
      await _loadStatuses();
    } catch (_) {}
  }

  void _showAddStatusSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _AddStatusSheet(
        sessionKey: widget.sessionKey,
        username: widget.username,
        onPost: (url, type, caption) {
          Navigator.pop(context);
          _addStatus(url, type, caption);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _bg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white, size: 16),
          ),
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('VTX STATUS',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
            Text('Stories & Updates',
                style: TextStyle(
                    color: Color(0xFF8B949E),
                    fontSize: 10,
                    fontFamily: 'ShareTechMono')),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF4A90C4)),
            onPressed: _loadStatuses,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddStatusSheet,
        backgroundColor: _accent,
        child: const Icon(Icons.add_a_photo, color: Colors.white),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF4A90C4)))
          : _errorMsg != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.cloud_off, color: Colors.redAccent, size: 52),
                      const SizedBox(height: 12),
                      Text(_errorMsg!, textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.redAccent, fontFamily: 'ShareTechMono', fontSize: 12)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: _loadStatuses,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Coba Lagi'),
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4A90C4)),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
              onRefresh: _loadStatuses,
              color: _accent,
              backgroundColor: _card,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // My Status
                  _buildSection(
                    title: 'Status Saya',
                    icon: Icons.person,
                    color: _accent,
                    statuses: _myStatuses,
                    isOwn: true,
                  ),
                  const SizedBox(height: 20),
                  // Others
                  _buildSection(
                    title: 'Status Teman',
                    icon: Icons.people,
                    color: const Color(0xFF4CAF50),
                    statuses: _othersStatuses,
                    isOwn: false,
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Color color,
    required List<UserStatus> statuses,
    required bool isOwn,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(title,
                style: TextStyle(
                    color: color,
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1)),
          ],
        ),
        const SizedBox(height: 12),
        if (statuses.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _border),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: _textSec, size: 18),
                const SizedBox(width: 10),
                Text(
                  isOwn
                      ? 'Belum ada status. Tekan + untuk buat status!'
                      : 'Tidak ada status dari teman',
                  style: const TextStyle(
                      color: Color(0xFF8B949E), fontSize: 12),
                ),
              ],
            ),
          )
        else
          SizedBox(
            height: 100,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: statuses.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (ctx, i) =>
                  _buildStatusBubble(ctx, statuses[i], isOwn),
            ),
          ),
      ],
    );
  }

  Widget _buildStatusBubble(
      BuildContext ctx, UserStatus status, bool isOwn) {
    return GestureDetector(
      onTap: () => Navigator.push(
        ctx,
        MaterialPageRoute(
          builder: (_) => StatusViewPage(
            statuses: isOwn ? _myStatuses : _getGroupByUser(status.username),
            initialIndex: 0,
            sessionKey: widget.sessionKey,
            myUsername: widget.username,
          ),
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFF4A90C4), Color(0xFF357ABD)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF4A90C4).withOpacity(0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(3),
              child: Container(
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFF0B0E14),
                ),
                child: ClipOval(
                  child: status.mediaType == 'image' && status.mediaUrl.isNotEmpty
                      ? Image.network(
                          status.mediaUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Center(
                            child: Text(
                              status.username.isNotEmpty
                                  ? status.username[0].toUpperCase()
                                  : '?',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22),
                            ),
                          ),
                        )
                      : Center(
                          child: Text(
                            status.username.isNotEmpty
                                ? status.username[0].toUpperCase()
                                : '?',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 22),
                          ),
                        ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          SizedBox(
            width: 64,
            child: Text(
              isOwn ? 'Saya' : status.username,
              style: const TextStyle(
                  color: Colors.white, fontSize: 10, fontFamily: 'ShareTechMono'),
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  List<UserStatus> _getGroupByUser(String username) {
    return _othersStatuses.where((s) => s.username == username).toList();
  }
}

// ============================================================
// ADD STATUS SHEET
// ============================================================
class _AddStatusSheet extends StatefulWidget {
  final String sessionKey;
  final String username;
  final Function(String url, String type, String caption) onPost;

  const _AddStatusSheet({
    required this.sessionKey,
    required this.username,
    required this.onPost,
  });

  @override
  State<_AddStatusSheet> createState() => _AddStatusSheetState();
}

class _AddStatusSheetState extends State<_AddStatusSheet> {
  final TextEditingController _captionCtrl = TextEditingController();
  final TextEditingController _textCtrl = TextEditingController();
  String? _selectedType;
  File? _selectedFile;
  bool _uploading = false;

  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _border = Color(0xFF252B36);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  Future<void> _pickMedia(String type) async {
    final picker = ImagePicker();
    XFile? picked;
    if (type == 'image') {
      picked = await picker.pickImage(source: ImageSource.gallery);
    } else {
      picked = await picker.pickVideo(source: ImageSource.gallery);
    }
    if (picked != null) {
      setState(() {
        _selectedFile = File(picked!.path);
        _selectedType = type;
      });
    }
  }

  Future<void> _upload() async {
    if (_selectedType == null) return;
    setState(() => _uploading = true);
    try {
      String mediaUrl = '';
      String mediaType = _selectedType!;

      if (_selectedType == 'text') {
        mediaUrl = '';
        mediaType = 'text';
        widget.onPost(mediaUrl, mediaType, _textCtrl.text.trim());
        return;
      }

      if (_selectedFile != null) {
        final req = http.MultipartRequest(
          'POST',
          Uri.parse('$_kServerBase/status/upload'),
        )
          ..headers['Authorization'] = 'Bearer ${widget.sessionKey}'
          ..files.add(await http.MultipartFile.fromPath(
              'file', _selectedFile!.path));

        final streamed = await req.send();
        final res = await http.Response.fromStream(streamed);
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          mediaUrl = data['url'] ?? '';
        }
      }

      widget.onPost(mediaUrl, mediaType, _captionCtrl.text.trim());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Gagal upload: $e'),
              backgroundColor: Colors.red.shade800),
        );
      }
    }
    setState(() => _uploading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFF252B36),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Buat Status Baru',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 15,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            // Type selector
            Row(
              children: [
                _typeBtn(Icons.image, 'Foto', 'image', const Color(0xFF4CAF50)),
                const SizedBox(width: 10),
                _typeBtn(Icons.videocam, 'Video', 'video',
                    const Color(0xFFFF5722)),
                const SizedBox(width: 10),
                _typeBtn(Icons.text_fields, 'Teks', 'text', _accent),
              ],
            ),
            const SizedBox(height: 16),
            // Preview
            if (_selectedFile != null && _selectedType == 'image')
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  _selectedFile!,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            if (_selectedFile != null && _selectedType == 'video')
              Container(
                height: 80,
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _border),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.videocam, color: Color(0xFFFF5722), size: 28),
                    SizedBox(width: 10),
                    Text('Video siap diupload',
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                  ],
                ),
              ),
            if (_selectedType == 'text')
              TextField(
                controller: _textCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: 'Tulis sesuatu...',
                  hintStyle: const TextStyle(color: Color(0xFF8B949E)),
                  filled: true,
                  fillColor: _bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            if (_selectedType != null && _selectedType != 'text') ...[
              const SizedBox(height: 12),
              TextField(
                controller: _captionCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Tambah keterangan...',
                  hintStyle: const TextStyle(color: _textSec),
                  filled: true,
                  fillColor: _bg,
                  prefixIcon:
                      const Icon(Icons.edit, color: _accent, size: 18),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 16),
            if (_selectedType != null)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _accent,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                  icon: _uploading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.send, color: Colors.white),
                  label: Text(
                    _uploading ? 'Mengunggah...' : 'Post Status',
                    style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold),
                  ),
                  onPressed: _uploading ? null : _upload,
                ),
              ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _typeBtn(
      IconData icon, String label, String type, Color color) {
    final selected = _selectedType == type;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (type != 'text') {
            _pickMedia(type);
          } else {
            setState(() => _selectedType = 'text');
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? color.withOpacity(0.2) : _bg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: selected ? color : const Color(0xFF252B36)),
          ),
          child: Column(
            children: [
              Icon(icon, color: selected ? color : const Color(0xFF8B949E),
                  size: 22),
              const SizedBox(height: 4),
              Text(label,
                  style: TextStyle(
                      color: selected ? color : const Color(0xFF8B949E),
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// STATUS VIEW PAGE (fullscreen, like story)
// ============================================================
class StatusViewPage extends StatefulWidget {
  final List<UserStatus> statuses;
  final int initialIndex;
  final String sessionKey;
  final String myUsername;

  const StatusViewPage({
    super.key,
    required this.statuses,
    required this.initialIndex,
    required this.sessionKey,
    required this.myUsername,
  });

  @override
  State<StatusViewPage> createState() => _StatusViewPageState();
}

class _StatusViewPageState extends State<StatusViewPage>
    with SingleTickerProviderStateMixin {
  late int _current;
  late AnimationController _progressCtrl;
  VideoPlayerController? _videoCtrl;

  @override
  void initState() {
    super.initState();
    _current = widget.initialIndex;
    _progressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _loadCurrent();
    _progressCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed) _next();
    });
    _markViewed();
  }

  void _loadCurrent() {
    final status = widget.statuses[_current];
    _progressCtrl.reset();
    if (status.mediaType == 'video' && status.mediaUrl.isNotEmpty) {
      _videoCtrl?.dispose();
      _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(status.mediaUrl))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {});
            _videoCtrl!.play();
            _progressCtrl.duration =
                _videoCtrl!.value.duration;
            _progressCtrl.forward();
          }
        });
    } else {
      _progressCtrl.duration = const Duration(seconds: 5);
      _progressCtrl.forward();
    }
    _markViewed();
  }

  Future<void> _markViewed() async {
    if (_current >= widget.statuses.length) return;
    final sid = widget.statuses[_current].id;
    try {
      await http.post(
        Uri.parse('$_kServerBase/status/view/$sid'),
        headers: {'Authorization': 'Bearer ${widget.sessionKey}'},
      );
    } catch (_) {}
  }

  void _next() {
    if (_current < widget.statuses.length - 1) {
      setState(() => _current++);
      _loadCurrent();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_current > 0) {
      setState(() => _current--);
      _loadCurrent();
    }
  }

  @override
  void dispose() {
    _progressCtrl.dispose();
    _videoCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = widget.statuses[_current];
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.localPosition.dx < w / 3) {
            _prev();
          } else if (d.localPosition.dx > w * 2 / 3) {
            _next();
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Media
            _buildMedia(status),
            // Gradient overlay top
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: 120,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
              ),
            ),
            // Gradient overlay bottom
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: 120,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
              ),
            ),
            // Top UI
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                child: Column(
                  children: [
                    // Progress bars
                    Row(
                      children: List.generate(widget.statuses.length, (i) {
                        return Expanded(
                          child: Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 2),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(2),
                              child: LinearProgressIndicator(
                                value: i < _current
                                    ? 1.0
                                    : i == _current
                                        ? _progressCtrl.value
                                        : 0.0,
                                backgroundColor: Colors.white30,
                                valueColor:
                                    const AlwaysStoppedAnimation<Color>(
                                        Colors.white),
                                minHeight: 3,
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor:
                              const Color(0xFF4A90C4).withOpacity(0.3),
                          child: Text(
                            status.username.isNotEmpty
                                ? status.username[0].toUpperCase()
                                : '?',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(status.username,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                    fontFamily: 'Orbitron')),
                            Text(
                              _timeAgo(status.createdAt),
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 11),
                            ),
                          ],
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 24),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // Caption
            if (status.caption.isNotEmpty)
              Positioned(
                bottom: 40,
                left: 16,
                right: 16,
                child: Text(
                  status.caption,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      shadows: [Shadow(color: Colors.black, blurRadius: 8)]),
                  textAlign: TextAlign.center,
                ),
              ),
            // Viewer count (own status)
            if (status.isOwn && status.viewers.isNotEmpty)
              Positioned(
                bottom: 16,
                left: 0,
                right: 0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.visibility,
                        color: Colors.white70, size: 16),
                    const SizedBox(width: 4),
                    Text('${status.viewers.length} dilihat',
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 12)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMedia(UserStatus status) {
    if (status.mediaType == 'text') {
      return Container(
        color: const Color(0xFF151A23),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(40),
            child: Text(
              status.caption,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron'),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }
    if (status.mediaType == 'video' &&
        _videoCtrl != null &&
        _videoCtrl!.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.contain,
        child: SizedBox(
          width: _videoCtrl!.value.size.width,
          height: _videoCtrl!.value.size.height,
          child: VideoPlayer(_videoCtrl!),
        ),
      );
    }
    if (status.mediaUrl.isNotEmpty) {
      return Image.network(
        status.mediaUrl,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => const Center(
          child:
              Icon(Icons.broken_image, color: Colors.white38, size: 60),
        ),
      );
    }
    return Container(color: const Color(0xFF0B0E14));
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes}m lalu';
    if (diff.inDays < 1) return '${diff.inHours}j lalu';
    return '${diff.inDays}h lalu';
  }
}
