import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as path;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:permission_handler/permission_handler.dart';

// ============================================================
// CONSTANTS
// ============================================================
const String _kServerBase = 'http://panel-legal.jhonaley.net:2983'; // Ganti URL server kamu
const String _kWsUrl = 'ws://panel-legal.jhonaley.net:2983'; // Ganti WS server kamu

// ============================================================
// MODEL
// ============================================================
class ChatMessage {
  final String id;
  final String senderId;
  final String senderName;
  final String content;
  final String type; // text | image | video | audio | file | zip
  final DateTime time;
  final bool isMe;
  final String? fileUrl;
  final String? fileName;

  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.content,
    required this.type,
    required this.time,
    required this.isMe,
    this.fileUrl,
    this.fileName,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j, String myId) {
    return ChatMessage(
      id: j['id']?.toString() ?? '',
      senderId: j['senderId']?.toString() ?? '',
      senderName: j['senderName']?.toString() ?? 'Unknown',
      content: j['content']?.toString() ?? '',
      type: j['type']?.toString() ?? 'text',
      time: DateTime.tryParse(j['time']?.toString() ?? '') ?? DateTime.now(),
      isMe: j['senderId']?.toString() == myId,
      fileUrl: j['fileUrl']?.toString(),
      fileName: j['fileName']?.toString(),
    );
  }
}

// ============================================================
// MAIN CHAT HUB (Public & Private Tab)
// ============================================================
class ChatHubPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const ChatHubPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<ChatHubPage> createState() => _ChatHubPageState();
}

class _ChatHubPageState extends State<ChatHubPage>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  // Colors
  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _border = Color(0xFF252B36);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _bg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white, size: 16),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('VTX CHAT',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
            Text('Hi, ${widget.username}',
                style: const TextStyle(
                    color: _textSec,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono')),
          ],
        ),
        actions: [
          // Search private user button
          IconButton(
            icon: const Icon(Icons.search, color: _accent),
            onPressed: () => _openPrivateSearch(context),
            tooltip: 'Cari User Private Chat',
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          indicatorColor: _accent,
          labelColor: _accent,
          unselectedLabelColor: _textSec,
          labelStyle: const TextStyle(
              fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold),
          tabs: const [
            Tab(text: 'PUBLIC', icon: Icon(Icons.public, size: 18)),
            Tab(text: 'PRIVATE', icon: Icon(Icons.lock, size: 18)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // Public Chat Room
          ChatRoomPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
            roomId: 'public_global',
            roomName: 'Public Room',
            isPublic: true,
          ),
          // Private: list conversations
          PrivateConversationsPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
          ),
        ],
      ),
    );
  }

  void _openPrivateSearch(BuildContext context) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 20,
            right: 20,
            top: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Cari Username',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 14,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              autofocus: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Ketik username...',
                hintStyle: const TextStyle(color: _textSec),
                filled: true,
                fillColor: _bg,
                prefixIcon: const Icon(Icons.person_search, color: _accent),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                    backgroundColor: _accent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                icon: const Icon(Icons.chat, color: Colors.white),
                label: const Text('Mulai Chat',
                    style: TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold)),
                onPressed: () {
                  final target = ctrl.text.trim();
                  if (target.isEmpty) return;
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatRoomPage(
                        sessionKey: widget.sessionKey,
                        username: widget.username,
                        roomId:
                            'private_${_sortedRoom(widget.username, target)}',
                        roomName: target,
                        isPublic: false,
                        peerUsername: target,
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  String _sortedRoom(String a, String b) {
    final sorted = [a, b]..sort();
    return sorted.join('_');
  }
}

// ============================================================
// PRIVATE CONVERSATION LIST
// ============================================================
class PrivateConversationsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const PrivateConversationsPage(
      {super.key, required this.sessionKey, required this.username});

  @override
  State<PrivateConversationsPage> createState() =>
      _PrivateConversationsPageState();
}

class _PrivateConversationsPageState extends State<PrivateConversationsPage> {
  List<Map<String, dynamic>> _convos = [];
  bool _loading = true;

  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _border = Color(0xFF252B36);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  @override
  void initState() {
    super.initState();
    _loadConversations();
  }

  Future<void> _loadConversations() async {
    try {
      final res = await http.get(
        Uri.parse('$_kServerBase/chat/conversations'),
        headers: {'Authorization': 'Bearer ${widget.sessionKey}'},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _convos = List<Map<String, dynamic>>.from(data['conversations'] ?? []);
          _loading = false;
        });
      } else {
        setState(() => _loading = false);
      }
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(color: Color(0xFF4A90C4)));
    }
    if (_convos.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.chat_bubble_outline, color: _textSec, size: 48),
            const SizedBox(height: 12),
            const Text('Belum ada percakapan',
                style: TextStyle(
                    color: _textSec,
                    fontFamily: 'ShareTechMono',
                    fontSize: 13)),
            const SizedBox(height: 8),
            const Text('Tekan ikon search untuk mulai chat privat',
                style: TextStyle(
                    color: _textSec, fontSize: 11),
                textAlign: TextAlign.center),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _convos.length,
      itemBuilder: (ctx, i) {
        final c = _convos[i];
        final peer = c['peerUsername']?.toString() ?? '';
        final lastMsg = c['lastMessage']?.toString() ?? '';
        final time = c['time']?.toString() ?? '';
        return GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChatRoomPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                roomId: 'private_${_sortedRoom(widget.username, peer)}',
                roomName: peer,
                isPublic: false,
                peerUsername: peer,
              ),
            ),
          ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _border),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: _accent.withOpacity(0.2),
                  radius: 24,
                  child: Text(
                    peer.isNotEmpty ? peer[0].toUpperCase() : '?',
                    style: const TextStyle(
                        color: _accent,
                        fontWeight: FontWeight.bold,
                        fontSize: 16),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(peer,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              fontSize: 13)),
                      const SizedBox(height: 3),
                      Text(lastMsg,
                          style:
                              const TextStyle(color: _textSec, fontSize: 12),
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                Text(time,
                    style:
                        const TextStyle(color: _textSec, fontSize: 10)),
              ],
            ),
          ),
        );
      },
    );
  }

  String _sortedRoom(String a, String b) {
    final sorted = [a, b]..sort();
    return sorted.join('_');
  }
}

// ============================================================
// CHAT ROOM (Public or Private)
// ============================================================
class ChatRoomPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String roomId;
  final String roomName;
  final bool isPublic;
  final String? peerUsername;

  const ChatRoomPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.roomId,
    required this.roomName,
    required this.isPublic,
    this.peerUsername,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<ChatMessage> _messages = [];
  IO.Socket? _socket;
  bool _sending = false;
  bool _isRecording = false;
  bool _loading = true;
  String? _errorMsg;

  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _border = Color(0xFF252B36);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  @override
  void initState() {
    super.initState();
    _connectSocket();
    _loadHistory();
  }

  void _connectSocket() {
    _socket = IO.io(
      _kWsUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': widget.sessionKey})
          .build(),
    );

    _socket!.onConnect((_) {
      _socket!.emit('join_room', {'room': widget.roomId});
    });

    _socket!.on('new_message', (data) {
      if (!mounted) return;
      final msg = ChatMessage.fromJson(
          Map<String, dynamic>.from(data), widget.username);
      setState(() => _messages.add(msg));
      _scrollToBottom();
    });

    _socket!.onDisconnect((_) {});
  }

  Future<void> _loadHistory() async {
    if (mounted) setState(() { _loading = true; _errorMsg = null; });
    try {
      final res = await http.get(
        Uri.parse('$_kServerBase/chat/history/${widget.roomId}'),
        headers: {'Authorization': 'Bearer ${widget.sessionKey}'},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final msgs = List<Map<String, dynamic>>.from(data['messages'] ?? []);
        if (mounted) {
          setState(() {
            _messages.clear();
            _messages.addAll(msgs
                .map((m) => ChatMessage.fromJson(m, widget.username)));
            _loading = false;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
        }
      } else {
        if (mounted) setState(() { _loading = false; _errorMsg = 'Server error: \${res.statusCode}'; });
      }
    } catch (e) {
      if (mounted) setState(() { _loading = false; _errorMsg = 'Koneksi gagal: \$e'; });
    }
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut);
      }
    });
  }

  Future<void> _sendText() async {
    final txt = _msgCtrl.text.trim();
    if (txt.isEmpty || _sending) return;
    _msgCtrl.clear();
    setState(() => _sending = true);
    try {
      _socket?.emit('send_message', {
        'room': widget.roomId,
        'content': txt,
        'type': 'text',
        'senderName': widget.username,
      });
    } catch (_) {}
    setState(() => _sending = false);
  }

  Future<void> _sendFile(String type) async {
    try {
      File? file;
      String? fileName;

      if (type == 'image' || type == 'video') {
        final picker = ImagePicker();
        final XFile? picked = type == 'image'
            ? await picker.pickImage(source: ImageSource.gallery)
            : await picker.pickVideo(source: ImageSource.gallery);
        if (picked == null) return;
        file = File(picked.path);
        fileName = path.basename(picked.path);
      } else {
        // zip, audio, file
        final result = await FilePicker.platform.pickFiles(
          type: type == 'audio' ? FileType.audio : FileType.any,
          allowMultiple: false,
        );
        if (result == null || result.files.isEmpty) return;
        final pf = result.files.first;
        if (pf.path == null) return;
        file = File(pf.path!);
        fileName = pf.name;
      }

      if (file == null) return;

      // Upload ke server
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('$_kServerBase/chat/upload'),
      )
        ..headers['Authorization'] = 'Bearer ${widget.sessionKey}'
        ..fields['room'] = widget.roomId
        ..fields['type'] = type
        ..fields['senderName'] = widget.username
        ..files.add(await http.MultipartFile.fromPath('file', file.path,
            filename: fileName));

      final streamed = await req.send();
      final res = await http.Response.fromStream(streamed);
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        _socket?.emit('send_message', {
          'room': widget.roomId,
          'content': fileName ?? 'file',
          'type': type,
          'fileUrl': data['url'],
          'fileName': fileName,
          'senderName': widget.username,
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Gagal kirim: $e'),
              backgroundColor: Colors.red.shade800),
        );
      }
    }
  }

  void _showAttachmentMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Kirim File',
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 14,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _attachBtn(Icons.image, 'Foto', const Color(0xFF4CAF50),
                    () { Navigator.pop(context); _sendFile('image'); }),
                _attachBtn(Icons.videocam, 'Video', const Color(0xFFFF5722),
                    () { Navigator.pop(context); _sendFile('video'); }),
                _attachBtn(Icons.audiotrack, 'Audio', const Color(0xFF9C27B0),
                    () { Navigator.pop(context); _sendFile('audio'); }),
                _attachBtn(Icons.folder_zip, 'ZIP', const Color(0xFFFF9800),
                    () { Navigator.pop(context); _sendFile('zip'); }),
                _attachBtn(Icons.insert_drive_file, 'File', _accent,
                    () { Navigator.pop(context); _sendFile('file'); }),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _attachBtn(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.4)),
            ),
            child: Icon(icon, color: color, size: 26),
          ),
          const SizedBox(height: 6),
          Text(label,
              style: TextStyle(
                  color: color, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  void _startCall({bool isVideo = false}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          peerUsername: widget.peerUsername ?? widget.roomName,
          isVideo: isVideo,
          roomId: widget.roomId,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _socket?.disconnect();
    _msgCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _bg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _border),
            ),
            child: const Icon(Icons.arrow_back_ios_new,
                color: Colors.white, size: 16),
          ),
        ),
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: _accent.withOpacity(0.2),
              radius: 18,
              child: Icon(
                widget.isPublic ? Icons.public : Icons.person,
                color: _accent,
                size: 18,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.roomName,
                  style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontSize: 13,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  widget.isPublic ? 'Public Room' : 'Private Chat',
                  style:
                      const TextStyle(color: _textSec, fontSize: 10),
                ),
              ],
            ),
          ],
        ),
        actions: [
          if (!widget.isPublic) ...[
            IconButton(
              icon: const Icon(Icons.call, color: Color(0xFF4CAF50)),
              onPressed: () => _startCall(isVideo: false),
              tooltip: 'Voice Call',
            ),
            IconButton(
              icon: const Icon(Icons.videocam, color: _accent),
              onPressed: () => _startCall(isVideo: true),
              tooltip: 'Video Call',
            ),
          ],
        ],
      ),
      body: Column(
        children: [
          // Messages
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _accent))
                : _errorMsg != null
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.wifi_off, color: Colors.redAccent, size: 48),
                            const SizedBox(height: 12),
                            Text(_errorMsg!, textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.redAccent, fontFamily: 'ShareTechMono', fontSize: 12)),
                            const SizedBox(height: 16),
                            ElevatedButton.icon(
                              onPressed: _loadHistory,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Coba Lagi'),
                              style: ElevatedButton.styleFrom(backgroundColor: _accent),
                            ),
                          ],
                        ),
                      )
                    : _messages.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.chat_bubble_outline,
                                    color: _textSec, size: 40),
                                const SizedBox(height: 8),
                                Text(
                                  widget.isPublic
                                      ? 'Mulai ngobrol di public room!'
                                      : 'Mulai chat dengan \${widget.roomName}',
                                  style: const TextStyle(
                                      color: _textSec,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 13),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            itemCount: _messages.length,
                            itemBuilder: (_, i) =>
                                _buildMessageBubble(_messages[i]),
                          ),
          ),
          // Input
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isMe = msg.isMe;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: _accent.withOpacity(0.2),
              child: Text(
                msg.senderName.isNotEmpty
                    ? msg.senderName[0].toUpperCase()
                    : '?',
                style: const TextStyle(
                    color: _accent, fontSize: 11, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.72),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isMe ? _accent.withOpacity(0.85) : _card,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: isMe
                      ? const Radius.circular(16)
                      : const Radius.circular(4),
                  bottomRight: isMe
                      ? const Radius.circular(4)
                      : const Radius.circular(16),
                ),
                border: Border.all(
                    color: isMe
                        ? Colors.transparent
                        : _border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe && widget.isPublic)
                    Text(msg.senderName,
                        style: const TextStyle(
                            color: _accent,
                            fontFamily: 'Orbitron',
                            fontSize: 10,
                            fontWeight: FontWeight.bold)),
                  if (!isMe && widget.isPublic)
                    const SizedBox(height: 4),
                  _buildMsgContent(msg),
                  const SizedBox(height: 4),
                  Text(
                    '${msg.time.hour.toString().padLeft(2, '0')}:${msg.time.minute.toString().padLeft(2, '0')}',
                    style: TextStyle(
                        color: isMe
                            ? Colors.white70
                            : _textSec,
                        fontSize: 9),
                  ),
                ],
              ),
            ),
          ),
          if (isMe) const SizedBox(width: 8),
        ],
      ),
    );
  }

  Widget _buildMsgContent(ChatMessage msg) {
    switch (msg.type) {
      case 'image':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (msg.fileUrl != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  msg.fileUrl!,
                  width: 200,
                  height: 150,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                      Icons.broken_image, color: Colors.white54, size: 40),
                ),
              ),
          ],
        );
      case 'video':
        return Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.play_circle_outline,
                  color: Colors.white, size: 28),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                msg.fileName ?? 'Video',
                style: const TextStyle(color: Colors.white, fontSize: 12),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        );
      case 'audio':
        return Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.audiotrack,
                  color: Colors.white, size: 24),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                msg.fileName ?? 'Audio',
                style: const TextStyle(color: Colors.white, fontSize: 12),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        );
      case 'zip':
      case 'file':
        return Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                msg.type == 'zip'
                    ? Icons.folder_zip
                    : Icons.insert_drive_file,
                color: Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                msg.fileName ?? 'File',
                style: const TextStyle(color: Colors.white, fontSize: 12),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        );
      default:
        return Text(
          msg.content,
          style: const TextStyle(color: Colors.white, fontSize: 13),
        );
    }
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _card,
        border: Border(top: BorderSide(color: _border)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Attachment
            GestureDetector(
              onTap: _showAttachmentMenu,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _bg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _border),
                ),
                child:
                    const Icon(Icons.attach_file, color: _accent, size: 20),
              ),
            ),
            const SizedBox(width: 8),
            // Text Field
            Expanded(
              child: TextField(
                controller: _msgCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                maxLines: null,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendText(),
                decoration: InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle:
                      const TextStyle(color: _textSec, fontSize: 13),
                  filled: true,
                  fillColor: _bg,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Send Button
            GestureDetector(
              onTap: _sendText,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF4A90C4), Color(0xFF357ABD)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: _accent.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(Icons.send, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// CALL PAGE (Voice & Video)
// ============================================================
class CallPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String peerUsername;
  final bool isVideo;
  final String roomId;

  const CallPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.peerUsername,
    required this.isVideo,
    required this.roomId,
  });

  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  bool _connected = false;
  bool _muted = false;
  bool _speakerOn = true;
  IO.Socket? _socket;
  Duration _duration = Duration.zero;
  Timer? _timer;

  static const Color _bg = Color(0xFF0B0E14);
  static const Color _card = Color(0xFF151A23);
  static const Color _accent = Color(0xFF4A90C4);
  static const Color _textSec = Color(0xFF8B949E);

  @override
  void initState() {
    super.initState();
    _connectCall();
  }

  void _connectCall() {
    _socket = IO.io(
      _kWsUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': widget.sessionKey})
          .build(),
    );

    _socket!.onConnect((_) {
      _socket!.emit('initiate_call', {
        'room': widget.roomId,
        'caller': widget.username,
        'callee': widget.peerUsername,
        'type': widget.isVideo ? 'video' : 'voice',
      });
    });

    _socket!.on('call_accepted', (_) {
      if (!mounted) return;
      setState(() => _connected = true);
      _startTimer();
    });

    _socket!.on('call_ended', (_) {
      if (mounted) Navigator.pop(context);
    });
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _duration += const Duration(seconds: 1));
    });
  }

  void _endCall() {
    _socket?.emit('end_call', {'room': widget.roomId});
    Navigator.pop(context);
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _socket?.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(
          children: [
            // Top: peer info
            const SizedBox(height: 60),
            CircleAvatar(
              radius: 52,
              backgroundColor: _accent.withOpacity(0.15),
              child: Text(
                widget.peerUsername.isNotEmpty
                    ? widget.peerUsername[0].toUpperCase()
                    : '?',
                style: const TextStyle(
                    color: _accent,
                    fontSize: 36,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),
            Text(widget.peerUsername,
                style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              _connected
                  ? _formatDuration(_duration)
                  : (widget.isVideo ? 'Menghubungkan video...' : 'Menghubungkan...'),
              style: TextStyle(
                  color: _connected ? const Color(0xFF4CAF50) : _textSec,
                  fontFamily: 'ShareTechMono',
                  fontSize: 14),
            ),
            const Spacer(),
            // Controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _callBtn(
                  icon: _muted ? Icons.mic_off : Icons.mic,
                  color: _muted ? Colors.red : _card,
                  iconColor: _muted ? Colors.white : _textSec,
                  onTap: () => setState(() => _muted = !_muted),
                  label: _muted ? 'Unmute' : 'Mute',
                ),
                const SizedBox(width: 20),
                // End Call
                GestureDetector(
                  onTap: _endCall,
                  child: Column(
                    children: [
                      Container(
                        width: 68,
                        height: 68,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.red.withOpacity(0.4),
                              blurRadius: 16,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.call_end,
                            color: Colors.white, size: 30),
                      ),
                      const SizedBox(height: 6),
                      const Text('Tutup',
                          style:
                              TextStyle(color: Colors.redAccent, fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(width: 20),
                _callBtn(
                  icon: _speakerOn ? Icons.volume_up : Icons.volume_off,
                  color: _speakerOn ? _accent.withOpacity(0.2) : _card,
                  iconColor: _speakerOn ? _accent : _textSec,
                  onTap: () => setState(() => _speakerOn = !_speakerOn),
                  label: 'Speaker',
                ),
              ],
            ),
            const SizedBox(height: 60),
          ],
        ),
      ),
    );
  }

  Widget _callBtn({
    required IconData icon,
    required Color color,
    required Color iconColor,
    required VoidCallback onTap,
    required String label,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF252B36)),
            ),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(height: 6),
          Text(label,
              style: const TextStyle(color: Color(0xFF8B949E), fontSize: 11)),
        ],
      ),
    );
  }
}
