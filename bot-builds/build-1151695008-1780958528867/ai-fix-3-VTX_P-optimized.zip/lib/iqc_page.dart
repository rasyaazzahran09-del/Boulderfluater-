import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

// =====================================================
// IQC PAGE — Image Quality Check & Enhance
// Menggunakan api.siputzx.my.id — Tanpa server
// =====================================================

class IqcPage extends StatefulWidget {
  const IqcPage({super.key});

  @override
  State<IqcPage> createState() => _IqcPageState();
}

class _IqcPageState extends State<IqcPage> with SingleTickerProviderStateMixin {
  File? _selectedImage;
  bool _isAnalyzing = false;
  bool _isEnhancing = false;
  Map<String, dynamic>? _analysisResult;
  String? _enhancedImageUrl;
  late TabController _tabController;
  final ImagePicker _picker = ImagePicker();

  static const String _apiBase = 'https://api.siputzx.my.id';

  final Color _bg = const Color(0xFF0B0E14);
  final Color _card = const Color(0xFF151A23);
  final Color _accent = const Color(0xFF7C3AED);
  final Color _accent2 = const Color(0xFFAB47BC);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final xfile = await _picker.pickImage(source: source, imageQuality: 95);
      if (xfile == null) return;
      setState(() {
        _selectedImage = File(xfile.path);
        _analysisResult = null;
        _enhancedImageUrl = null;
      });
    } catch (e) {
      _snack('Gagal memilih gambar: $e', isError: true);
    }
  }

  Future<void> _analyzeImage() async {
    if (_selectedImage == null) return;
    setState(() { _isAnalyzing = true; _analysisResult = null; });

    try {
      // Upload gambar ke siputzx image tools
      final uri = Uri.parse('$_apiBase/api/tools/image-info');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(await http.MultipartFile.fromPath('image', _selectedImage!.path));
      final streamed = await req.send().timeout(const Duration(seconds: 20));
      final res = await http.Response.fromStream(streamed);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == true) {
          setState(() => _analysisResult = data['data'] ?? data['result'] ?? {});
          return;
        }
      }

      // Fallback: analisis lokal dari metadata file
      final bytes = await _selectedImage!.readAsBytes();
      final stat = await _selectedImage!.stat();
      setState(() {
        _analysisResult = {
          'file_size': '${(stat.size / 1024).toStringAsFixed(1)} KB',
          'bytes': bytes.length,
          'path': _selectedImage!.path.split('/').last,
          'format': _selectedImage!.path.split('.').last.toUpperCase(),
          'status': 'Analisis lokal (API tidak tersedia)',
          'quality_score': _calcQualityScore(stat.size),
          'recommendation': _getRecommendation(stat.size),
        };
      });
    } catch (e) {
      _snack('Gagal analisis: $e', isError: true);
    } finally {
      setState(() => _isAnalyzing = false);
    }
  }

  int _calcQualityScore(int bytes) {
    if (bytes > 2000000) return 95;
    if (bytes > 500000) return 80;
    if (bytes > 100000) return 65;
    return 45;
  }

  String _getRecommendation(int bytes) {
    if (bytes > 2000000) return 'Kualitas sangat baik, siap digunakan';
    if (bytes > 500000) return 'Kualitas baik, cocok untuk media sosial';
    if (bytes > 100000) return 'Kualitas sedang, bisa di-enhance';
    return 'Kualitas rendah, disarankan untuk di-enhance';
  }

  Future<void> _enhanceImage() async {
    if (_selectedImage == null) return;
    setState(() { _isEnhancing = true; _enhancedImageUrl = null; });

    try {
      // Endpoint enhance/upscale siputzx
      final uri = Uri.parse('$_apiBase/api/tools/remini');
      final req = http.MultipartRequest('POST', uri);
      req.files.add(await http.MultipartFile.fromPath('image', _selectedImage!.path));
      final streamed = await req.send().timeout(const Duration(seconds: 40));
      final res = await http.Response.fromStream(streamed);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final url = data['data']?['url'] ?? data['result']?['url'] ?? data['url'] ?? '';
        if (url.toString().isNotEmpty) {
          setState(() => _enhancedImageUrl = url.toString());
          _snack('✅ Gambar berhasil di-enhance!');
          return;
        }
      }

      // Fallback: remini endpoint alternatif
      final uri2 = Uri.parse('$_apiBase/api/tools/enhance');
      final req2 = http.MultipartRequest('POST', uri2);
      req2.files.add(await http.MultipartFile.fromPath('image', _selectedImage!.path));
      final streamed2 = await req2.send().timeout(const Duration(seconds: 40));
      final res2 = await http.Response.fromStream(streamed2);

      if (res2.statusCode == 200) {
        // Jika langsung gambar binary
        if (res2.headers['content-type']?.contains('image') == true) {
          final dir = await getTemporaryDirectory();
          final f = File('${dir.path}/enhanced_${DateTime.now().millisecondsSinceEpoch}.jpg');
          await f.writeAsBytes(res2.bodyBytes);
          setState(() => _enhancedImageUrl = 'file://${f.path}');
          _snack('✅ Gambar berhasil di-enhance!');
          return;
        }
        final data2 = jsonDecode(res2.body);
        final url2 = data2['data']?['url'] ?? data2['result'] ?? '';
        if (url2.toString().isNotEmpty) {
          setState(() => _enhancedImageUrl = url2.toString());
          _snack('✅ Gambar berhasil di-enhance!');
          return;
        }
      }

      _snack('Enhance API tidak tersedia saat ini', isError: true);
    } catch (e) {
      _snack('Gagal enhance: $e', isError: true);
    } finally {
      setState(() => _isEnhancing = false);
    }
  }

  Future<void> _downloadEnhanced() async {
    if (_enhancedImageUrl == null) return;
    try {
      if (Platform.isAndroid) {
        final status = await Permission.storage.request();
        if (!status.isGranted) {
          await Permission.manageExternalStorage.request();
        }
      }

      List<int> bytes;
      if (_enhancedImageUrl!.startsWith('file://')) {
        bytes = await File(_enhancedImageUrl!.replaceFirst('file://', '')).readAsBytes();
      } else {
        final res = await http.get(Uri.parse(_enhancedImageUrl!))
            .timeout(const Duration(seconds: 30));
        bytes = res.bodyBytes;
      }

      Directory? saveDir;
      if (Platform.isAndroid) {
        saveDir = Directory('/storage/emulated/0/Pictures/VTX');
        if (!await saveDir.exists()) await saveDir.create(recursive: true);
      } else {
        saveDir = await getApplicationDocumentsDirectory();
      }

      final file = File('${saveDir.path}/iqc_enhanced_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(bytes);
      _snack('✅ Tersimpan ke Galeri: ${file.path.split('/').last}');
    } catch (e) {
      _snack('Gagal simpan: $e', isError: true);
    }
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red.shade700 : _accent,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('IQC — Image Quality Check',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 13)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: _accent,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey,
          tabs: const [
            Tab(icon: Icon(Icons.analytics_outlined), text: 'Analisis'),
            Tab(icon: Icon(Icons.auto_fix_high), text: 'Enhance'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [_buildAnalysisTab(), _buildEnhanceTab()],
      ),
    );
  }

  // ── TAB 1: Analisis ──
  Widget _buildAnalysisTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        _buildPickerCard(),
        const SizedBox(height: 16),
        if (_selectedImage != null) ...[
          _buildImagePreview(),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: _isAnalyzing
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.analytics, color: Colors.white),
              label: Text(_isAnalyzing ? 'MENGANALISIS...' : 'ANALISIS KUALITAS',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
              onPressed: _isAnalyzing ? null : _analyzeImage,
            ),
          ),
          const SizedBox(height: 16),
          if (_analysisResult != null) _buildAnalysisResult(),
        ],
      ]),
    );
  }

  // ── TAB 2: Enhance ──
  Widget _buildEnhanceTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        _buildPickerCard(),
        const SizedBox(height: 16),
        if (_selectedImage != null) ...[
          _buildImagePreview(),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7C3AED),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              icon: _isEnhancing
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.auto_fix_high, color: Colors.white),
              label: Text(_isEnhancing ? 'MEMPROSES...' : 'ENHANCE GAMBAR (AI)',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
              onPressed: _isEnhancing ? null : _enhanceImage,
            ),
          ),
          const SizedBox(height: 16),
          if (_enhancedImageUrl != null) ...[
            const Text('Hasil Enhanced:', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: _enhancedImageUrl!.startsWith('file://')
                  ? Image.file(File(_enhancedImageUrl!.replaceFirst('file://', '')), fit: BoxFit.contain)
                  : Image.network(_enhancedImageUrl!, fit: BoxFit.contain,
                      loadingBuilder: (_, child, prog) => prog == null ? child
                          : const Center(child: CircularProgressIndicator(color: Color(0xFF7C3AED)))),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4CAF50),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.download, color: Colors.white),
                label: const Text('SIMPAN KE GALERI',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
                onPressed: _downloadEnhanced,
              ),
            ),
          ],
        ],
      ]),
    );
  }

  Widget _buildPickerCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _accent.withOpacity(0.3))),
      child: Column(children: [
        Icon(Icons.image_search, color: _accent, size: 40),
        const SizedBox(height: 12),
        const Text('Pilih Gambar', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _accent),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: Icon(Icons.photo_library, color: _accent),
            label: Text('Galeri', style: TextStyle(color: _accent)),
            onPressed: () => _pickImage(ImageSource.gallery),
          )),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _accent2),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: Icon(Icons.camera_alt, color: _accent2),
            label: Text('Kamera', style: TextStyle(color: _accent2)),
            onPressed: () => _pickImage(ImageSource.camera),
          )),
        ]),
      ]),
    );
  }

  Widget _buildImagePreview() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.file(_selectedImage!, height: 200, width: double.infinity, fit: BoxFit.cover),
    );
  }

  Widget _buildAnalysisResult() {
    final score = _analysisResult!['quality_score'] as int? ?? 0;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _accent.withOpacity(0.3))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Hasil Analisis', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 12),

        if (score > 0) ...[
          Row(children: [
            const Text('Score Kualitas:', style: TextStyle(color: Colors.grey)),
            const Spacer(),
            Text('$score/100', style: TextStyle(
              color: score > 75 ? Colors.green : score > 50 ? Colors.orange : Colors.red,
              fontWeight: FontWeight.bold, fontSize: 18,
            )),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: score / 100,
            backgroundColor: Colors.grey.shade700,
            color: score > 75 ? Colors.green : score > 50 ? Colors.orange : Colors.red,
            minHeight: 8,
          ),
          const SizedBox(height: 12),
        ],

        ..._analysisResult!.entries.where((e) => e.key != 'quality_score').map((e) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 2, child: Text(e.key.replaceAll('_', ' ').toUpperCase(),
                style: const TextStyle(color: Colors.grey, fontSize: 11))),
            Expanded(flex: 3, child: Text('${e.value}',
                style: const TextStyle(color: Colors.white, fontSize: 12))),
          ]),
        )).toList(),
      ]),
    );
  }
}
