import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';

// =====================================================
// SPOTIFY PAGE — Menggunakan api.siputzx.my.id
// Tanpa server, langsung ke API
// =====================================================

class SpotifyPage extends StatefulWidget {
  const SpotifyPage({super.key});

  @override
  State<SpotifyPage> createState() => _SpotifyPageState();
}

class _SpotifyPageState extends State<SpotifyPage> {
  final TextEditingController _searchController = TextEditingController();
  VideoPlayerController? _videoController;
  bool _isLoading = false;
  bool _isPlaying = false;
  bool _isDownloading = false;
  bool _hasSearchResult = false;
  Map<String, dynamic>? _trackData;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  static const String _apiBase = 'https://api.siputzx.my.id';

  @override
  void dispose() {
    _videoController?.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initPlayer(String url) async {
    await _videoController?.dispose();
    _videoController = VideoPlayerController.networkUrl(Uri.parse(url));
    await _videoController!.initialize();
    _videoController!.addListener(() {
      if (mounted) {
        setState(() {
          _isPlaying = _videoController!.value.isPlaying;
          _position = _videoController!.value.position;
          _duration = _videoController!.value.duration;
        });
      }
    });
    await _videoController!.play();
    setState(() => _isPlaying = true);
  }

  Future<void> _searchTrack() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _isLoading = true;
      _hasSearchResult = false;
      _isPlaying = false;
      _position = Duration.zero;
      _duration = Duration.zero;
      _trackData = null;
    });

    try {
      // Coba endpoint spotify search siputzx
      final encoded = Uri.encodeComponent(query);
      final res = await http.get(
        Uri.parse('$_apiBase/api/d/spotify?query=$encoded'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        if (data['status'] == true && data['data'] != null) {
          setState(() {
            _trackData = data['data'];
            _hasSearchResult = true;
          });
          final url = data['data']['url'] ?? data['data']['preview_url'] ?? '';
          if (url.isNotEmpty) await _initPlayer(url);
          return;
        }
      }

      // Fallback: endpoint spotifyplay deline
      final res2 = await http.get(
        Uri.parse('https://api.deline.web.id/downloader/spotifyplay?q=$encoded'),
      ).timeout(const Duration(seconds: 15));

      if (res2.statusCode == 200) {
        final data2 = json.decode(res2.body);
        if (data2['status'] == true && data2['result'] != null) {
          setState(() {
            _trackData = {
              'title': data2['result']['metadata']?['title'] ?? query,
              'artist': data2['result']['metadata']?['artist'] ?? '',
              'cover': data2['result']['metadata']?['cover'] ?? '',
              'duration': data2['result']['metadata']?['duration'] ?? '',
              'url': data2['result']['dlink'] ?? '',
            };
            _hasSearchResult = true;
          });
          final url = data2['result']['dlink'] ?? '';
          if (url.isNotEmpty) await _initPlayer(url);
          return;
        }
      }

      _showSnack('Lagu tidak ditemukan', isError: true);
    } catch (e) {
      _showSnack('Error: $e', isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _downloadTrack() async {
    if (_trackData == null) return;
    final url = _trackData!['url'] ?? '';
    if (url.isEmpty) {
      _showSnack('URL download tidak tersedia', isError: true);
      return;
    }

    setState(() => _isDownloading = true);
    try {
      // Minta permission storage
      if (Platform.isAndroid) {
        final status = await Permission.storage.request();
        if (!status.isGranted) {
          final status2 = await Permission.manageExternalStorage.request();
          if (!status2.isGranted) {
            _showSnack('Izin penyimpanan ditolak', isError: true);
            return;
          }
        }
      }

      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));
      if (res.statusCode != 200) throw Exception('Download gagal: ${res.statusCode}');

      final title = (_trackData!['title'] ?? 'track').replaceAll(RegExp(r'[^\w\s]'), '').trim();
      final fileName = '${title}_${DateTime.now().millisecondsSinceEpoch}.mp3';

      Directory? saveDir;
      if (Platform.isAndroid) {
        saveDir = Directory('/storage/emulated/0/Music');
        if (!await saveDir.exists()) {
          saveDir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
        }
      } else {
        saveDir = await getApplicationDocumentsDirectory();
      }

      final file = File('${saveDir.path}/$fileName');
      await file.writeAsBytes(res.bodyBytes);
      _showSnack('✅ Tersimpan: ${file.path}');
    } catch (e) {
      _showSnack('Gagal download: $e', isError: true);
    } finally {
      setState(() => _isDownloading = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red : const Color(0xFF1DB954),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0A),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: const [
          Icon(Icons.music_note, color: Color(0xFF1DB954), size: 20),
          SizedBox(width: 8),
          Text('Spotify Downloader',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 14)),
        ]),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Search bar
          Row(children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Cari lagu, artis...',
                  hintStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: const Color(0xFF1A1A1A),
                  prefixIcon: const Icon(Icons.search, color: Color(0xFF1DB954)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                onSubmitted: (_) => _searchTrack(),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: _isLoading ? null : _searchTrack,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF1DB954), Color(0xFF1ED760)]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _isLoading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.search, color: Colors.white),
              ),
            ),
          ]),

          const SizedBox(height: 20),

          // Result
          if (_hasSearchResult && _trackData != null)
            Expanded(child: SingleChildScrollView(child: Column(children: [
              // Cover
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(16)),
                child: Column(children: [
                  if ((_trackData!['cover'] ?? '').isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(_trackData!['cover'], width: 180, height: 180, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(Icons.music_note, color: Colors.grey, size: 60)),
                    ),
                  const SizedBox(height: 14),
                  Text(_trackData!['title'] ?? '',
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 6),
                  Text(_trackData!['artist'] ?? '',
                      style: const TextStyle(color: Colors.grey, fontSize: 14)),
                ]),
              ),

              const SizedBox(height: 16),

              // Player controls
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: const Color(0xFF1A1A1A), borderRadius: BorderRadius.circular(16)),
                child: Column(children: [
                  Slider(
                    value: _position.inSeconds.toDouble().clamp(0, _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1),
                    min: 0,
                    max: _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1,
                    activeColor: const Color(0xFF1DB954),
                    inactiveColor: Colors.grey.shade700,
                    onChanged: (v) => _videoController?.seekTo(Duration(seconds: v.toInt())),
                  ),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(_fmt(_position), style: const TextStyle(color: Colors.white, fontSize: 12)),
                    Text(_fmt(_duration), style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ]),
                  const SizedBox(height: 16),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconButton(
                      icon: const Icon(Icons.stop, color: Colors.white, size: 28),
                      onPressed: () {
                        _videoController?.pause();
                        _videoController?.seekTo(Duration.zero);
                        setState(() { _isPlaying = false; _position = Duration.zero; });
                      },
                    ),
                    const SizedBox(width: 16),
                    GestureDetector(
                      onTap: () {
                        if (_isPlaying) { _videoController?.pause(); setState(() => _isPlaying = false); }
                        else { _videoController?.play(); setState(() => _isPlaying = true); }
                      },
                      child: Container(
                        width: 56, height: 56,
                        decoration: const BoxDecoration(shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [Color(0xFF1DB954), Color(0xFF1ED760)])),
                        child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 32),
                      ),
                    ),
                    const SizedBox(width: 16),
                    IconButton(
                      icon: const Icon(Icons.replay, color: Colors.white, size: 28),
                      onPressed: () { _videoController?.seekTo(Duration.zero); _videoController?.play(); setState(() => _isPlaying = true); },
                    ),
                  ]),
                ]),
              ),

              const SizedBox(height: 16),

              // Download button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1DB954),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: _isDownloading
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.download, color: Colors.white),
                  label: Text(
                    _isDownloading ? 'MENYIMPAN...' : 'DOWNLOAD MP3',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 13),
                  ),
                  onPressed: _isDownloading ? null : _downloadTrack,
                ),
              ),
            ]))),

          if (_isLoading)
            const Expanded(child: Center(child: CircularProgressIndicator(color: Color(0xFF1DB954)))),

          if (!_hasSearchResult && !_isLoading)
            Expanded(child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.music_note, size: 80, color: Colors.grey.shade700),
              const SizedBox(height: 16),
              Text('Cari lagu favoritmu', style: TextStyle(color: Colors.grey.shade400, fontSize: 16)),
              const SizedBox(height: 8),
              Text('Gunakan API siputzx — tanpa server', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            ]))),
        ]),
      ),
    );
  }
}
