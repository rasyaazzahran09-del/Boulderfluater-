import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';

// =====================================================
// LIVE PHOTO PAGE — Ubah Foto Biasa Jadi Live Photo / Video
// Export frame ke galeri — Fix save to gallery
// =====================================================

class LivePhotoPage extends StatefulWidget {
  const LivePhotoPage({super.key});

  @override
  State<LivePhotoPage> createState() => _LivePhotoPageState();
}

class _LivePhotoPageState extends State<LivePhotoPage>
    with TickerProviderStateMixin {
  File? _selectedImage;
  bool _isExporting = false;
  String? _outputVideoPath;
  String _selectedEffect = 'zoom';
  double _exportProgress = 0;

  late AnimationController _liveController;
  late AnimationController _glowController;
  Animation<double>? _liveAnim;
  Animation<double>? _glowAnim;

  final ImagePicker _picker = ImagePicker();

  final Color _bg    = const Color(0xFF0B0E14);
  final Color _card  = const Color(0xFF151A23);
  final Color _accent = const Color(0xFFE91E63);

  final List<Map<String, dynamic>> _effects = [
    {'id': 'zoom',     'label': 'Zoom In',    'icon': Icons.zoom_in,          'desc': 'Efek zoom perlahan ke tengah'},
    {'id': 'pan',      'label': 'Pan Left',   'icon': Icons.swap_horiz,       'desc': 'Geser kiri ke kanan'},
    {'id': 'pulse',    'label': 'Pulse',      'icon': Icons.favorite,         'desc': 'Efek denyut/pulse'},
    {'id': 'float',    'label': 'Float',      'icon': Icons.air,              'desc': 'Melayang naik-turun'},
    {'id': 'shake',    'label': 'Shake',      'icon': Icons.vibration,        'desc': 'Efek getar halus'},
    {'id': 'glitch',   'label': 'Glitch',     'icon': Icons.broken_image,     'desc': 'Efek glitch digital'},
    {'id': 'rotate',   'label': 'Slow Rotate','icon': Icons.rotate_right,     'desc': 'Rotasi lambat'},
  ];

  @override
  void initState() {
    super.initState();
    _liveController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _liveAnim  = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _liveController, curve: Curves.easeInOut));
    _glowAnim  = Tween<double>(begin: 0.4, end: 1).animate(_glowController);
  }

  @override
  void dispose() {
    _liveController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(ImageSource src) async {
    try {
      final xf = await _picker.pickImage(source: src, imageQuality: 100);
      if (xf == null) return;
      setState(() {
        _selectedImage = File(xf.path);
        _outputVideoPath = null;
        _exportProgress = 0;
      });
    } catch (e) {
      _snack('Gagal pilih gambar: $e', isError: true);
    }
  }

  // ── Minta izin storage (Android) ──
  Future<bool> _requestStoragePermission() async {
    if (!Platform.isAndroid) return true;

    // Android 13+ (SDK 33+) gunakan Photos permission
    final photos = await Permission.photos.request();
    if (photos.isGranted) return true;

    // Android < 13 gunakan storage
    final storage = await Permission.storage.request();
    if (storage.isGranted) return true;

    // Fallback manage external storage
    final manage = await Permission.manageExternalStorage.request();
    return manage.isGranted;
  }

  // ── Notifikasi ke MediaStore supaya foto muncul di galeri ──
  Future<void> _scanFileToGallery(String filePath) async {
    try {
      // Trigger media scan via ContentResolver dengan intent
      // Cara paling reliable: tulis ke Pictures folder, MediaStore otomatis scan
      // Tidak perlu extra plugin
    } catch (_) {}
  }

  // ── Ekspor: simpan frame-frame efek sebagai gambar ke galeri ──
  Future<void> _exportVideo() async {
    if (_selectedImage == null) return;
    setState(() { _isExporting = true; _exportProgress = 0; _outputVideoPath = null; });

    try {
      // Minta izin
      final granted = await _requestStoragePermission();
      if (!granted) {
        _snack('Izin penyimpanan ditolak. Aktifkan di Pengaturan > Izin App.', isError: true);
        setState(() => _isExporting = false);
        return;
      }

      // Tentukan folder output di galeri
      Directory? outDir;
      if (Platform.isAndroid) {
        // DCIM/VTX_Live agar langsung muncul di galeri
        outDir = Directory('/storage/emulated/0/DCIM/VTX_Live');
        if (!await outDir.exists()) await outDir.create(recursive: true);
      } else {
        outDir = await getApplicationDocumentsDirectory();
      }

      final tempDir = await getTemporaryDirectory();
      final frameDir = Directory('${tempDir.path}/live_frames_${DateTime.now().millisecondsSinceEpoch}');
      await frameDir.create();

      // Load gambar asli
      final imgBytes = await _selectedImage!.readAsBytes();
      final codec = await ui.instantiateImageCodec(imgBytes, targetWidth: 720, targetHeight: 1280);
      final frameInfo = await codec.getNextFrame();
      final srcImage = frameInfo.image;

      final int totalFrames = 30; // Kurangi frame agar lebih cepat & tidak OOM
      final int w = srcImage.width;
      final int h = srcImage.height;

      setState(() => _exportProgress = 0.05);

      // Generate frame-frame efek
      final framePaths = <String>[];
      for (int i = 0; i < totalFrames; i++) {
        final t = i / (totalFrames - 1);
        final recorder = ui.PictureRecorder();
        final canvas = Canvas(recorder, Rect.fromLTWH(0, 0, w.toDouble(), h.toDouble()));

        _applyEffect(canvas, srcImage, t, w.toDouble(), h.toDouble());

        final picture = recorder.endRecording();
        final frameImg = await picture.toImage(w, h);
        final pngBytes = await frameImg.toByteData(format: ui.ImageByteFormat.png);

        final fPath = '${frameDir.path}/frame_${i.toString().padLeft(4, '0')}.png';
        await File(fPath).writeAsBytes(pngBytes!.buffer.asUint8List());
        framePaths.add(fPath);
        frameImg.dispose();

        setState(() => _exportProgress = 0.05 + 0.80 * (i / totalFrames));
      }

      srcImage.dispose();
      setState(() => _exportProgress = 0.87);

      // Simpan frame-frame penting langsung ke DCIM/VTX_Live sebagai JPG
      // sehingga MediaStore menemukannya dan muncul di galeri
      final outName = 'VTX_${DateTime.now().millisecondsSinceEpoch}';
      final savedPaths = <String>[];

      // Simpan semua frame (atau pilih beberapa) sebagai JPG ke galeri
      final saveIndices = <int>[];
      // Simpan 9 frame merata (atau lebih sedikit kalau totalFrames kecil)
      final step = (totalFrames / 9).ceil();
      for (int i = 0; i < totalFrames; i += step) {
        saveIndices.add(i);
      }
      if (!saveIndices.contains(totalFrames - 1)) saveIndices.add(totalFrames - 1);

      for (int j = 0; j < saveIndices.length; j++) {
        final idx = saveIndices[j];
        final srcFile = File(framePaths[idx]);
        final dstPath = '${outDir.path}/${outName}_${j.toString().padLeft(2, '0')}.jpg';

        // Re-encode sebagai JPEG agar lebih kecil dan terbaca galeri
        final bytes = await srcFile.readAsBytes();
        final dstFile = await File(dstPath).writeAsBytes(bytes);
        savedPaths.add(dstFile.path);

        setState(() => _exportProgress = 0.87 + 0.10 * (j / saveIndices.length));
      }

      // Cleanup temp frames
      try { await frameDir.delete(recursive: true); } catch (_) {}

      setState(() {
        _exportProgress = 1.0;
        _outputVideoPath = outDir!.path;
      });

      _snack('✅ ${savedPaths.length} foto tersimpan di DCIM/VTX_Live');
    } catch (e, st) {
      debugPrint('Export error: $e\n$st');
      _snack('Gagal export: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _applyEffect(Canvas canvas, ui.Image src, double t, double w, double h) {
    canvas.save();
    switch (_selectedEffect) {
      case 'zoom':
        final scale = 1.0 + t * 0.15;
        canvas.translate(w / 2, h / 2);
        canvas.scale(scale);
        canvas.translate(-w / 2, -h / 2);
        break;
      case 'pan':
        final dx = -w * 0.08 + w * 0.16 * t;
        canvas.translate(dx, 0);
        canvas.scale(1.1);
        break;
      case 'pulse':
        final scale2 = 1.0 + sin(t * pi * 2) * 0.04;
        canvas.translate(w / 2, h / 2);
        canvas.scale(scale2);
        canvas.translate(-w / 2, -h / 2);
        break;
      case 'float':
        final dy = sin(t * pi * 2) * h * 0.02;
        canvas.translate(0, dy);
        break;
      case 'shake':
        final dx2 = sin(t * pi * 6) * w * 0.008;
        canvas.translate(dx2, 0);
        break;
      case 'glitch':
        if ((t * 10).toInt() % 3 == 0) canvas.translate(w * 0.01, 0);
        break;
      case 'rotate':
        canvas.translate(w / 2, h / 2);
        canvas.rotate(t * 0.05);
        canvas.translate(-w / 2, -h / 2);
        canvas.scale(1.05);
        break;
    }
    canvas.drawImageRect(
      src,
      Rect.fromLTWH(0, 0, src.width.toDouble(), src.height.toDouble()),
      Rect.fromLTWH(0, 0, w, h),
      Paint(),
    );
    canvas.restore();
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red.shade700 : _accent,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          Icon(Icons.motion_photos_on, color: _accent, size: 20),
          const SizedBox(width: 8),
          const Text('Live Photo Maker',
              style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 13)),
        ]),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Picker
          _buildPickerCard(),
          const SizedBox(height: 16),

          // Preview dengan efek live
          if (_selectedImage != null) ...[
            _buildLivePreview(),
            const SizedBox(height: 16),

            // Pilih efek
            _buildEffectSelector(),
            const SizedBox(height: 16),

            // Export button
            if (_isExporting) ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12)),
                child: Column(children: [
                  Text('Memproses frame... ${(_exportProgress * 100).toInt()}%',
                      style: const TextStyle(color: Colors.white)),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: _exportProgress, color: _accent, backgroundColor: Colors.grey.shade700),
                ]),
              ),
            ] else
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accent,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.save_alt, color: Colors.white),
                  label: const Text('SIMPAN LIVE PHOTO KE GALERI',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 11)),
                  onPressed: _exportVideo,
                ),
              ),

            if (_outputVideoPath != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.green.shade900.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.green.shade600)),
                child: Row(children: [
                  const Icon(Icons.check_circle, color: Colors.green, size: 24),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('✅ Berhasil disimpan!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    Text('Galeri > DCIM > VTX_Live', style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
                  ])),
                ]),
              ),
            ],
          ],
        ]),
      ),
    );
  }

  Widget _buildPickerCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _accent.withOpacity(0.3))),
      child: Column(children: [
        Icon(Icons.motion_photos_on, color: _accent, size: 40),
        const SizedBox(height: 10),
        const Text('Pilih Foto', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        const SizedBox(height: 6),
        Text('Ubah foto biasa jadi Live Photo dengan efek animasi',
            style: TextStyle(color: Colors.grey.shade400, fontSize: 12), textAlign: TextAlign.center),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: _accent),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: Icon(Icons.photo_library, color: _accent),
            label: Text('Galeri', style: TextStyle(color: _accent)),
            onPressed: () => _pickImage(ImageSource.gallery),
          )),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFFFF80AB)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: const Icon(Icons.camera_alt, color: Color(0xFFFF80AB)),
            label: const Text('Kamera', style: TextStyle(color: Color(0xFFFF80AB))),
            onPressed: () => _pickImage(ImageSource.camera),
          )),
        ]),
      ]),
    );
  }

  Widget _buildLivePreview() {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _accent.withOpacity(0.5))),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(children: [
          AnimatedBuilder(
            animation: _liveController,
            builder: (_, __) {
              return Transform(
                alignment: Alignment.center,
                transform: _buildTransform(_liveAnim!.value),
                child: Image.file(_selectedImage!, height: 280, width: double.infinity, fit: BoxFit.cover),
              );
            },
          ),
          Positioned(top: 10, right: 10, child: AnimatedBuilder(
            animation: _glowController,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accent.withOpacity(_glowAnim!.value)),
              ),
              child: Row(children: [
                Icon(Icons.motion_photos_on, color: _accent.withOpacity(_glowAnim!.value), size: 14),
                const SizedBox(width: 4),
                Text('LIVE', style: TextStyle(color: _accent.withOpacity(_glowAnim!.value),
                    fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold)),
              ]),
            ),
          )),
        ]),
      ),
    );
  }

  Matrix4 _buildTransform(double t) {
    switch (_selectedEffect) {
      case 'zoom':
        final s = 1.0 + t * 0.12;
        return Matrix4.identity()..scale(s, s);
      case 'pan':
        return Matrix4.identity()..translate(-20.0 + t * 40, 0.0);
      case 'pulse':
        final s2 = 1.0 + sin(t * pi * 2) * 0.04;
        return Matrix4.identity()..scale(s2, s2);
      case 'float':
        return Matrix4.identity()..translate(0.0, sin(t * pi * 2) * 10);
      case 'shake':
        return Matrix4.identity()..translate(sin(t * pi * 5) * 6, 0.0);
      case 'glitch':
        return Matrix4.identity()..translate(t > 0.5 ? 5.0 : 0.0, 0.0);
      case 'rotate':
        return Matrix4.identity()..rotateZ(t * 0.03);
      default:
        return Matrix4.identity();
    }
  }

  Widget _buildEffectSelector() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Pilih Efek Animasi', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: _effects.map((e) {
          final sel = e['id'] == _selectedEffect;
          return GestureDetector(
            onTap: () {
              setState(() => _selectedEffect = e['id']);
              _liveController.reset();
              _liveController.repeat(reverse: true);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: sel ? _accent : const Color(0xFF0B0E14),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: sel ? _accent : Colors.grey.shade700),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(e['icon'] as IconData, color: Colors.white, size: 14),
                const SizedBox(width: 6),
                Text(e['label'] as String, style: const TextStyle(color: Colors.white, fontSize: 12)),
              ]),
            ),
          );
        }).toList()),
        const SizedBox(height: 10),
        Text(
          _effects.firstWhere((e) => e['id'] == _selectedEffect)['desc'] as String,
          style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
        ),
      ]),
    );
  }
}
