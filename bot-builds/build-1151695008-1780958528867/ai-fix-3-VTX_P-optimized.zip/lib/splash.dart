import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart'; // Pastikan import ini sesuai struktur folder Anda

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  
  // Controller untuk animasi teks (pulse/glow)
  late AnimationController _textAnimationController;
  
  // Controller untuk fade out akhir
  late AnimationController _fadeOutController;

  bool _isVideoInitialized = false;
  bool _hasNavigated = false; // Mencegah navigasi ganda

  @override
  void initState() {
    super.initState();

    // 1. Inisialisasi Animasi Teks (Pulse Effect)
    _textAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true); // Ulangi bolak-balik

    // 2. Inisialisasi Animasi Fade Out
    _fadeOutController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    // 3. Inisialisasi Video
    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        if (mounted) {
          setState(() {
            _isVideoInitialized = true;
          });
          _videoController.setLooping(false);
          _videoController.play();

          // Listener untuk mengecek durasi video
          _videoController.addListener(_checkVideoPosition);
        }
      }).catchError((error) {
        // Jika video error (misal file corrupt), tetap lanjut ke dashboard setelah beberapa detik
        debugPrint("Error loading video: $error");
        Future.delayed(const Duration(seconds: 3), () {
          _navigateToDashboard();
        });
      });
  }

  void _checkVideoPosition() {
    if (_hasNavigated || !_videoController.value.isInitialized) return;

    final position = _videoController.value.position;
    final duration = _videoController.value.duration;

    // Cek apakah durasi valid
    if (duration.inMilliseconds > 0) {
      // Mulai fade out 1 detik sebelum selesai
      if (position >= duration - const Duration(seconds: 1)) {
        if (_fadeOutController.status != AnimationStatus.forward &&
            _fadeOutController.status != AnimationStatus.completed) {
          _fadeOutController.forward();
        }
      }

      // Navigasi jika video selesai
      if (position >= duration) {
        _navigateToDashboard();
      }
    }
  }

  void _navigateToDashboard() {
    if (_hasNavigated) return;
    
    setState(() {
      _hasNavigated = true;
    });

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  // Fungsi untuk tombol SKIP
  void _onSkipIntro() {
    _videoController.removeListener(_checkVideoPosition);
    _videoController.pause();
    _navigateToDashboard();
  }

  @override
  void dispose() {
    // Hentikan semua resource agar tidak memory leak
    _videoController.dispose();
    _textAnimationController.dispose();
    _fadeOutController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand, // Memastikan stack memenuhi layar
        children: [
          // --- LAYER 1: VIDEO BACKGROUND ---
          if (_isVideoInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: Colors.black), // Background hitam sementara loading

          // --- LAYER 2: OVERLAY GELAP (Supaya teks jelas) ---
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.black.withOpacity(0.6),
                  ],
                ),
              ),
            ),
          ),

          // --- LAYER 3: KONTEN TENGAH (LOGO / TEKS) ---
          Positioned.fill(
            child: Center(
              child: AnimatedBuilder(
                animation: _textAnimationController,
                builder: (context, child) {
                  // Menghitung nilai opacity/shadow berdasarkan animasi
                  double glowIntensity = _textAnimationController.value;
                  
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Teks Utama
                      Text(
                        "VTX",
                        style: TextStyle(
                          fontSize: 70,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 12,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                              // Efek glow merah yang berkedip
                              color: Colors.redAccent.withOpacity(0.5 + (glowIntensity * 0.5)),
                              blurRadius: 15 + (glowIntensity * 25),
                              offset: const Offset(0, 0),
                            ),
                            Shadow(
                              color: Colors.black.withOpacity(0.9),
                              blurRadius: 10,
                              offset: const Offset(2, 5),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Sub-teks
                      Text(
                        "DIAM TETAPI TIDAK KEJAM",
                        style: TextStyle(
                          fontSize: 16,
                          letterSpacing: 6,
                          color: Colors.white.withOpacity(0.8),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),

          // --- LAYER 4: TOMBOL SKIP ---
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: GestureDetector(
                  onTap: _onSkipIntro,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white.withOpacity(0.1),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.skip_next, color: Colors.white, size: 18),
                        SizedBox(width: 5),
                        Text(
                          "SKIP",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // --- LAYER 5: FADE OUT OVERLAY (AKHIR VIDEO) ---
          IgnorePointer(
            // Memastikan overlay ini tidak menghalangi klik tombol skip
            child: FadeTransition(
              opacity: _fadeOutController.drive(Tween(begin: 0.0, end: 1.0)),
              child: Container(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}